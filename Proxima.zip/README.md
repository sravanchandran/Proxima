# PROXIMA Business Demo

PROXIMA is a polished, realistic SaaS-style property and facilities management demonstration application. It is designed to allow a business person to understand the PROXIMA ecosystem within 5–10 minutes by demonstrating Building Management, Asset Management, Complaint Management, WhatsApp integration, and operational dashboards.

## Features

- **Authentication**: Secure login/logout managed by Supabase Auth.
- **Dashboard**: High-level KPIs, recent activity, and dynamic metrics.
- **Building Management**: View the hierarchical structure of a building, its floors, and areas (e.g., Anantara Business Tower).
- **Asset Register**: Manage equipment and facilities assets across the building.
- **Complaint Management**: Track operational issues from creation to resolution, complete with status updates and photo uploads.
- **WhatsApp Integration**: A webhook that allows field staff to create complaints seamlessly by simply texting a WhatsApp number.
- **Premium UI**: Designed with Tailwind CSS and Shadcn UI, featuring glassmorphism, dynamic gradients, and smooth micro-animations.

## Requirements

- **Node.js**: v18+
- **npm**: v9+
- **Supabase**: A Supabase account for the PostgreSQL database, Authentication, and Storage.
- **Meta Developer Account**: (Optional) For live WhatsApp Business Cloud API testing.

## Installation

1. Clone the repository and install dependencies:
   ```bash
   npm install
   ```

2. Duplicate the `.env.example` file and rename it to `.env.local`. Fill in the values from your Supabase project settings:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://<your-project-ref>.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=<your-anon-key>
   SUPABASE_SERVICE_ROLE_KEY=<your-service-role-key>

   # Optional: For WhatsApp Webhook validation
   WHATSAPP_VERIFY_TOKEN=proxima_demo_secret
   ```

## Database Setup

1. Open your Supabase Dashboard.
2. Go to the **SQL Editor** and paste the contents of `supabase/migrations/20240101000000_initial_schema.sql`.
3. Run the script. This will create all necessary tables (Profiles, Buildings, Floors, Areas, Assets, Complaints), setup Row Level Security (RLS), and create the `complaint_photos` storage bucket.

## Seeding Demo Data

To populate the application with realistic data (e.g., Anantara Business Tower, assorted assets, and complaints), run the seed script:
```bash
npm run seed
```

## Running the Application

Start the Next.js development server:
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser. 

### Demo User Login
If you haven't created a user yet, go to your Supabase Dashboard -> **Authentication** and create a test user (e.g., `manager@proxima.demo` with a secure password). You can then log into the application using these credentials.

## WhatsApp Webhook Testing

If you'd like to test the WhatsApp integration locally without a Meta Developer account:
1. Ensure your dev server is running.
2. Run the mock payload script:
   ```bash
   node scripts/test-whatsapp.mjs
   ```
3. Check the PROXIMA dashboard; a new complaint will instantly appear.

If you are connecting it to Meta:
1. Use a tunneling tool like **Ngrok** to expose your local server (`ngrok http 3000`).
2. Provide the Ngrok URL (`https://<your-ngrok-id>.ngrok-free.app/api/whatsapp/webhook`) in the Meta Webhook configuration.
3. Use the `WHATSAPP_VERIFY_TOKEN` you set in `.env.local` to verify the connection.
