

async function testWebhook() {
  const payload = {
    object: 'whatsapp_business_account',
    entry: [
      {
        changes: [
          {
            value: {
              messages: [
                {
                  type: 'text',
                  text: {
                    body: 'Complaint: Broken chair in the lobby\nLocation: Ground Floor, Lobby\nPriority: Low\nPlease replace it soon.'
                  }
                }
              ]
            }
          }
        ]
      }
    ]
  }

  console.log('Sending mock WhatsApp webhook...')

  const response = await fetch('http://localhost:3000/api/whatsapp/webhook', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  })

  console.log('Response Status:', response.status)
  const text = await response.text()
  console.log('Response Text:', text)

  if (response.ok) {
    console.log('✅ Webhook triggered successfully. Check the PROXIMA dashboard!')
  } else {
    console.error('❌ Webhook failed.')
  }
}

testWebhook().catch(console.error)
