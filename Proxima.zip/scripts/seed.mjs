import { createClient } from '@supabase/supabase-js'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
dotenv.config({ path: path.resolve(__dirname, '../.env.local') })

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase credentials in .env.local')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseServiceKey)

async function seed() {
  console.log('Seeding Database...')

  // Clear existing data
  await supabase.from('complaints').delete().neq('id', '00000000-0000-0000-0000-000000000000')
  await supabase.from('assets').delete().neq('id', '00000000-0000-0000-0000-000000000000')
  await supabase.from('areas').delete().neq('id', '00000000-0000-0000-0000-000000000000')
  await supabase.from('floors').delete().neq('id', '00000000-0000-0000-0000-000000000000')
  await supabase.from('buildings').delete().neq('id', '00000000-0000-0000-0000-000000000000')

  // 1. Create Building
  const { data: building, error: bError } = await supabase
    .from('buildings')
    .insert([{
      name: 'Anantara Business Tower',
      address: 'Downtown Dubai',
      city: 'Dubai',
      country: 'UAE',
      description: 'Premium Grade-A commercial tower in Downtown Dubai.',
      number_of_floors: 5,
      status: 'Active'
    }])
    .select()
    .single()

  if (bError) throw bError
  console.log(`Created Building: ${building.name}`)

  // 2. Create Floors
  const floorData = [
    { building_id: building.id, name: 'Basement', level: -1 },
    { building_id: building.id, name: 'Ground Floor', level: 0 },
    { building_id: building.id, name: 'Floor 1', level: 1 },
    { building_id: building.id, name: 'Floor 2', level: 2 },
    { building_id: building.id, name: 'Floor 3', level: 3 },
  ]
  const { data: floors, error: fError } = await supabase.from('floors').insert(floorData).select()
  if (fError) throw fError
  console.log(`Created ${floors.length} Floors`)

  const b1 = floors.find(f => f.name === 'Basement')
  const g  = floors.find(f => f.name === 'Ground Floor')
  const f1 = floors.find(f => f.name === 'Floor 1')
  const f2 = floors.find(f => f.name === 'Floor 2')
  const f3 = floors.find(f => f.name === 'Floor 3')

  // 3. Create Areas
  const areaData = [
    { floor_id: b1.id, name: 'Plant Room' },
    { floor_id: b1.id, name: 'Parking' },
    { floor_id: g.id,  name: 'Lobby' },
    { floor_id: g.id,  name: 'Reception' },
    { floor_id: g.id,  name: 'Electrical Room' },
    { floor_id: f1.id, name: 'Office 101' },
    { floor_id: f1.id, name: 'Office 102' },
    { floor_id: f2.id, name: 'Office 201' },
    { floor_id: f2.id, name: 'Office 202' },
    { floor_id: f3.id, name: 'Office 301' },
  ]
  const { data: areas, error: aError } = await supabase.from('areas').insert(areaData).select()
  if (aError) throw aError
  console.log(`Created ${areas.length} Areas`)

  const area = (name) => areas.find(a => a.name === name)

  // 4. Create Assets
  const assetData = [
    {
      asset_id: 'AST-001',
      name: 'Split AC Unit',
      type: 'HVAC',
      category: 'HVAC',
      building_id: building.id,
      floor_id: f1.id,
      area_id: area('Office 101').id,
      description: 'Carrier 2 Ton Split AC Unit',
      manufacturer: 'Carrier',
      model: '42QHC018DS',
      serial_number: 'CA-001-2021',
      status: 'Active',
      installation_date: '2021-03-15',
    },
    {
      asset_id: 'AST-002',
      name: 'Water Booster Pump',
      type: 'Mechanical',
      category: 'Plumbing',
      building_id: building.id,
      floor_id: b1.id,
      area_id: area('Plant Room').id,
      description: 'Grundfos main cold water booster pump',
      manufacturer: 'Grundfos',
      model: 'CM 5-6',
      serial_number: 'GF-002-2021',
      status: 'Active',
      installation_date: '2021-05-20',
    },
    {
      asset_id: 'AST-003',
      name: 'Fire Extinguisher CO2',
      type: 'Fire Safety',
      category: 'Fire Safety',
      building_id: building.id,
      floor_id: f2.id,
      area_id: area('Office 201').id,
      description: '5kg CO2 fire extinguisher',
      manufacturer: 'Amerex',
      model: 'B5T',
      serial_number: 'AM-003-2021',
      status: 'Active',
      installation_date: '2021-06-01',
    },
    {
      asset_id: 'AST-004',
      name: 'Main Electrical Panel',
      type: 'Electrical',
      category: 'Electrical',
      building_id: building.id,
      floor_id: g.id,
      area_id: area('Electrical Room').id,
      description: 'Main LV distribution board, 415V',
      manufacturer: 'Schneider Electric',
      model: 'MasterPact MTZ2',
      serial_number: 'SE-004-2021',
      status: 'Active',
      installation_date: '2021-01-10',
    },
    {
      asset_id: 'AST-005',
      name: 'Chiller Unit',
      type: 'HVAC',
      category: 'HVAC',
      building_id: building.id,
      floor_id: b1.id,
      area_id: area('Plant Room').id,
      description: 'Trane air-cooled chiller, 200TR',
      manufacturer: 'Trane',
      model: 'CGAM200',
      serial_number: 'TR-005-2021',
      status: 'Active',
      installation_date: '2021-02-28',
    },
    {
      asset_id: 'AST-006',
      name: 'UPS System',
      type: 'Electrical',
      category: 'Electrical',
      building_id: building.id,
      floor_id: g.id,
      area_id: area('Electrical Room').id,
      description: 'Eaton 9PX 10KVA UPS for BMS',
      manufacturer: 'Eaton',
      model: '9PX10KVA',
      serial_number: 'EA-006-2021',
      status: 'Active',
      installation_date: '2021-08-01',
    },
    {
      asset_id: 'AST-007',
      name: 'Fresh Air Handling Unit',
      type: 'HVAC',
      category: 'HVAC',
      building_id: building.id,
      floor_id: f3.id,
      area_id: area('Office 301').id,
      description: 'Carrier AHU for Floor 3',
      manufacturer: 'Carrier',
      model: 'AHU-39HQ',
      serial_number: 'CA-007-2021',
      status: 'Active',
      installation_date: '2021-09-05',
    },
    {
      asset_id: 'AST-008',
      name: 'Diesel Generator',
      type: 'Electrical',
      category: 'Electrical',
      building_id: building.id,
      floor_id: b1.id,
      area_id: area('Plant Room').id,
      description: 'Caterpillar 500 kVA standby generator',
      manufacturer: 'Caterpillar',
      model: 'DE500E0',
      serial_number: 'CAT-008-2021',
      status: 'Under Maintenance',
      installation_date: '2021-01-15',
    },
  ]
  const { data: assets, error: astError } = await supabase.from('assets').insert(assetData).select()
  if (astError) throw astError
  console.log(`Created ${assets.length} Assets`)

  const asset = (id) => assets.find(a => a.asset_id === id)

  // 5. Create Complaints
  const complaintData = [
    {
      ticket_number: 'CMP-001',
      title: 'AC not cooling in Office 101',
      description: 'The split AC unit in Office 101 is blowing warm air. Tenants reporting discomfort.',
      category: 'HVAC',
      priority: 'High',
      building_id: building.id,
      floor_id: f1.id,
      area_id: area('Office 101').id,
      asset_id: asset('AST-001').id,
      source: 'WhatsApp',
      status: 'Open',
    },
    {
      ticket_number: 'CMP-002',
      title: 'Water leakage near booster pump',
      description: 'Water leaking from the flexible joint near the main pump. Risk of flooding.',
      category: 'Plumbing',
      priority: 'High',
      building_id: building.id,
      floor_id: b1.id,
      area_id: area('Plant Room').id,
      asset_id: asset('AST-002').id,
      source: 'Web',
      status: 'In Progress',
    },
    {
      ticket_number: 'CMP-003',
      title: 'Damaged light fittings in Office 201',
      description: 'Two ceiling light fittings flickering intermittently above workstations.',
      category: 'Electrical',
      priority: 'Medium',
      building_id: building.id,
      floor_id: f2.id,
      area_id: area('Office 201').id,
      source: 'Web',
      status: 'Resolved',
    },
    {
      ticket_number: 'CMP-004',
      title: 'Lobby AC temperature too low',
      description: 'Ground floor lobby thermostat reading 17°C. Tenants and visitors complaining of cold.',
      category: 'HVAC',
      priority: 'Low',
      building_id: building.id,
      floor_id: g.id,
      area_id: area('Lobby').id,
      source: 'WhatsApp',
      status: 'Open',
    },
    {
      ticket_number: 'CMP-005',
      title: 'Generator failed monthly test',
      description: 'Scheduled monthly load test did not complete. Generator started but did not pick up load.',
      category: 'Electrical',
      priority: 'Critical',
      building_id: building.id,
      floor_id: b1.id,
      area_id: area('Plant Room').id,
      asset_id: asset('AST-008').id,
      source: 'Web',
      status: 'Open',
    },
    {
      ticket_number: 'CMP-006',
      title: 'UPS battery health critical',
      description: 'UPS battery health at 18%. Runtime reduced to under 4 minutes.',
      category: 'Electrical',
      priority: 'High',
      building_id: building.id,
      floor_id: g.id,
      area_id: area('Electrical Room').id,
      asset_id: asset('AST-006').id,
      source: 'Web',
      status: 'In Progress',
    },
    {
      ticket_number: 'CMP-007',
      title: 'AHU filter blockage on Floor 3',
      description: 'Fresh air handling unit showing high pressure drop across filters. Needs replacement.',
      category: 'HVAC',
      priority: 'Medium',
      building_id: building.id,
      floor_id: f3.id,
      area_id: area('Office 301').id,
      asset_id: asset('AST-007').id,
      source: 'WhatsApp',
      status: 'Resolved',
    },
    {
      ticket_number: 'CMP-008',
      title: 'Parking flood light not working',
      description: 'Three flood lights in basement parking not functioning. Safety concern at night.',
      category: 'Electrical',
      priority: 'Medium',
      building_id: building.id,
      floor_id: b1.id,
      area_id: area('Parking').id,
      source: 'Web',
      status: 'Closed',
    },
  ]
  const { data: complaints, error: cmpError } = await supabase.from('complaints').insert(complaintData).select()
  if (cmpError) throw cmpError
  console.log(`Created ${complaints.length} Complaints`)

  // 6. Create Service Persons (if table exists)
  const servicePersonData = [
    {
      name: 'Ahmed Khan',
      service_type: 'HVAC',
      company: 'CoolTech Services',
      whatsapp_number: '+971501234567',
      is_active: true,
    },
    {
      name: 'Raj Kumar',
      service_type: 'HVAC',
      company: 'Dubai Climate Solutions',
      whatsapp_number: '+971502345678',
      is_active: true,
    },
    {
      name: 'Ali Hassan',
      service_type: 'Plumbing',
      company: 'Dubai Plumbing LLC',
      whatsapp_number: '+971503456789',
      is_active: true,
    },
    {
      name: 'Tariq Mahmoud',
      service_type: 'Plumbing',
      company: 'FlowMaster Services',
      whatsapp_number: '+971504567890',
      is_active: true,
    },
    {
      name: 'John Mathew',
      service_type: 'Electrical',
      company: 'PowerCare Services',
      whatsapp_number: '+971505678901',
      is_active: true,
    },
    {
      name: 'Vikram Singh',
      service_type: 'Electrical',
      company: 'Apex Electrical LLC',
      whatsapp_number: '+971506789012',
      is_active: true,
    },
    {
      name: 'Fatima Ali',
      service_type: 'Fire Safety',
      company: 'SafeGuard Fire Systems',
      whatsapp_number: '+971507890123',
      is_active: true,
    },
    {
      name: 'Elena Rostova',
      service_type: 'Cleaning',
      company: 'CleanSpark Facilities',
      whatsapp_number: '+971508901234',
      is_active: true,
    },
    {
      name: 'Omar Farooq',
      service_type: 'General Maintenance',
      company: 'PrimeFix Solutions',
      whatsapp_number: '+971509012345',
      is_active: false,
    },
  ]

  try {
    const { data: sps, error: spError } = await supabase.from('service_persons').insert(servicePersonData).select()
    if (!spError && sps) {
      console.log(`Created ${sps.length} Service Persons`)
    } else {
      console.log('service_persons table not yet present in Supabase, using local resilient store')
    }
  } catch (err) {
    console.log('Skipping service_persons insert (table migration pending):', err.message)
  }

  console.log('Seed completed successfully!')
}

seed().catch(console.error)
