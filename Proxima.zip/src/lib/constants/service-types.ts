export const SERVICE_TYPES = [
  'HVAC',
  'Plumbing',
  'Electrical',
  'Fire Safety',
  'Cleaning',
  'Civil',
  'General Maintenance',
] as const

export type ServiceType = typeof SERVICE_TYPES[number]

export function isValidServiceType(value: string): value is ServiceType {
  return SERVICE_TYPES.includes(value as ServiceType)
}

export const SERVICE_TYPE_DETAILS: Record<
  ServiceType,
  {
    label: string
    description: string
    color: string
    badgeClass: string
  }
> = {
  'HVAC': {
    label: 'HVAC',
    description: 'Heating, ventilation, air conditioning & chiller systems',
    color: '#0284C7',
    badgeClass: 'bg-sky-50 text-sky-700 border-sky-200',
  },
  'Plumbing': {
    label: 'Plumbing',
    description: 'Pumps, water supply, drainage & piping',
    color: '#0D9488',
    badgeClass: 'bg-teal-50 text-teal-700 border-teal-200',
  },
  'Electrical': {
    label: 'Electrical',
    description: 'LV panels, power distribution, lighting & generators',
    color: '#D97706',
    badgeClass: 'bg-amber-50 text-amber-700 border-amber-200',
  },
  'Fire Safety': {
    label: 'Fire Safety',
    description: 'Alarms, sprinklers, extinguishers & suppression systems',
    color: '#DC2626',
    badgeClass: 'bg-red-50 text-red-700 border-red-200',
  },
  'Cleaning': {
    label: 'Cleaning',
    description: 'Deep sanitization, facade cleaning & waste management',
    color: '#059669',
    badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  },
  'Civil': {
    label: 'Civil',
    description: 'Structural repairs, flooring, masonry & carpentry',
    color: '#4B5563',
    badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
  },
  'General Maintenance': {
    label: 'General Maintenance',
    description: 'Routine upkeep, fixtures, minor repairs & inspections',
    color: '#4F46E5',
    badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  },
}
