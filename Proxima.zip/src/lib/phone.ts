/**
 * Phone number normalization & validation utilities.
 * Handles international numbers and common local UAE formats (e.g., 050..., 055...).
 */

export function normalizePhoneNumber(raw: string): string {
  if (!raw) return ''

  // Trim whitespace
  let clean = raw.trim()

  // Remove spaces, dashes, parentheses, dots
  clean = clean.replace(/[\s\-\(\)\.]/g, '')

  // If starts with 00, replace with +
  if (clean.startsWith('00')) {
    clean = '+' + clean.substring(2)
  }

  // If already starts with +, ensure remaining are digits
  if (clean.startsWith('+')) {
    const digitsOnly = clean.substring(1).replace(/\D/g, '')
    return `+${digitsOnly}`
  }

  // If numbers start with 05X (common UAE 10-digit mobile number, e.g. 0501234567)
  if (/^05\d{8}$/.test(clean)) {
    return `+971${clean.substring(1)}`
  }

  // If numbers start with 971 without +, add +
  if (/^971\d{8,9}$/.test(clean)) {
    return `+${clean}`
  }

  // Generic fallback: if 9 or 10 digits starting with non-0, assume UAE if 9 digits, else add +
  const digits = clean.replace(/\D/g, '')
  if (digits.length === 9 && digits.startsWith('5')) {
    return `+971${digits}`
  }

  return `+${digits}`
}

export function isValidPhoneNumber(phone: string): boolean {
  const normalized = normalizePhoneNumber(phone)
  // E.164 format: + followed by 8 to 15 digits
  return /^\+[1-9]\d{7,14}$/.test(normalized)
}

export function formatPhoneNumber(phone: string): string {
  const normalized = normalizePhoneNumber(phone)
  if (!normalized) return phone

  // Format UAE numbers: +971 50 XXX XXXX
  if (normalized.startsWith('+971')) {
    const rest = normalized.substring(4)
    if (rest.length === 9) {
      return `+971 ${rest.substring(0, 2)} ${rest.substring(2, 5)} ${rest.substring(5)}`
    }
  }

  // Generic international grouping: +XX XXX XXX XXXX
  if (normalized.length >= 11) {
    const code = normalized.substring(0, 3)
    const part1 = normalized.substring(3, 6)
    const part2 = normalized.substring(6, 9)
    const part3 = normalized.substring(9)
    return `${code} ${part1} ${part2} ${part3}`
  }

  return normalized
}
