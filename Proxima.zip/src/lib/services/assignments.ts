import { createClient } from '@/lib/supabase/server'
import { getServicePersonById } from './service-persons'
import { recordComplaintActivity } from './whatsapp-messages'
import {
  sendAssignmentWhatsAppMessage,
  WhatsAppSendResult,
} from '@/lib/whatsapp/service'
import { getMemoryAssignments, ServicePersonRecord } from './demo-store'

export interface AssignmentResult {
  success: boolean
  message: string
  servicePerson: ServicePersonRecord
  whatsappResult: WhatsAppSendResult
}

export async function assignComplaint(
  complaintId: string,
  servicePersonId: string
): Promise<AssignmentResult> {
  const supabase = await createClient()

  // 1. Fetch complaint
  const { data: complaint, error: compError } = await supabase
    .from('complaints')
    .select('*, buildings(name), floors(name), areas(name), assets(name, asset_id)')
    .eq('id', complaintId)
    .single()

  if (compError || !complaint) {
    throw new Error('Complaint not found')
  }

  // 2. Fetch service person
  const servicePerson = await getServicePersonById(servicePersonId)
  if (!servicePerson) {
    throw new Error('Selected service person does not exist')
  }

  // 3. Validate service person active status
  if (!servicePerson.is_active) {
    throw new Error('Selected service person is currently inactive and cannot be assigned')
  }

  // 4. Validate category match (CRITICAL RULE)
  const complaintCategory = complaint.category || 'HVAC'
  if (servicePerson.service_type.toLowerCase() !== complaintCategory.toLowerCase()) {
    throw new Error(
      `Selected service person is not eligible for this complaint type. Service type is "${servicePerson.service_type}", but complaint category is "${complaintCategory}".`
    )
  }

  const isReassignment =
    complaint.assigned_service_person_id &&
    complaint.assigned_service_person_id !== servicePerson.id

  // 5. Update complaint in Supabase
  const updatePayload: Record<string, unknown> = {
    assigned_service_person_id: servicePerson.id,
    latest_activity: `Assigned to ${servicePerson.name} (${servicePerson.company})`,
  }

  try {
    const { error: updateError } = await supabase
      .from('complaints')
      .update(updatePayload)
      .eq('id', complaintId)

    if (updateError) {
      console.warn('Could not update assigned_service_person_id directly on Supabase:', updateError.message)
    }
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Unknown error'
    console.warn('Supabase update error:', msg)
  }

  // Update memory assignment store for resilience
  getMemoryAssignments()[complaintId] = {
    servicePersonId: servicePerson.id,
  }

  // 6. Record activity in audit trail
  const activityMessage = isReassignment
    ? `Reassigned to ${servicePerson.name} · ${servicePerson.company}`
    : `Assigned to ${servicePerson.name} · ${servicePerson.company}`

  await recordComplaintActivity({
    complaint_id: complaintId,
    service_person_id: servicePerson.id,
    activity_type: isReassignment ? 'reassigned' : 'assigned',
    message: activityMessage,
    metadata: {
      service_person_name: servicePerson.name,
      service_type: servicePerson.service_type,
      company: servicePerson.company,
      whatsapp: servicePerson.whatsapp_number,
    },
  })

  // 7. Dispatch WhatsApp notification
  const whatsappResult = await sendAssignmentWhatsAppMessage(
    {
      id: complaint.id,
      ticket_number: complaint.ticket_number,
      title: complaint.title,
      category: complaint.category,
      priority: complaint.priority,
      building_name: complaint.buildings?.name || 'Anantara Business Tower',
      floor_name: complaint.floors?.name || 'Floor 1',
      area_name: complaint.areas?.name || 'Office 101',
      has_photo: !!complaint.photo_url,
    },
    {
      id: servicePerson.id,
      name: servicePerson.name,
      whatsapp_number: servicePerson.whatsapp_number,
      company: servicePerson.company,
    }
  )

  // 8. Record WhatsApp event in activity audit
  if (whatsappResult.success) {
    await recordComplaintActivity({
      complaint_id: complaintId,
      service_person_id: servicePerson.id,
      activity_type: 'whatsapp_sent',
      message: `Assignment sent via WhatsApp to ${servicePerson.name}`,
      metadata: {
        whatsapp_message_id: whatsappResult.messageId,
        recipient_phone: servicePerson.whatsapp_number,
      },
    })
  } else {
    await recordComplaintActivity({
      complaint_id: complaintId,
      service_person_id: servicePerson.id,
      activity_type: 'whatsapp_sent',
      message: `WhatsApp assignment notification failed to reach ${servicePerson.name}: ${whatsappResult.error || 'Unknown error'}`,
      metadata: {
        error: whatsappResult.error,
        recipient_phone: servicePerson.whatsapp_number,
      },
    })
  }

  return {
    success: true,
    message: `Complaint successfully assigned to ${servicePerson.name}`,
    servicePerson,
    whatsappResult,
  }
}

export async function resendAssignmentWhatsApp(complaintId: string): Promise<AssignmentResult> {
  const supabase = await createClient()

  const { data: complaint } = await supabase
    .from('complaints')
    .select('*, buildings(name), floors(name), areas(name), assets(name, asset_id)')
    .eq('id', complaintId)
    .single()

  if (!complaint) {
    throw new Error('Complaint not found')
  }

  const assignedId =
    complaint.assigned_service_person_id ||
    getMemoryAssignments()[complaintId]?.servicePersonId

  if (!assignedId) {
    throw new Error('Complaint has no assigned service person to notify')
  }

  const servicePerson = await getServicePersonById(assignedId)
  if (!servicePerson) {
    throw new Error('Assigned service person record not found')
  }

  const whatsappResult = await sendAssignmentWhatsAppMessage(
    {
      id: complaint.id,
      ticket_number: complaint.ticket_number,
      title: complaint.title,
      category: complaint.category,
      priority: complaint.priority,
      building_name: complaint.buildings?.name || 'Anantara Business Tower',
      floor_name: complaint.floors?.name || 'Floor 1',
      area_name: complaint.areas?.name || 'Office 101',
      has_photo: !!complaint.photo_url,
    },
    {
      id: servicePerson.id,
      name: servicePerson.name,
      whatsapp_number: servicePerson.whatsapp_number,
      company: servicePerson.company,
    }
  )

  if (whatsappResult.success) {
    await recordComplaintActivity({
      complaint_id: complaintId,
      service_person_id: servicePerson.id,
      activity_type: 'whatsapp_sent',
      message: `Assignment re-sent via WhatsApp to ${servicePerson.name}`,
      metadata: {
        whatsapp_message_id: whatsappResult.messageId,
        recipient_phone: servicePerson.whatsapp_number,
        is_retry: true,
      },
    })
  } else {
    await recordComplaintActivity({
      complaint_id: complaintId,
      service_person_id: servicePerson.id,
      activity_type: 'whatsapp_sent',
      message: `WhatsApp re-send failed for ${servicePerson.name}: ${whatsappResult.error || 'Network error'}`,
      metadata: {
        error: whatsappResult.error,
        recipient_phone: servicePerson.whatsapp_number,
        is_retry: true,
      },
    })
  }

  return {
    success: whatsappResult.success,
    message: whatsappResult.success
      ? `WhatsApp notification resent to ${servicePerson.name}`
      : `WhatsApp delivery failed: ${whatsappResult.error}`,
    servicePerson,
    whatsappResult,
  }
}

export async function getComplaintAssignment(complaintId: string) {
  const supabase = await createClient()

  const { data: complaint } = await supabase
    .from('complaints')
    .select('assigned_service_person_id, latest_service_response, latest_service_response_at')
    .eq('id', complaintId)
    .single()

  const assignedId =
    complaint?.assigned_service_person_id ||
    getMemoryAssignments()[complaintId]?.servicePersonId

  let servicePerson = null
  if (assignedId) {
    servicePerson = await getServicePersonById(assignedId)
  }

  const latestResponse =
    complaint?.latest_service_response ||
    getMemoryAssignments()[complaintId]?.latestResponse

  const latestResponseAt =
    complaint?.latest_service_response_at ||
    getMemoryAssignments()[complaintId]?.latestResponseAt

  return {
    assignedServicePerson: servicePerson,
    latestResponse,
    latestResponseAt,
  }
}
