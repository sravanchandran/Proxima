import { createClient } from '@/lib/supabase/server'
import {
  ComplaintActivityRecord,
  WhatsAppMessageRecord,
  getMemoryActivities,
  getMemoryWhatsAppMessages,
} from './demo-store'

export async function recordComplaintActivity(input: {
  complaint_id: string
  service_person_id?: string | null
  activity_type: ComplaintActivityRecord['activity_type']
  message: string
  metadata?: Record<string, unknown>
}): Promise<ComplaintActivityRecord> {
  const newRecord: ComplaintActivityRecord = {
    id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    complaint_id: input.complaint_id,
    service_person_id: input.service_person_id || null,
    activity_type: input.activity_type,
    message: input.message,
    metadata: input.metadata || {},
    created_at: new Date().toISOString(),
  }

  try {
    const supabase = await createClient()
    const { data, error } = await supabase
      .from('complaint_activities')
      .insert({
        complaint_id: input.complaint_id,
        service_person_id: input.service_person_id || null,
        activity_type: input.activity_type,
        message: input.message,
        metadata: input.metadata || {},
      })
      .select()
      .single()

    if (!error && data) {
      getMemoryActivities().unshift(data as ComplaintActivityRecord)
      return data as ComplaintActivityRecord
    }
  } catch {
    // fallback
  }

  getMemoryActivities().unshift(newRecord)
  return newRecord
}

export async function getComplaintActivities(complaintId: string): Promise<ComplaintActivityRecord[]> {
  try {
    const supabase = await createClient()
    const { data, error } = await supabase
      .from('complaint_activities')
      .select('*')
      .eq('complaint_id', complaintId)
      .order('created_at', { ascending: true })

    if (!error && data && data.length > 0) {
      return data as ComplaintActivityRecord[]
    }
  } catch {
    // fallback
  }

  return getMemoryActivities()
    .filter((a) => a.complaint_id === complaintId)
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
}

export async function recordWhatsAppMessage(input: {
  complaint_id?: string | null
  service_person_id?: string | null
  direction: 'INBOUND' | 'OUTBOUND'
  message_text: string
  whatsapp_message_id?: string
  status: 'SENT' | 'DELIVERED' | 'READ' | 'FAILED' | 'RECEIVED'
  sender_phone?: string
  recipient_phone?: string
  error_message?: string
}): Promise<WhatsAppMessageRecord> {
  const newRecord: WhatsAppMessageRecord = {
    id: `wam-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    complaint_id: input.complaint_id || null,
    service_person_id: input.service_person_id || null,
    direction: input.direction,
    message_text: input.message_text,
    whatsapp_message_id: input.whatsapp_message_id || `wamid.${Date.now()}`,
    status: input.status,
    sender_phone: input.sender_phone,
    recipient_phone: input.recipient_phone,
    error_message: input.error_message,
    created_at: new Date().toISOString(),
  }

  try {
    const supabase = await createClient()
    const { data, error } = await supabase
      .from('whatsapp_messages')
      .insert({
        complaint_id: input.complaint_id || null,
        service_person_id: input.service_person_id || null,
        direction: input.direction,
        message_text: input.message_text,
        whatsapp_message_id: newRecord.whatsapp_message_id,
        status: input.status,
        sender_phone: input.sender_phone,
        recipient_phone: input.recipient_phone,
        error_message: input.error_message,
      })
      .select()
      .single()

    if (!error && data) {
      getMemoryWhatsAppMessages().unshift(data as WhatsAppMessageRecord)
      return data as WhatsAppMessageRecord
    }
  } catch {
    // fallback
  }

  getMemoryWhatsAppMessages().unshift(newRecord)
  return newRecord
}

export async function getWhatsAppMessages(filters?: {
  complaintId?: string
  servicePersonId?: string
  direction?: 'INBOUND' | 'OUTBOUND'
  limit?: number
}): Promise<WhatsAppMessageRecord[]> {
  try {
    const supabase = await createClient()
    let query = supabase.from('whatsapp_messages').select('*').order('created_at', { ascending: false })

    if (filters?.complaintId) query = query.eq('complaint_id', filters.complaintId)
    if (filters?.servicePersonId) query = query.eq('service_person_id', filters.servicePersonId)
    if (filters?.direction) query = query.eq('direction', filters.direction)
    if (filters?.limit) query = query.limit(filters.limit)

    const { data, error } = await query
    if (!error && data && data.length > 0) {
      return data as WhatsAppMessageRecord[]
    }
  } catch {
    // fallback
  }

  let list = getMemoryWhatsAppMessages()
  if (filters?.complaintId) list = list.filter((m) => m.complaint_id === filters.complaintId)
  if (filters?.servicePersonId) list = list.filter((m) => m.service_person_id === filters.servicePersonId)
  if (filters?.direction) list = list.filter((m) => m.direction === filters.direction)

  return list.slice(0, filters?.limit || 50)
}
