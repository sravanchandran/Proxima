import { createClient } from '@/lib/supabase/server'
import {
  ServicePersonRecord,
  getMemoryServicePersons,
} from './demo-store'
import { normalizePhoneNumber, isValidPhoneNumber } from '@/lib/phone'
import { isValidServiceType } from '@/lib/constants/service-types'

export interface ServicePersonFilters {
  query?: string
  serviceType?: string
  status?: 'all' | 'active' | 'inactive'
}

export async function getServicePersons(filters?: ServicePersonFilters): Promise<ServicePersonRecord[]> {
  try {
    const supabase = await createClient()
    let query = supabase.from('service_persons').select('*').order('created_at', { ascending: false })

    if (filters?.serviceType && filters.serviceType !== 'all') {
      query = query.eq('service_type', filters.serviceType)
    }

    if (filters?.status === 'active') {
      query = query.eq('is_active', true)
    } else if (filters?.status === 'inactive') {
      query = query.eq('is_active', false)
    }

    if (filters?.query) {
      const q = filters.query.toLowerCase()
      query = query.or(`name.ilike.%${q}%,company.ilike.%${q}%,whatsapp_number.ilike.%${q}%,service_type.ilike.%${q}%`)
    }

    const { data, error } = await query

    if (error) {
      // Fallback if table not yet in schema cache
      return filterMemoryServicePersons(filters)
    }

    return (data as ServicePersonRecord[]) || []
  } catch {
    return filterMemoryServicePersons(filters)
  }
}

function filterMemoryServicePersons(filters?: ServicePersonFilters): ServicePersonRecord[] {
  let list = getMemoryServicePersons()

  if (filters?.serviceType && filters.serviceType !== 'all') {
    list = list.filter((sp) => sp.service_type.toLowerCase() === filters.serviceType!.toLowerCase())
  }

  if (filters?.status === 'active') {
    list = list.filter((sp) => sp.is_active)
  } else if (filters?.status === 'inactive') {
    list = list.filter((sp) => !sp.is_active)
  }

  if (filters?.query) {
    const q = filters.query.toLowerCase()
    list = list.filter(
      (sp) =>
        sp.name.toLowerCase().includes(q) ||
        sp.company.toLowerCase().includes(q) ||
        sp.service_type.toLowerCase().includes(q) ||
        sp.whatsapp_number.toLowerCase().includes(q)
    )
  }

  return list
}

export async function getActiveServicePersonsByType(serviceType: string): Promise<ServicePersonRecord[]> {
  try {
    const supabase = await createClient()
    const { data, error } = await supabase
      .from('service_persons')
      .select('*')
      .eq('service_type', serviceType)
      .eq('is_active', true)
      .order('name', { ascending: true })

    if (error || !data) {
      return getMemoryServicePersons().filter(
        (sp) => sp.is_active && sp.service_type.toLowerCase() === serviceType.toLowerCase()
      )
    }

    return data as ServicePersonRecord[]
  } catch {
    return getMemoryServicePersons().filter(
      (sp) => sp.is_active && sp.service_type.toLowerCase() === serviceType.toLowerCase()
    )
  }
}

export async function getServicePersonById(id: string): Promise<ServicePersonRecord | null> {
  try {
    const supabase = await createClient()
    const { data, error } = await supabase.from('service_persons').select('*').eq('id', id).single()

    if (error || !data) {
      return getMemoryServicePersons().find((sp) => sp.id === id) || null
    }

    return data as ServicePersonRecord
  } catch {
    return getMemoryServicePersons().find((sp) => sp.id === id) || null
  }
}

export async function findServicePersonByPhone(phone: string): Promise<ServicePersonRecord | null> {
  const normalized = normalizePhoneNumber(phone)
  if (!normalized) return null

  try {
    const supabase = await createClient()
    const { data } = await supabase
      .from('service_persons')
      .select('*')
      .eq('whatsapp_number', normalized)
      .limit(1)

    if (data && data.length > 0) {
      return data[0] as ServicePersonRecord
    }
  } catch {
    // ignore
  }

  return (
    getMemoryServicePersons().find(
      (sp) => normalizePhoneNumber(sp.whatsapp_number) === normalized
    ) || null
  )
}

export interface CreateServicePersonInput {
  name: string
  service_type: string
  company: string
  whatsapp_number: string
  is_active?: boolean
}

export async function createServicePerson(input: CreateServicePersonInput): Promise<ServicePersonRecord> {
  const name = input.name.trim()
  const service_type = input.service_type.trim()
  const company = input.company.trim()
  const normalizedPhone = normalizePhoneNumber(input.whatsapp_number)

  if (!name) throw new Error('Service person name is required')
  if (!isValidServiceType(service_type)) {
    throw new Error(`Invalid service type. Must be one of the standardized service types.`)
  }
  if (!company) throw new Error('Company name is required')
  if (!isValidPhoneNumber(normalizedPhone)) {
    throw new Error('Please provide a valid international phone number (e.g. +971501234567)')
  }

  const is_active = input.is_active !== undefined ? input.is_active : true
  const now = new Date().toISOString()
  const newRecord: ServicePersonRecord = {
    id: `sp-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    name,
    service_type,
    company,
    whatsapp_number: normalizedPhone,
    is_active,
    created_at: now,
    updated_at: now,
  }

  try {
    const supabase = await createClient()
    const { data, error } = await supabase
      .from('service_persons')
      .insert({
        name,
        service_type,
        company,
        whatsapp_number: normalizedPhone,
        is_active,
      })
      .select()
      .single()

    if (!error && data) {
      getMemoryServicePersons().unshift(data as ServicePersonRecord)
      return data as ServicePersonRecord
    }
  } catch {
    // fallback
  }

  getMemoryServicePersons().unshift(newRecord)
  return newRecord
}

export async function updateServicePerson(
  id: string,
  input: Partial<CreateServicePersonInput>
): Promise<ServicePersonRecord> {
  const existing = await getServicePersonById(id)
  if (!existing) throw new Error('Service person not found')

  const updates: Partial<ServicePersonRecord> = {
    updated_at: new Date().toISOString(),
  }

  if (input.name !== undefined) {
    if (!input.name.trim()) throw new Error('Name cannot be empty')
    updates.name = input.name.trim()
  }

  if (input.service_type !== undefined) {
    if (!isValidServiceType(input.service_type.trim())) {
      throw new Error('Invalid service type')
    }
    updates.service_type = input.service_type.trim()
  }

  if (input.company !== undefined) {
    if (!input.company.trim()) throw new Error('Company cannot be empty')
    updates.company = input.company.trim()
  }

  if (input.whatsapp_number !== undefined) {
    const norm = normalizePhoneNumber(input.whatsapp_number)
    if (!isValidPhoneNumber(norm)) {
      throw new Error('Invalid phone number format')
    }
    updates.whatsapp_number = norm
  }

  if (input.is_active !== undefined) {
    updates.is_active = input.is_active
  }

  try {
    const supabase = await createClient()
    const { data, error } = await supabase
      .from('service_persons')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (!error && data) {
      const idx = getMemoryServicePersons().findIndex((s) => s.id === id)
      if (idx !== -1) getMemoryServicePersons()[idx] = data as ServicePersonRecord
      return data as ServicePersonRecord
    }
  } catch {
    // fallback
  }

  const memoryList = getMemoryServicePersons()
  const idx = memoryList.findIndex((s) => s.id === id)
  if (idx !== -1) {
    memoryList[idx] = { ...memoryList[idx], ...updates }
    return memoryList[idx]
  }

  return { ...existing, ...updates }
}

export async function toggleServicePersonStatus(id: string, isActive: boolean): Promise<ServicePersonRecord> {
  return updateServicePerson(id, { is_active: isActive })
}
