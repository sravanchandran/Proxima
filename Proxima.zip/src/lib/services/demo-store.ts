import { normalizePhoneNumber } from '@/lib/phone'

export interface ServicePersonRecord {
  id: string
  name: string
  service_type: string
  company: string
  whatsapp_number: string
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface ComplaintActivityRecord {
  id: string
  complaint_id: string
  service_person_id: string | null
  activity_type: 'created' | 'assigned' | 'reassigned' | 'whatsapp_sent' | 'whatsapp_received' | 'status_changed' | 'note_added'
  message: string
  metadata?: Record<string, unknown>
  created_at: string
}

export interface WhatsAppMessageRecord {
  id: string
  complaint_id: string | null
  service_person_id: string | null
  direction: 'INBOUND' | 'OUTBOUND'
  message_text: string
  whatsapp_message_id?: string
  status: 'SENT' | 'DELIVERED' | 'READ' | 'FAILED' | 'RECEIVED'
  sender_phone?: string
  recipient_phone?: string
  error_message?: string
  created_at: string
}

export const INITIAL_SERVICE_PERSONS: ServicePersonRecord[] = [
  {
    id: 'sp-101-hvac-ahmed',
    name: 'Ahmed Khan',
    service_type: 'HVAC',
    company: 'CoolTech Services',
    whatsapp_number: normalizePhoneNumber('+971501234567'),
    is_active: true,
    created_at: new Date(Date.now() - 30 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 30 * 86400000).toISOString(),
  },
  {
    id: 'sp-102-hvac-raj',
    name: 'Raj Kumar',
    service_type: 'HVAC',
    company: 'Dubai Climate Solutions',
    whatsapp_number: normalizePhoneNumber('+971502345678'),
    is_active: true,
    created_at: new Date(Date.now() - 28 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 28 * 86400000).toISOString(),
  },
  {
    id: 'sp-103-plumb-ali',
    name: 'Ali Hassan',
    service_type: 'Plumbing',
    company: 'Dubai Plumbing LLC',
    whatsapp_number: normalizePhoneNumber('+971503456789'),
    is_active: true,
    created_at: new Date(Date.now() - 25 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 25 * 86400000).toISOString(),
  },
  {
    id: 'sp-104-plumb-tariq',
    name: 'Tariq Mahmoud',
    service_type: 'Plumbing',
    company: 'FlowMaster Services',
    whatsapp_number: normalizePhoneNumber('+971504567890'),
    is_active: true,
    created_at: new Date(Date.now() - 20 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 20 * 86400000).toISOString(),
  },
  {
    id: 'sp-105-elec-john',
    name: 'John Mathew',
    service_type: 'Electrical',
    company: 'PowerCare Services',
    whatsapp_number: normalizePhoneNumber('+971505678901'),
    is_active: true,
    created_at: new Date(Date.now() - 22 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 22 * 86400000).toISOString(),
  },
  {
    id: 'sp-106-elec-vikram',
    name: 'Vikram Singh',
    service_type: 'Electrical',
    company: 'Apex Electrical LLC',
    whatsapp_number: normalizePhoneNumber('+971506789012'),
    is_active: true,
    created_at: new Date(Date.now() - 15 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 15 * 86400000).toISOString(),
  },
  {
    id: 'sp-107-fire-fatima',
    name: 'Fatima Ali',
    service_type: 'Fire Safety',
    company: 'SafeGuard Fire Systems',
    whatsapp_number: normalizePhoneNumber('+971507890123'),
    is_active: true,
    created_at: new Date(Date.now() - 18 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 18 * 86400000).toISOString(),
  },
  {
    id: 'sp-108-clean-elena',
    name: 'Elena Rostova',
    service_type: 'Cleaning',
    company: 'CleanSpark Facilities',
    whatsapp_number: normalizePhoneNumber('+971508901234'),
    is_active: true,
    created_at: new Date(Date.now() - 10 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 10 * 86400000).toISOString(),
  },
  {
    id: 'sp-109-gen-omar',
    name: 'Omar Farooq',
    service_type: 'General Maintenance',
    company: 'PrimeFix Solutions',
    whatsapp_number: normalizePhoneNumber('+971509012345'),
    is_active: false, // Inactive for testing filtering
    created_at: new Date(Date.now() - 40 * 86400000).toISOString(),
    updated_at: new Date(Date.now() - 5 * 86400000).toISOString(),
  },
]

// Global in-memory fallback stores (persisted during process lifetime)
declare global {
  var __proxima_service_persons: ServicePersonRecord[] | undefined
  var __proxima_complaint_assignments: Record<string, {
    servicePersonId: string
    latestResponse?: string
    latestResponseAt?: string
  }> | undefined
  var __proxima_complaint_activities: ComplaintActivityRecord[] | undefined
  var __proxima_whatsapp_messages: WhatsAppMessageRecord[] | undefined
}

export function getMemoryServicePersons(): ServicePersonRecord[] {
  if (!globalThis.__proxima_service_persons) {
    globalThis.__proxima_service_persons = [...INITIAL_SERVICE_PERSONS]
  }
  return globalThis.__proxima_service_persons
}

export function getMemoryAssignments() {
  if (!globalThis.__proxima_complaint_assignments) {
    globalThis.__proxima_complaint_assignments = {}
  }
  return globalThis.__proxima_complaint_assignments
}

export function getMemoryActivities(): ComplaintActivityRecord[] {
  if (!globalThis.__proxima_complaint_activities) {
    globalThis.__proxima_complaint_activities = []
  }
  return globalThis.__proxima_complaint_activities
}

export function getMemoryWhatsAppMessages(): WhatsAppMessageRecord[] {
  if (!globalThis.__proxima_whatsapp_messages) {
    globalThis.__proxima_whatsapp_messages = []
  }
  return globalThis.__proxima_whatsapp_messages
}
