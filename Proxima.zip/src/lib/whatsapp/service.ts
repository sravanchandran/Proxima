import { recordWhatsAppMessage } from '@/lib/services/whatsapp-messages'
import { normalizePhoneNumber } from '@/lib/phone'

export interface WhatsAppSendResult {
  success: boolean
  messageId?: string
  status: 'SENT' | 'FAILED'
  error?: string
  messageText: string
}

export interface ComplaintContextForWhatsApp {
  id: string
  ticket_number: string
  title: string
  category: string
  priority: string
  building_name?: string
  floor_name?: string
  area_name?: string
  has_photo?: boolean
}

export interface ServicePersonForWhatsApp {
  id: string
  name: string
  whatsapp_number: string
  company: string
}

export function formatAssignmentMessage(
  complaint: ComplaintContextForWhatsApp,
  servicePerson: ServicePersonForWhatsApp
): string {
  const firstName = servicePerson.name.split(' ')[0] || servicePerson.name
  const location = [complaint.floor_name, complaint.area_name].filter(Boolean).join(' / ') || 'Designated Facility Area'
  const building = complaint.building_name || 'Anantara Business Tower'
  const photoNote = complaint.has_photo ? '\nPhoto Attachment: Photographic evidence attached in ticket' : ''

  return `Hello ${firstName},

A new service complaint has been assigned to you.

Complaint: ${complaint.ticket_number}
Issue: ${complaint.title}
Category: ${complaint.category}
Priority: ${complaint.priority}
Location: ${location}
Building: ${building}${photoNote}

Please review the issue and reply with an update.

PROXIMA Facilities`
}

export async function sendAssignmentWhatsAppMessage(
  complaint: ComplaintContextForWhatsApp,
  servicePerson: ServicePersonForWhatsApp
): Promise<WhatsAppSendResult> {
  const messageText = formatAssignmentMessage(complaint, servicePerson)
  const recipientPhone = normalizePhoneNumber(servicePerson.whatsapp_number)

  const accessToken = process.env.WHATSAPP_ACCESS_TOKEN
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID

  // Check if live Meta WhatsApp credentials are provided
  const isMetaConfigured =
    accessToken &&
    phoneNumberId &&
    !accessToken.includes('your_whatsapp') &&
    !phoneNumberId.includes('your_whatsapp')

  if (isMetaConfigured) {
    try {
      // Remove leading + for Meta API recipient
      const metaTo = recipientPhone.replace(/^\+/, '')

      const res = await fetch(`https://graph.facebook.com/v22.0/${phoneNumberId}/messages`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: metaTo,
          type: 'text',
          text: { body: messageText },
        }),
      })

      const data = await res.json()

      if (!res.ok || data.error) {
        const errorMsg = data.error?.message || `Meta API returned HTTP ${res.status}`
        console.error('Meta WhatsApp API dispatch failed:', errorMsg)

        await recordWhatsAppMessage({
          complaint_id: complaint.id,
          service_person_id: servicePerson.id,
          direction: 'OUTBOUND',
          message_text: messageText,
          status: 'FAILED',
          recipient_phone: recipientPhone,
          error_message: errorMsg,
        })

        return {
          success: false,
          status: 'FAILED',
          error: errorMsg,
          messageText,
        }
      }

      const wamid = data.messages?.[0]?.id || `wamid.meta.${Date.now()}`

      await recordWhatsAppMessage({
        complaint_id: complaint.id,
        service_person_id: servicePerson.id,
        direction: 'OUTBOUND',
        message_text: messageText,
        whatsapp_message_id: wamid,
        status: 'SENT',
        recipient_phone: recipientPhone,
      })

      return {
        success: true,
        messageId: wamid,
        status: 'SENT',
        messageText,
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : 'Network error reaching WhatsApp API'
      console.error('Network error calling Meta WhatsApp API:', errorMsg)

      await recordWhatsAppMessage({
        complaint_id: complaint.id,
        service_person_id: servicePerson.id,
        direction: 'OUTBOUND',
        message_text: messageText,
        status: 'FAILED',
        recipient_phone: recipientPhone,
        error_message: errorMsg,
      })

      return {
        success: false,
        status: 'FAILED',
        error: errorMsg,
        messageText,
      }
    }
  }

  // Demo Environment Mode: Meta credentials not live, simulate successful dispatch
  const simulatedMessageId = `wamid.demo.${Date.now()}.${Math.random().toString(36).substring(2, 7)}`

  await recordWhatsAppMessage({
    complaint_id: complaint.id,
    service_person_id: servicePerson.id,
    direction: 'OUTBOUND',
    message_text: messageText,
    whatsapp_message_id: simulatedMessageId,
    status: 'SENT',
    recipient_phone: recipientPhone,
  })

  return {
    success: true,
    messageId: simulatedMessageId,
    status: 'SENT',
    messageText,
  }
}
