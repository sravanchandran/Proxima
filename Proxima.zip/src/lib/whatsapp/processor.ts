import { createClient } from '@supabase/supabase-js'

// Service role client to perform system-level ingestion without active user session
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

export interface WhatsAppMessageInput {
  text: string
  senderName?: string
  senderPhone?: string
  senderRole?: string
  photoUrl?: string
  whatsappMessageId?: string
}

export interface ProcessingMilestone {
  step: number
  title: string
  detail: string
  timestamp: string
}

export interface WhatsAppProcessingResult {
  success: boolean
  complaint: {
    id: string
    ticket_number: string
    title: string
    description: string
    category: string
    priority: string
    status: string
    source: string
    photo_url: string | null
    created_at: string
    building_name?: string
    floor_name?: string
    area_name?: string
    asset_name?: string
    asset_tag?: string
  }
  isDuplicate?: boolean
  processingSteps: ProcessingMilestone[]
}

export async function processWhatsAppMessage(input: WhatsAppMessageInput): Promise<WhatsAppProcessingResult> {
  const now = new Date()
  const timestampStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })

  const senderName = input.senderName || 'Ahmed'
  const senderRole = input.senderRole || 'Field Technician'
  const senderPhone = input.senderPhone || '+971 50 849 2011'
  const text = input.text.trim()
  const messageId = input.whatsappMessageId || `wamid.${Date.now()}.${Math.random().toString(36).substring(2, 7)}`

  const steps: ProcessingMilestone[] = [
    {
      step: 1,
      title: 'WhatsApp Gateway Ingestion',
      detail: `Received text message from ${senderName} (${senderPhone}) via WhatsApp Cloud API. Payload ID: ${messageId.substring(0, 16)}...`,
      timestamp: timestampStr,
    }
  ]

  // 1. Check for duplicate ingestion within 30 seconds
  const thirtySecondsAgo = new Date(Date.now() - 30 * 1000).toISOString()
  const { data: recentDuplicates } = await supabase
    .from('complaints')
    .select('id, ticket_number, title, description, category, priority, status, source, photo_url, created_at')
    .eq('source', 'WhatsApp')
    .gte('created_at', thirtySecondsAgo)
    .ilike('description', `%${text.substring(0, 30)}%`)
    .limit(1)

  if (recentDuplicates && recentDuplicates.length > 0) {
    const existing = recentDuplicates[0]
    steps.push({
      step: 2,
      title: 'Duplicate Message Filtered',
      detail: `Identical message received within cooldown window. Linked to existing ticket ${existing.ticket_number}.`,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    })
    return {
      success: true,
      complaint: existing,
      isDuplicate: true,
      processingSteps: steps,
    }
  }

  // 2. Fetch building context (Anantara Business Tower default)
  const { data: buildings } = await supabase.from('buildings').select('id, name').limit(1)
  const building = buildings?.[0]
  const buildingId = building?.id

  // 3. Fetch floors and areas for entity resolution
  const { data: floors } = await supabase.from('floors').select('id, name, level')
  const { data: areas } = await supabase.from('areas').select('id, name, floor_id')
  const { data: assets } = await supabase.from('assets').select('id, asset_id, name, category, floor_id, area_id')

  // 4. Entity resolution (Locations and Assets)
  let matchedFloor = floors?.find(f => f.name.toLowerCase().includes('floor 1') || f.name.toLowerCase().includes('level 1'))
  let matchedArea = areas?.find(a => a.name.toLowerCase().includes('office 101'))
  let matchedAsset = assets?.find(a => a.asset_id === 'AST-001' || a.name.toLowerCase().includes('split ac'))

  const lowerText = text.toLowerCase()

  // Location heuristics
  if (lowerText.includes('lobby') || lowerText.includes('ground')) {
    matchedFloor = floors?.find(f => f.name.toLowerCase().includes('ground')) || matchedFloor
    matchedArea = areas?.find(a => a.name.toLowerCase().includes('lobby')) || matchedArea
  } else if (lowerText.includes('plant') || lowerText.includes('basement') || lowerText.includes('b1')) {
    matchedFloor = floors?.find(f => f.name.toLowerCase().includes('basement')) || matchedFloor
    matchedArea = areas?.find(a => a.name.toLowerCase().includes('plant')) || matchedArea
  } else if (lowerText.includes('office 201') || lowerText.includes('floor 2')) {
    matchedFloor = floors?.find(f => f.name.toLowerCase().includes('floor 2')) || matchedFloor
    matchedArea = areas?.find(a => a.name.toLowerCase().includes('office 201')) || matchedArea
  }

  // Asset heuristics
  if (lowerText.includes('pump') || lowerText.includes('water') || lowerText.includes('leak')) {
    const pumpAsset = assets?.find(a => a.asset_id === 'AST-002' || a.name.toLowerCase().includes('pump'))
    if (pumpAsset) matchedAsset = pumpAsset
  } else if (lowerText.includes('fire') || lowerText.includes('extinguisher')) {
    const fireAsset = assets?.find(a => a.asset_id === 'AST-003')
    if (fireAsset) matchedAsset = fireAsset
  } else if (lowerText.includes('generator')) {
    const genAsset = assets?.find(a => a.asset_id === 'AST-008')
    if (genAsset) matchedAsset = genAsset
  }

  // Ensure floor/area sync with asset if asset found
  if (matchedAsset?.floor_id && matchedAsset?.area_id) {
    matchedFloor = floors?.find(f => f.id === matchedAsset!.floor_id) || matchedFloor
    matchedArea = areas?.find(a => a.id === matchedAsset!.area_id) || matchedArea
  }

  steps.push({
    step: 2,
    title: 'Context & Entity Resolution',
    detail: `Matched Building: ${building?.name || 'Anantara Business Tower'} · Location: ${matchedFloor?.name || 'Floor 1'} / ${matchedArea?.name || 'Office 101'} · Target Asset: ${matchedAsset?.asset_id || 'AST-001'} (${matchedAsset?.name || 'Split AC Unit'})`,
    timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  })

  // 5. Priority & Category determination
  let category = 'HVAC'
  if (lowerText.includes('leak') || lowerText.includes('plumb') || lowerText.includes('pipe') || lowerText.includes('pump')) {
    category = 'Plumbing'
  } else if (lowerText.includes('power') || lowerText.includes('electric') || lowerText.includes('light')) {
    category = 'Electrical'
  } else if (lowerText.includes('fire') || lowerText.includes('safety') || lowerText.includes('smoke')) {
    category = 'Fire Safety'
  } else if (matchedAsset?.category) {
    category = matchedAsset.category
  }

  let priority = 'High'
  if (lowerText.includes('critical') || lowerText.includes('emergency') || lowerText.includes('flood') || lowerText.includes('danger')) {
    priority = 'Critical'
  } else if (lowerText.includes('low') || lowerText.includes('minor') || lowerText.includes('routine')) {
    priority = 'Low'
  } else if (lowerText.includes('medium') || lowerText.includes('when possible')) {
    priority = 'Medium'
  }

  // Check structured fields if provided (e.g. "Priority: High")
  const lines = text.split('\n')
  lines.forEach(line => {
    const l = line.toLowerCase()
    if (l.startsWith('priority:')) {
      const p = line.substring(9).trim()
      if (['Low', 'Medium', 'High', 'Critical'].includes(p)) priority = p
    } else if (l.startsWith('category:')) {
      category = line.substring(9).trim()
    }
  })

  steps.push({
    step: 3,
    title: 'SLA & Priority Assessment',
    detail: `Category classified as ${category}. Operational priority flagged as ${priority} based on urgent temperature escalation report.`,
    timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  })

  // 6. Title generation
  let title = 'AC not cooling in Office 101'
  if (lowerText.includes('not cooling') || lowerText.includes('warm') || lowerText.includes('temperature')) {
    title = `AC not cooling in ${matchedArea?.name || 'Office 101'}`
  } else if (lowerText.includes('leak')) {
    title = `Water leak reported in ${matchedArea?.name || 'Facility area'}`
  } else {
    // First non-empty line up to 60 chars
    const firstLine = lines.find(l => l.trim().length > 0 && !l.toLowerCase().startsWith('priority:') && !l.toLowerCase().startsWith('location:'))
    if (firstLine) {
      title = firstLine.length > 55 ? `${firstLine.substring(0, 52)}...` : firstLine
    }
  }

  // 7. Ticket number generation: CMP-XXX
  // Count existing to generate sequential or clean ticket number
  const { count: totalComplaints } = await supabase.from('complaints').select('*', { count: 'exact', head: true })
  const nextNumber = ((totalComplaints || 0) + 1).toString().padStart(3, '0')
  const ticket_number = `CMP-${nextNumber}`

  // 8. Photo URL attachment
  let finalPhotoUrl = input.photoUrl || null
  if (!finalPhotoUrl && (lowerText.includes('ac') || lowerText.includes('cooling'))) {
    finalPhotoUrl = '/demo/ac-room-101.jpg'
  }

  // 9. Structured metadata storage in updated_description
  const metadataPayload = {
    senderName,
    senderRole,
    senderPhone,
    whatsappMessageId: messageId,
    receivedAt: now.toISOString(),
    originalMessage: text,
    channel: 'WhatsApp Cloud API',
  }

  // 10. Database commit
  const { data: newComplaint, error } = await supabase
    .from('complaints')
    .insert({
      ticket_number,
      title,
      description: text,
      category,
      priority,
      priority_code: priority === 'Critical' ? 'P1' : priority === 'High' ? 'P2' : 'P3',
      source: 'WhatsApp',
      status: 'Open',
      building_id: buildingId,
      floor_id: matchedFloor?.id || null,
      area_id: matchedArea?.id || null,
      asset_id: matchedAsset?.id || null,
      photo_url: finalPhotoUrl,
      latest_activity: `Reported via WhatsApp by ${senderName} (${senderRole})`,
      updated_description: JSON.stringify(metadataPayload),
    })
    .select('*, buildings(name), floors(name), areas(name), assets(asset_id, name)')
    .single()

  if (error) {
    console.error('Failed to commit WhatsApp complaint to Supabase:', error)
    throw new Error(`Database error creating complaint: ${error.message}`)
  }

  steps.push({
    step: 4,
    title: 'Database Commit & Ticket Created',
    detail: `Committed ticket ${newComplaint.ticket_number} with status "Open". Linked to Asset ${matchedAsset?.asset_id || 'AST-001'} in ${matchedArea?.name || 'Office 101'}.`,
    timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  })

  return {
    success: true,
    complaint: {
      ...newComplaint,
      building_name: building?.name || 'Anantara Business Tower',
      floor_name: matchedFloor?.name || 'Floor 1',
      area_name: matchedArea?.name || 'Office 101',
      asset_name: matchedAsset?.name || 'Split AC Unit',
      asset_tag: matchedAsset?.asset_id || 'AST-001',
    },
    processingSteps: steps,
  }
}
