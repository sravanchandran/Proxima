import { createClient } from '@supabase/supabase-js'
import { findServicePersonByPhone } from '@/lib/services/service-persons'
import { recordWhatsAppMessage, recordComplaintActivity } from '@/lib/services/whatsapp-messages'
import { getMemoryAssignments, ServicePersonRecord } from '@/lib/services/demo-store'
import { normalizePhoneNumber } from '@/lib/phone'
import { processWhatsAppMessage, WhatsAppMessageInput, WhatsAppProcessingResult } from './processor'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

export interface InboundProcessingResult {
  type: 'SERVICE_PERSON_REPLY' | 'NEW_COMPLAINT' | 'UNMATCHED_REPLY'
  success: boolean
  complaint?: Record<string, unknown>
  servicePerson?: ServicePersonRecord
  messageText: string
  newComplaintResult?: WhatsAppProcessingResult
}

export async function handleInboundWhatsApp(input: WhatsAppMessageInput): Promise<InboundProcessingResult> {
  const text = input.text.trim()
  const rawSenderPhone = input.senderPhone || '+971 50 849 2011'
  const normalizedPhone = normalizePhoneNumber(rawSenderPhone)

  // 1. Check if sender is a registered service person
  const servicePerson = await findServicePersonByPhone(normalizedPhone)

  if (servicePerson) {
    // 2. Deterministic matching to a complaint
    let matchedComplaint: Record<string, unknown> | null = null

    // Heuristic A: Look for ticket reference in text (e.g. CMP-001, CMP-010)
    const ticketMatch = text.match(/\b(CMP-\d+)\b/i)
    if (ticketMatch) {
      const ticketNumber = ticketMatch[1].toUpperCase()
      const { data: byTicket } = await supabase
        .from('complaints')
        .select('*, buildings(name), floors(name), areas(name), assets(name, asset_id)')
        .eq('ticket_number', ticketNumber)
        .limit(1)

      if (byTicket && byTicket.length > 0) {
        matchedComplaint = byTicket[0]
      }
    }

    // Heuristic B: If no ticket in text, match to latest active assigned complaint for this service person
    if (!matchedComplaint) {
      // Check memory assignments first
      const memAssignments = getMemoryAssignments()
      const assignedCompIds = Object.entries(memAssignments)
        .filter(([, val]) => val.servicePersonId === servicePerson.id)
        .map(([cId]) => cId)

      // Query database for complaints assigned to this service person that are not Closed
      const { data: activeAssigned } = await supabase
        .from('complaints')
        .select('*, buildings(name), floors(name), areas(name), assets(name, asset_id)')
        .eq('assigned_service_person_id', servicePerson.id)
        .neq('status', 'Closed')
        .order('created_at', { ascending: false })
        .limit(1)

      if (activeAssigned && activeAssigned.length > 0) {
        matchedComplaint = activeAssigned[0]
      } else if (assignedCompIds.length > 0) {
        // Find latest from memory assignments
        const targetId = assignedCompIds[assignedCompIds.length - 1]
        const { data: fromId } = await supabase
          .from('complaints')
          .select('*, buildings(name), floors(name), areas(name), assets(name, asset_id)')
          .eq('id', targetId)
          .single()
        if (fromId) matchedComplaint = fromId
      }
    }

    // Heuristic C: Fallback for demo - if there is any active complaint in the DB, match the most recent Open/In Progress
    if (!matchedComplaint) {
      const { data: recentOpen } = await supabase
        .from('complaints')
        .select('*, buildings(name), floors(name), areas(name), assets(name, asset_id)')
        .in('status', ['Open', 'In Progress'])
        .order('created_at', { ascending: false })
        .limit(1)

      if (recentOpen && recentOpen.length > 0) {
        matchedComplaint = recentOpen[0]
      }
    }

    if (!matchedComplaint) {
      // Record as unmatched inbound message for review
      await recordWhatsAppMessage({
        direction: 'INBOUND',
        message_text: text,
        whatsapp_message_id: input.whatsappMessageId,
        status: 'RECEIVED',
        sender_phone: normalizedPhone,
        service_person_id: servicePerson.id,
      })

      return {
        type: 'UNMATCHED_REPLY',
        success: true,
        servicePerson,
        messageText: text,
      }
    }

    const complaintId = matchedComplaint.id as string
    const nowIso = new Date().toISOString()

    // 3. Record inbound message
    await recordWhatsAppMessage({
      complaint_id: complaintId,
      service_person_id: servicePerson.id,
      direction: 'INBOUND',
      message_text: text,
      whatsapp_message_id: input.whatsappMessageId,
      status: 'RECEIVED',
      sender_phone: normalizedPhone,
    })

    // 4. Record complaint activity in timeline
    await recordComplaintActivity({
      complaint_id: complaintId,
      service_person_id: servicePerson.id,
      activity_type: 'whatsapp_received',
      message: `${servicePerson.name} replied: "${text}"`,
      metadata: {
        channel: 'WhatsApp',
        sender_phone: normalizedPhone,
        company: servicePerson.company,
      },
    })

    // 5. Update complaint metadata in Supabase
    try {
      await supabase
        .from('complaints')
        .update({
          latest_service_response: text,
          latest_service_response_at: nowIso,
          latest_service_response_by: servicePerson.id,
          latest_activity: `Service response received from ${servicePerson.name}`,
        })
        .eq('id', complaintId)
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Unknown error'
      console.warn('Could not update response fields on Supabase:', msg)
    }

    // Update memory assignments
    const memAssignments = getMemoryAssignments()
    if (!memAssignments[complaintId]) {
      memAssignments[complaintId] = { servicePersonId: servicePerson.id }
    }
    memAssignments[complaintId].latestResponse = text
    memAssignments[complaintId].latestResponseAt = nowIso

    return {
      type: 'SERVICE_PERSON_REPLY',
      success: true,
      complaint: {
        ...matchedComplaint,
        latest_service_response: text,
        latest_service_response_at: nowIso,
      },
      servicePerson,
      messageText: text,
    }
  }

  // 2. Sender is NOT a Service Person -> Existing Field Staff complaint creation flow
  const newCompResult = await processWhatsAppMessage(input)

  // Record creation activity
  if (newCompResult.success && newCompResult.complaint?.id) {
    await recordComplaintActivity({
      complaint_id: newCompResult.complaint.id,
      activity_type: 'created',
      message: `Complaint created from WhatsApp by ${input.senderName || 'Field Staff'} (${input.senderPhone || rawSenderPhone})`,
      metadata: {
        channel: 'WhatsApp',
        source: 'Hotline',
      },
    })
  }

  return {
    type: 'NEW_COMPLAINT',
    success: newCompResult.success,
    complaint: newCompResult.complaint,
    newComplaintResult: newCompResult,
    messageText: text,
  }
}
