'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard,
  Building2,
  Package,
  MessageSquare,
  Layers,
  ChevronRight,
  MessageCircle,
  UserCheck,
} from 'lucide-react'

const navSections = [
  {
    label: 'Command',
    items: [
      { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    ],
  },
  {
    label: 'Operations',
    items: [
      { href: '/complaints', label: 'Complaints', icon: MessageSquare },
      { href: '/whatsapp', label: 'WhatsApp', icon: MessageCircle, isWhatsApp: true },
      { href: '/assets', label: 'Asset Register', icon: Package },
      { href: '/buildings', label: 'Buildings & Floors', icon: Building2 },
    ],
  },
  {
    label: 'Administration',
    items: [
      { href: '/service-persons', label: 'Service Persons', icon: UserCheck },
    ],
  },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <div className="flex flex-col h-full bg-[#0F172A] border-r border-[#1E293B]">
      {/* Brand Wordmark */}
      <div className="h-16 flex items-center px-5 border-b border-[#1E293B] shrink-0">
        <Link href="/dashboard" className="flex items-center gap-2.5 group">
          <div className="h-8 w-8 bg-[#4F46E5] rounded-lg flex items-center justify-center text-white shadow-sm group-hover:bg-indigo-500 transition-colors shrink-0">
            <Layers className="h-4 w-4" />
          </div>
          <div>
            <span className="font-bold text-white text-base tracking-tight leading-none block">PROXIMA</span>
            <span className="text-[10px] uppercase font-semibold tracking-widest text-slate-400 block mt-0.5">
              Facilities OS
            </span>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-5 space-y-6 overflow-y-auto">
        {navSections.map((section) => (
          <div key={section.label}>
            <p className="px-3 mb-2 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              {section.label}
            </p>
            <div className="space-y-1">
              {section.items.map((item) => {
                const active = pathname === item.href || (item.href !== '/dashboard' && pathname.startsWith(item.href))
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      'flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold transition-all duration-150',
                      active
                        ? 'bg-[#4F46E5] text-white shadow-sm'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                    )}
                  >
                    <div className="flex items-center gap-2.5">
                      {item.isWhatsApp ? (
                        <span className={cn(
                          'h-4 w-4 flex items-center justify-center rounded-full text-[10px]',
                          active ? 'text-white' : 'text-emerald-400'
                        )}>
                          <MessageCircle className="h-4 w-4" />
                        </span>
                      ) : (
                        <item.icon
                          className={cn(
                            'h-4 w-4 shrink-0',
                            active ? 'text-white' : 'text-slate-400'
                          )}
                        />
                      )}
                      <span>{item.label}</span>
                    </div>

                    {item.isWhatsApp && !active && (
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                    )}

                    {active && <ChevronRight className="h-3 w-3 text-indigo-200" />}
                  </Link>
                )
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Building Context Footer */}
      <div className="p-3 border-t border-[#1E293B] shrink-0">
        <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="h-7 w-7 rounded-md bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
              <Building2 className="h-3.5 w-3.5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-white truncate">Anantara Tower</p>
              <p className="text-[10px] text-slate-400 truncate">Downtown Dubai, UAE</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
