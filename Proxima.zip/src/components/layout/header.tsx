'use client'

import { Bell, LogOut, Settings, Building2 } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { logout } from '@/app/login/actions'

export function Header() {
  return (
    <header className="h-16 shrink-0 flex items-center justify-between px-6 bg-white border-b border-[#E2E8F0] z-10">
      {/* Left: Building + Operational Status */}
      <div className="flex items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <p className="text-sm font-bold text-[#172033] leading-none">Anantara Business Tower</p>
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-semibold">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live Operational
            </span>
          </div>
          <p className="text-xs text-[#667085] mt-1 flex items-center gap-1">
            <Building2 className="h-3 w-3 text-slate-400" />
            Downtown Dubai, UAE · Facility Management HQ
          </p>
        </div>
      </div>

      {/* Right: Actions & User */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          aria-label="Notifications"
          className="relative h-9 w-9 rounded-lg border border-[#E2E8F0] bg-white flex items-center justify-center text-[#667085] hover:text-[#172033] hover:bg-slate-50 transition-colors cursor-pointer"
        >
          <Bell className="h-4 w-4" />
          <span className="absolute top-2 right-2 h-1.5 w-1.5 rounded-full bg-red-500" />
        </button>

        <DropdownMenu>
          <DropdownMenuTrigger className="flex items-center gap-2.5 h-9 pl-2 pr-3 rounded-lg border border-[#E2E8F0] bg-white hover:bg-slate-50 transition-colors outline-none cursor-pointer">
            <div className="h-6 w-6 rounded-md bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center text-xs font-bold shrink-0">
              MG
            </div>
            <div className="text-left hidden sm:block">
              <p className="text-xs font-semibold text-[#172033] leading-none">Facility Manager</p>
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48 rounded-xl p-1 shadow-md border border-[#E2E8F0]">
            <DropdownMenuItem className="rounded-lg text-xs gap-2.5 text-[#172033] font-medium cursor-pointer">
              <Settings className="h-3.5 w-3.5 text-[#667085]" /> Facility Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="rounded-lg text-xs gap-2.5 text-red-600 focus:text-red-700 focus:bg-red-50 cursor-pointer font-medium"
              onClick={() => logout()}
            >
              <LogOut className="h-3.5 w-3.5" /> Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
