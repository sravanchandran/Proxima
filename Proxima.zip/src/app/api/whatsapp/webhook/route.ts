import { NextResponse } from 'next/server'
import { handleInboundWhatsApp } from '@/lib/whatsapp/inbound-handler'

export async function GET(request: Request) {
  const url = new URL(request.url)
  const mode = url.searchParams.get('hub.mode')
  const token = url.searchParams.get('hub.verify_token')
  const challenge = url.searchParams.get('hub.challenge')

  const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN

  if (mode === 'subscribe' && token === verifyToken) {
    return new NextResponse(challenge, { status: 200 })
  }

  return new NextResponse('Forbidden', { status: 403 })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    if (body.object !== 'whatsapp_business_account') {
      return new NextResponse('Not a WhatsApp Event', { status: 404 })
    }

    const entry = body.entry?.[0]
    const changes = entry?.changes?.[0]
    const value = changes?.value
    const message = value?.messages?.[0]
    const contact = value?.contacts?.[0]

    if (!message || message.type !== 'text') {
      // Inbound event acknowledged (e.g. read receipt or status update)
      return new NextResponse('OK', { status: 200 })
    }

    const text = message.text?.body || ''
    const senderName = contact?.profile?.name || 'WhatsApp User'
    const senderPhone = message.from ? `+${message.from}` : '+971 50 849 2011'
    const messageId = message.id

    // Unified inbound processing: detects whether sender is a service person replying or field staff reporting
    await handleInboundWhatsApp({
      text,
      senderName,
      senderPhone,
      senderRole: 'Field Staff',
      whatsappMessageId: messageId,
    })

    return new NextResponse('EVENT_RECEIVED', { status: 200 })
  } catch (error) {
    console.error('Webhook error:', error)
    return new NextResponse('Internal Server Error', { status: 500 })
  }
}
