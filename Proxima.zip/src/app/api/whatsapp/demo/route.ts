import { NextResponse } from 'next/server'
import { handleInboundWhatsApp } from '@/lib/whatsapp/inbound-handler'

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const text = body.text || 'AC is not cooling in Office 101. Temperature is very high. Please check urgently.'
    const senderName = body.senderName || 'Ahmed'
    const senderRole = body.senderRole || 'Field Technician'
    const senderPhone = body.senderPhone || '+971 50 849 2011'
    const photoUrl = body.photoUrl || '/demo/ac-room-101.jpg'

    const result = await handleInboundWhatsApp({
      text,
      senderName,
      senderRole,
      senderPhone,
      photoUrl,
    })

    return NextResponse.json(
      {
        success: result.success,
        type: result.type,
        complaint: result.complaint,
        servicePerson: result.servicePerson,
        processingSteps: result.newComplaintResult?.processingSteps || [
          {
            step: 1,
            title: 'WhatsApp Gateway Ingestion',
            detail: `Received reply from ${result.servicePerson?.name || senderName} (${senderPhone}) via WhatsApp.`,
            timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          },
          {
            step: 2,
            title: 'Service Person & Ticket Resolution',
            detail: `Matched to ${result.servicePerson?.name} (${result.servicePerson?.company}) and complaint ${result.complaint?.ticket_number || 'target'}.`,
            timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          },
          {
            step: 3,
            title: 'Inbound Response Logged & Activity Committed',
            detail: `Recorded service response: "${text}". Ticket timeline updated.`,
            timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          },
        ],
      },
      { status: 200 }
    )
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Failed to process WhatsApp demo message'
    console.error('Error in WhatsApp demo endpoint:', message)
    return NextResponse.json(
      {
        success: false,
        error: message,
      },
      { status: 500 }
    )
  }
}
