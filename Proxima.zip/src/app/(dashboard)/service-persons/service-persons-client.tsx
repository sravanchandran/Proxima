'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import {
  UserCheck,
  Search,
  Filter,
  Plus,
  Phone,
  Building2,
  CheckCircle2,
  Edit2,
  Eye,
  Loader2,
  X,
  Sparkles,
  Power,
} from 'lucide-react'
import { ServicePersonRecord } from '@/lib/services/demo-store'
import { SERVICE_TYPES, SERVICE_TYPE_DETAILS, ServiceType } from '@/lib/constants/service-types'
import { formatPhoneNumber } from '@/lib/phone'
import {
  createServicePersonAction,
  updateServicePersonAction,
  toggleServicePersonStatusAction,
} from './actions'

interface ServicePersonsClientProps {
  initialServicePersons: ServicePersonRecord[]
}

export function ServicePersonsClient({ initialServicePersons }: ServicePersonsClientProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedType, setSelectedType] = useState<string>('all')
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all')

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [editingPerson, setEditingPerson] = useState<ServicePersonRecord | null>(null)
  const [isPending, startTransition] = useTransition()
  const [formError, setFormError] = useState<string | null>(null)

  // Filtered list
  const filteredPersons = initialServicePersons.filter((person) => {
    // Type filter
    if (selectedType !== 'all' && person.service_type !== selectedType) {
      return false
    }
    // Status filter
    if (statusFilter === 'active' && !person.is_active) return false
    if (statusFilter === 'inactive' && person.is_active) return false

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      const matchName = person.name.toLowerCase().includes(q)
      const matchCompany = person.company.toLowerCase().includes(q)
      const matchType = person.service_type.toLowerCase().includes(q)
      const matchPhone = person.whatsapp_number.toLowerCase().includes(q)
      return matchName || matchCompany || matchType || matchPhone
    }

    return true
  })

  // KPIs
  const totalCount = initialServicePersons.length
  const activeCount = initialServicePersons.filter((p) => p.is_active).length
  const distinctTypes = new Set(initialServicePersons.map((p) => p.service_type)).size
  const distinctCompanies = new Set(initialServicePersons.map((p) => p.company)).size

  const handleToggleStatus = (person: ServicePersonRecord) => {
    startTransition(async () => {
      try {
        await toggleServicePersonStatusAction(person.id, person.is_active)
      } catch (err: unknown) {
        console.error('Failed to toggle status:', err)
      }
    })
  }

  const handleCreateSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setFormError(null)
    const formData = new FormData(e.currentTarget)

    startTransition(async () => {
      try {
        await createServicePersonAction(formData)
        setIsAddModalOpen(false)
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Failed to create service person'
        setFormError(msg)
      }
    })
  }

  const handleEditSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!editingPerson) return
    setFormError(null)
    const formData = new FormData(e.currentTarget)

    startTransition(async () => {
      try {
        await updateServicePersonAction(editingPerson.id, formData)
        setEditingPerson(null)
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Failed to update service person'
        setFormError(msg)
      }
    })
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded flex items-center gap-1">
              <UserCheck className="h-3 w-3" />
              Contractor &amp; Vendor Master Data
            </span>
            <span className="text-xs text-[#667085]">· Facilities Administration</span>
          </div>
          <h1 className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">Service Persons Master</h1>
          <p className="text-sm text-[#667085] mt-0.5">
            Manage certified technicians, contractors, and specialists eligible for complaint dispatch and two-way WhatsApp communication.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setFormError(null)
            setIsAddModalOpen(true)
          }}
          className="inline-flex items-center justify-center gap-2 h-10 px-4 bg-[#4F46E5] hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-all shrink-0 cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          Add Service Person
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wider text-[#667085]">Total Registered</p>
          <p className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">{totalCount}</p>
          <p className="text-[11px] text-[#667085] mt-0.5">Technicians &amp; engineers</p>
        </div>
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wider text-[#667085]">Active On-Call</p>
          <p className="text-2xl font-bold text-emerald-700 mt-1 tracking-tight">{activeCount}</p>
          <p className="text-[11px] text-emerald-600 mt-0.5">Eligible for live dispatch</p>
        </div>
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wider text-[#667085]">Service Domains</p>
          <p className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">{distinctTypes}</p>
          <p className="text-[11px] text-[#667085] mt-0.5">HVAC, Plumbing, Electrical...</p>
        </div>
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-wider text-[#667085]">Partner Companies</p>
          <p className="text-2xl font-bold text-indigo-700 mt-1 tracking-tight">{distinctCompanies}</p>
          <p className="text-[11px] text-[#667085] mt-0.5">Authorized service vendors</p>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#667085]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, company, service type, or phone..."
            className="w-full h-10 pl-10 pr-4 text-xs rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] text-[#172033] placeholder:text-[#667085] focus:bg-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2.5 w-full md:w-auto flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-[#667085] shrink-0">
            <Filter className="h-3.5 w-3.5" />
            <span className="font-semibold text-[11px] uppercase">Filters:</span>
          </div>

          {/* Service Type Filter */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="h-10 px-3 text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:outline-none focus:border-indigo-500 cursor-pointer"
          >
            <option value="all">All Service Types ({distinctTypes})</option>
            {SERVICE_TYPES.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <div className="inline-flex rounded-lg border border-[#E2E8F0] bg-[#F8FAFC] p-0.5 text-xs">
            {(['all', 'active', 'inactive'] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatusFilter(s)}
                className={`px-3 py-1.5 rounded-md font-semibold capitalize cursor-pointer transition-all ${
                  statusFilter === s
                    ? 'bg-white text-[#172033] shadow-2xs'
                    : 'text-[#667085] hover:text-[#172033]'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
        {/* Table Header */}
        <div
          className="grid gap-4 px-6 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] text-[11px] font-bold uppercase tracking-wider text-[#667085]"
          style={{ gridTemplateColumns: '2fr 1.3fr 1.8fr 1.5fr 110px 140px' }}
        >
          <span>Service Person</span>
          <span>Service Type</span>
          <span>Company / Vendor</span>
          <span>WhatsApp Hotline</span>
          <span>Status</span>
          <span className="text-right">Actions</span>
        </div>

        {/* Rows */}
        <div className="divide-y divide-[#E2E8F0]">
          {filteredPersons.map((person) => {
            const typeConfig = SERVICE_TYPE_DETAILS[person.service_type as ServiceType] || {
              badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
            }

            return (
              <div
                key={person.id}
                className="grid gap-4 px-6 py-4 items-center hover:bg-[#F8FAFC] transition-colors group"
                style={{ gridTemplateColumns: '2fr 1.3fr 1.8fr 1.5fr 110px 140px' }}
              >
                {/* Person */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="h-9 w-9 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-xs text-[#172033] shrink-0">
                    {person.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <Link
                      href={`/service-persons/${person.id}`}
                      className="text-xs font-bold text-[#172033] group-hover:text-indigo-600 transition-colors block truncate hover:underline"
                    >
                      {person.name}
                    </Link>
                    <span className="text-[11px] text-[#667085] truncate block">
                      Added {new Date(person.created_at).toLocaleDateString('en-GB')}
                    </span>
                  </div>
                </div>

                {/* Service Type */}
                <div>
                  <span
                    className={`inline-flex items-center px-2.5 py-1 rounded-md text-[11px] font-semibold border ${typeConfig.badgeClass}`}
                  >
                    {person.service_type}
                  </span>
                </div>

                {/* Company */}
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-[#172033] truncate">
                    <Building2 className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span>{person.company}</span>
                  </div>
                </div>

                {/* WhatsApp */}
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 font-mono text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200/80 px-2.5 py-1 rounded-md w-fit">
                    <Phone className="h-3 w-3 text-emerald-600 shrink-0" />
                    <span>{formatPhoneNumber(person.whatsapp_number)}</span>
                  </div>
                </div>

                {/* Status */}
                <div>
                  {person.is_active ? (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      Active
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                      <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
                      Inactive
                    </span>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-1.5 shrink-0">
                  <Link
                    href={`/service-persons/${person.id}`}
                    title="View Workload & Profile"
                    className="h-8 w-8 rounded-lg border border-[#E2E8F0] hover:bg-slate-100 flex items-center justify-center text-[#667085] hover:text-[#172033] transition-colors"
                  >
                    <Eye className="h-3.5 w-3.5" />
                  </Link>

                  <button
                    type="button"
                    title="Edit Service Person"
                    onClick={() => {
                      setFormError(null)
                      setEditingPerson(person)
                    }}
                    className="h-8 w-8 rounded-lg border border-[#E2E8F0] hover:bg-slate-100 flex items-center justify-center text-[#667085] hover:text-indigo-600 transition-colors cursor-pointer"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>

                  <button
                    type="button"
                    title={person.is_active ? 'Deactivate' : 'Activate'}
                    onClick={() => handleToggleStatus(person)}
                    disabled={isPending}
                    className={`h-8 px-2 rounded-lg border text-[11px] font-semibold transition-colors flex items-center gap-1 cursor-pointer ${
                      person.is_active
                        ? 'border-amber-200 text-amber-700 hover:bg-amber-50'
                        : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
                    }`}
                  >
                    <Power className="h-3 w-3" />
                    <span>{person.is_active ? 'Deactivate' : 'Activate'}</span>
                  </button>
                </div>
              </div>
            )
          })}

          {filteredPersons.length === 0 && (
            <div className="py-16 text-center text-xs text-[#667085] space-y-2">
              <UserCheck className="h-8 w-8 mx-auto text-slate-300" />
              <p className="text-sm font-semibold text-[#172033]">No service persons found</p>
              <p className="text-xs text-[#667085]">
                Adjust your search or filter criteria, or add a new service person to the master register.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between text-xs text-[#667085]">
          <span>
            Showing <strong className="text-[#172033]">{filteredPersons.length}</strong> of{' '}
            <strong className="text-[#172033]">{initialServicePersons.length}</strong> registered service people
          </span>
          <span className="text-[11px]">
            Strict complaint assignment matching requires Service Type = Complaint Category &amp; Active Status
          </span>
        </div>
      </div>

      {/* ── Add Service Person Modal ── */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-xl w-full max-w-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-[#E2E8F0] flex items-center justify-between bg-[#F8FAFC]">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                  <UserCheck className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#172033]">Add New Service Person</h3>
                  <p className="text-[11px] text-[#667085]">Register a specialist for complaint assignment</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="h-8 w-8 rounded-lg text-slate-400 hover:text-slate-600 flex items-center justify-center cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit}>
              <div className="p-6 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
                    {formError}
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#172033]">
                    Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    required
                    placeholder="e.g. Ahmed Khan"
                    className="w-full h-10 px-3 text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#172033]">
                      Service Type <span className="text-red-500">*</span>
                    </label>
                    <select
                      name="service_type"
                      required
                      defaultValue="HVAC"
                      className="w-full h-10 px-3 text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                    >
                      {SERVICE_TYPES.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                    <p className="text-[10px] text-[#667085]">Standardized category for automated assignment</p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#172033]">
                      Company / Vendor <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="company"
                      required
                      placeholder="e.g. CoolTech Services"
                      className="w-full h-10 px-3 text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#172033]">
                    WhatsApp Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="whatsapp_number"
                    required
                    placeholder="e.g. +971501234567 or 0501234567"
                    className="w-full h-10 px-3 font-mono text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-[#667085]">
                    Will be normalized to international standard (+971...) for automated Meta WhatsApp dispatch.
                  </p>
                </div>

                <div className="pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#172033]">
                    <input
                      type="checkbox"
                      name="is_active"
                      defaultChecked
                      className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>Active and available for immediate complaint dispatch</span>
                  </label>
                </div>
              </div>

              <div className="px-6 py-4 bg-[#F8FAFC] border-t border-[#E2E8F0] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="h-9 px-4 text-xs font-semibold text-[#667085] hover:text-[#172033] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isPending}
                  className="h-9 px-5 bg-[#4F46E5] hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                  <span>Save Service Person</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Edit Service Person Modal ── */}
      {editingPerson && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-xl w-full max-w-lg overflow-hidden">
            <div className="px-6 py-4 border-b border-[#E2E8F0] flex items-center justify-between bg-[#F8FAFC]">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                  <Edit2 className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#172033]">Edit Service Person</h3>
                  <p className="text-[11px] text-[#667085]">{editingPerson.name}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingPerson(null)}
                className="h-8 w-8 rounded-lg text-slate-400 hover:text-slate-600 flex items-center justify-center cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit}>
              <div className="p-6 space-y-4">
                {formError && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700">
                    {formError}
                  </div>
                )}

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#172033]">Full Name</label>
                  <input
                    type="text"
                    name="name"
                    required
                    defaultValue={editingPerson.name}
                    className="w-full h-10 px-3 text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#172033]">Service Type</label>
                    <select
                      name="service_type"
                      required
                      defaultValue={editingPerson.service_type}
                      className="w-full h-10 px-3 text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                    >
                      {SERVICE_TYPES.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#172033]">Company</label>
                    <input
                      type="text"
                      name="company"
                      required
                      defaultValue={editingPerson.company}
                      className="w-full h-10 px-3 text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#172033]">WhatsApp Number</label>
                  <input
                    type="text"
                    name="whatsapp_number"
                    required
                    defaultValue={editingPerson.whatsapp_number}
                    className="w-full h-10 px-3 font-mono text-xs rounded-lg border border-[#E2E8F0] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="pt-2">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-[#172033]">
                    <input
                      type="checkbox"
                      name="is_active"
                      defaultChecked={editingPerson.is_active}
                      className="h-4 w-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>Active and available for dispatch</span>
                  </label>
                </div>
              </div>

              <div className="px-6 py-4 bg-[#F8FAFC] border-t border-[#E2E8F0] flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setEditingPerson(null)}
                  className="h-9 px-4 text-xs font-semibold text-[#667085] hover:text-[#172033] transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isPending}
                  className="h-9 px-5 bg-[#4F46E5] hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
