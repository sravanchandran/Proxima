import { getServicePersons } from '@/lib/services/service-persons'
import { ServicePersonsClient } from './service-persons-client'

export const dynamic = 'force-dynamic'

export default async function ServicePersonsPage() {
  const servicePersons = await getServicePersons()

  return <ServicePersonsClient initialServicePersons={servicePersons} />
}
