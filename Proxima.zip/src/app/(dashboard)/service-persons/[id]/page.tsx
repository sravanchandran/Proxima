import { notFound } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { getServicePersonById } from '@/lib/services/service-persons'
import { getMemoryAssignments } from '@/lib/services/demo-store'
import { formatPhoneNumber } from '@/lib/phone'
import { SERVICE_TYPE_DETAILS, ServiceType } from '@/lib/constants/service-types'
import {
  ArrowLeft,
  Building2,
  Phone,
  Clock,
  MessageSquare,
} from 'lucide-react'

export const dynamic = 'force-dynamic'

export default async function ServicePersonDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const servicePerson = await getServicePersonById(id)

  if (!servicePerson) {
    notFound()
  }

  const supabase = await createClient()

  // Fetch complaints assigned to this service person from Supabase
  const { data: dbComplaints } = await supabase
    .from('complaints')
    .select('*, buildings(name), floors(name), areas(name)')
    .eq('assigned_service_person_id', id)
    .order('created_at', { ascending: false })

  // Also check memory assignments
  const memAssignments = getMemoryAssignments()
  const memComplaintIds = Object.entries(memAssignments)
    .filter(([, val]) => val.servicePersonId === id)
    .map(([cId]) => cId)

  let allComplaints = dbComplaints || []

  if (memComplaintIds.length > 0) {
    const { data: memMatches } = await supabase
      .from('complaints')
      .select('*, buildings(name), floors(name), areas(name)')
      .in('id', memComplaintIds)

    if (memMatches) {
      const existingIds = new Set(allComplaints.map((c) => c.id))
      memMatches.forEach((c) => {
        if (!existingIds.has(c.id)) {
          allComplaints.push(c)
        }
      })
    }
  }

  // Attach memory latest responses
  allComplaints = allComplaints.map((c) => {
    const mem = memAssignments[c.id]
    return {
      ...c,
      latest_service_response: c.latest_service_response || mem?.latestResponse || null,
      latest_service_response_at: c.latest_service_response_at || mem?.latestResponseAt || null,
    }
  })

  const typeConfig =
    SERVICE_TYPE_DETAILS[servicePerson.service_type as ServiceType] || {
      badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
    }

  const activeAssignments = allComplaints.filter((c) => c.status === 'Open' || c.status === 'In Progress').length
  const completedAssignments = allComplaints.filter((c) => c.status === 'Resolved' || c.status === 'Closed').length

  return (
    <div className="max-w-5xl space-y-6">
      {/* Back button */}
      <Link
        href="/service-persons"
        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#667085] hover:text-[#172033] transition-colors"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back to Service Persons
      </Link>

      {/* Header Profile Card */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xl shadow-2xs">
              {servicePerson.name.substring(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl font-bold text-[#172033] tracking-tight">{servicePerson.name}</h1>
                {servicePerson.is_active ? (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Active On-Call
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-200">
                    <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
                    Inactive
                  </span>
                )}
              </div>
              <p className="text-xs text-[#667085] mt-1 flex items-center gap-2">
                <Building2 className="h-3.5 w-3.5 text-slate-400" />
                <span className="font-semibold text-[#172033]">{servicePerson.company}</span>
                <span>·</span>
                <span>Member since {new Date(servicePerson.created_at).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="font-mono text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-lg flex items-center gap-2">
              <Phone className="h-3.5 w-3.5 text-emerald-600" />
              <span>{formatPhoneNumber(servicePerson.whatsapp_number)}</span>
            </div>
          </div>
        </div>

        {/* Profile Attributes Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-5 border-t border-[#E2E8F0]">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#667085] block">Specialty Domain</span>
            <span className={`inline-flex items-center px-2.5 py-0.5 mt-1 rounded text-xs font-semibold border ${typeConfig.badgeClass}`}>
              {servicePerson.service_type}
            </span>
          </div>

          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#667085] block">Active Workload</span>
            <span className="text-lg font-bold text-[#172033] block mt-0.5">
              {activeAssignments} <span className="text-xs font-normal text-[#667085]">tickets in progress</span>
            </span>
          </div>

          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#667085] block">Completed Tickets</span>
            <span className="text-lg font-bold text-emerald-700 block mt-0.5">
              {completedAssignments} <span className="text-xs font-normal text-[#667085]">resolved</span>
            </span>
          </div>

          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#667085] block">Dispatch Eligibility</span>
            <span className="text-xs font-semibold text-indigo-700 block mt-1">
              Matches &quot;{servicePerson.service_type}&quot; complaints
            </span>
          </div>
        </div>
      </div>

      {/* Recent Assignments Table */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#172033]">
              Assigned Complaint History
            </h2>
            <p className="text-xs text-[#667085] mt-0.5">
              Work orders and facilities tickets assigned to {servicePerson.name}
            </p>
          </div>
          <span className="text-xs font-semibold text-[#172033]">
            {allComplaints.length} total assignments
          </span>
        </div>

        <div className="divide-y divide-[#E2E8F0]">
          {allComplaints.map((c) => (
            <div key={c.id} className="p-5 hover:bg-[#F8FAFC] transition-colors space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <Link
                    href={`/complaints/${c.id}`}
                    className="font-mono text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:underline"
                  >
                    {c.ticket_number}
                  </Link>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs font-bold text-[#172033]">{c.title}</span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-[#667085]">
                    Assigned {new Date(c.created_at).toLocaleDateString('en-GB')}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                    {c.status}
                  </span>
                </div>
              </div>

              {/* Latest WhatsApp response if present */}
              {c.latest_service_response ? (
                <div className="bg-emerald-50/60 border border-emerald-200/80 rounded-lg p-3 text-xs flex items-start gap-2.5">
                  <MessageSquare className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between text-[10px] text-[#667085] mb-0.5">
                      <span className="font-bold text-emerald-800">Latest WhatsApp Reply</span>
                      {c.latest_service_response_at && (
                        <span>
                          {new Date(c.latest_service_response_at).toLocaleTimeString('en-US', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      )}
                    </div>
                    <p className="text-[#172033] italic">&ldquo;{c.latest_service_response}&rdquo;</p>
                  </div>
                </div>
              ) : (
                <div className="text-[11px] text-[#667085] flex items-center gap-1.5 italic">
                  <Clock className="h-3 w-3 text-amber-500" />
                  <span>Awaiting initial response from service person</span>
                </div>
              )}
            </div>
          ))}

          {allComplaints.length === 0 && (
            <div className="py-12 text-center text-xs text-[#667085] space-y-1">
              <Clock className="h-6 w-6 mx-auto text-slate-300" />
              <p className="font-semibold text-[#172033]">No assignments on record yet</p>
              <p>When this service person is assigned to a {servicePerson.service_type} complaint, it will show here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
