'use server'

import { revalidatePath } from 'next/cache'
import {
  createServicePerson,
  updateServicePerson,
  toggleServicePersonStatus,
} from '@/lib/services/service-persons'

export async function createServicePersonAction(formData: FormData) {
  const name = formData.get('name') as string
  const service_type = formData.get('service_type') as string
  const company = formData.get('company') as string
  const whatsapp_number = formData.get('whatsapp_number') as string
  const is_active = formData.get('is_active') === 'true' || formData.get('is_active') === 'on'

  if (!name || !service_type || !company || !whatsapp_number) {
    throw new Error('All required fields must be provided')
  }

  await createServicePerson({
    name,
    service_type,
    company,
    whatsapp_number,
    is_active,
  })

  revalidatePath('/service-persons')
  revalidatePath('/complaints')
}

export async function updateServicePersonAction(id: string, formData: FormData) {
  const name = formData.get('name') as string
  const service_type = formData.get('service_type') as string
  const company = formData.get('company') as string
  const whatsapp_number = formData.get('whatsapp_number') as string
  const is_active = formData.get('is_active') === 'true' || formData.get('is_active') === 'on'

  await updateServicePerson(id, {
    name,
    service_type,
    company,
    whatsapp_number,
    is_active,
  })

  revalidatePath('/service-persons')
  revalidatePath(`/service-persons/${id}`)
  revalidatePath('/complaints')
}

export async function toggleServicePersonStatusAction(id: string, currentStatus: boolean) {
  await toggleServicePersonStatus(id, !currentStatus)

  revalidatePath('/service-persons')
  revalidatePath(`/service-persons/${id}`)
  revalidatePath('/complaints')
}
