import { createClient } from '@/lib/supabase/server'
import { Building2, MapPin, Layers, LayoutGrid } from 'lucide-react'

interface AreaRecord {
  id: string
  name: string
}

interface FloorRecord {
  id: string
  name: string
  level: number
  areas?: AreaRecord[]
}

export default async function BuildingsPage() {
  const supabase = await createClient()

  const { data: buildings } = await supabase
    .from('buildings')
    .select('*, floors(*, areas(*))')
    .limit(1)

  const building = buildings?.[0]

  if (!building) {
    return (
      <div className="flex flex-col items-center justify-center py-32 text-center">
        <div className="h-12 w-12 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400 mb-4">
          <Building2 className="h-6 w-6" />
        </div>
        <p className="text-sm font-semibold text-[#172033]">No building registered</p>
        <p className="text-xs text-[#667085] mt-1">
          Run <code className="bg-[#F1F5F9] px-1.5 py-0.5 rounded text-[#172033]">npm run seed</code> to populate the property database.
        </p>
      </div>
    )
  }

  const sortedFloors: FloorRecord[] = [...(building.floors ?? [])].sort((a: FloorRecord, b: FloorRecord) => b.level - a.level)
  const totalAreas = sortedFloors.reduce((acc: number, f: FloorRecord) => acc + (f.areas?.length ?? 0), 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
            Property Portfolio
          </span>
          <span className="text-xs text-[#667085]">· Facility Structure</span>
        </div>
        <h1 className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">Building Hierarchy &amp; Infrastructure</h1>
        <p className="text-sm text-[#667085] mt-0.5">
          Structural blueprint and architectural spatial breakdown for active facility operations.
        </p>
      </div>

      {/* Building Overview Card */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
        <div className="flex flex-col md:flex-row items-start justify-between gap-6 p-6 border-b border-[#E2E8F0]">
          <div className="flex items-start gap-4">
            <div className="h-14 w-14 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0 shadow-xs">
              <Building2 className="h-7 w-7" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#172033]">{building.name}</h2>
              <div className="flex items-center gap-1.5 mt-1 text-sm text-[#667085]">
                <MapPin className="h-4 w-4 text-indigo-500 shrink-0" />
                <span>{building.address}, {building.city}, {building.country}</span>
              </div>
              {building.description && (
                <p className="text-xs text-[#667085] mt-2 max-w-2xl leading-relaxed">
                  {building.description}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-6 divide-x divide-[#E2E8F0] self-stretch md:self-auto pt-4 md:pt-0 border-t md:border-t-0 border-[#E2E8F0]">
            <div className="pr-4">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Status</p>
              <span className="inline-flex items-center gap-1.5 mt-1 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                {building.status ?? 'Active'}
              </span>
            </div>
            <div className="px-4">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Total Floors</p>
              <p className="text-xl font-bold text-[#172033] mt-0.5">{sortedFloors.length}</p>
            </div>
            <div className="pl-4">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Managed Areas</p>
              <p className="text-xl font-bold text-[#172033] mt-0.5">{totalAreas}</p>
            </div>
          </div>
        </div>

        {/* Floor Hierarchy Breakdown */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                Floor &amp; Demarcated Areas Blueprint
              </h3>
            </div>
            <span className="text-xs text-[#667085] font-medium">
              {sortedFloors.length} levels configured
            </span>
          </div>

          <div className="space-y-3">
            {sortedFloors.map((floor: FloorRecord) => {
              const levelLabel =
                floor.level < 0 ? `B${Math.abs(floor.level)}` : floor.level === 0 ? 'G' : `L${floor.level}`

              return (
                <div key={floor.id} className="border border-[#E2E8F0] rounded-xl overflow-hidden bg-white shadow-2xs">
                  <div className="flex items-center justify-between px-4 py-3 bg-[#F8FAFC] border-b border-[#E2E8F0]">
                    <div className="flex items-center gap-3">
                      <div className="h-7 w-7 rounded-md bg-indigo-100 text-indigo-800 flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold font-mono">{levelLabel}</span>
                      </div>
                      <span className="text-sm font-bold text-[#172033]">{floor.name}</span>
                    </div>
                    <span className="text-[11px] text-[#667085] font-medium">
                      {floor.areas?.length ?? 0} area{(floor.areas?.length ?? 0) !== 1 ? 's' : ''}
                    </span>
                  </div>

                  <div className="p-4">
                    {floor.areas && floor.areas.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {floor.areas.map((area: AreaRecord) => (
                          <div
                            key={area.id}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#E2E8F0] rounded-lg text-xs font-medium text-[#172033] hover:border-indigo-300 hover:bg-indigo-50/30 transition-colors cursor-default"
                          >
                            <LayoutGrid className="h-3 w-3 text-indigo-500" />
                            <span>{area.name}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-xs text-[#667085] italic">No functional zones designated</span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
