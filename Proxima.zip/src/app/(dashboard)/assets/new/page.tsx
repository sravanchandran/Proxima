import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ArrowLeft, PackagePlus, Sparkles } from 'lucide-react'
import Link from 'next/link'
import { createAsset } from './actions'

export default function NewAssetPage() {
  return (
    <div className="max-w-3xl space-y-6">
      <Link
        href="/assets"
        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#667085] hover:text-[#172033] transition-colors"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back to Assets
      </Link>

      {/* Header with Subtle Colored Icon Block */}
      <div className="flex items-start gap-4">
        <div className="h-12 w-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-[#4F46E5] shrink-0 shadow-xs">
          <PackagePlus className="h-6 w-6" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
              Inventory Ledger
            </span>
            <span className="text-xs text-[#667085]">· Anantara Business Tower</span>
          </div>
          <h1 className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">Register Facility Asset</h1>
          <p className="text-sm text-[#667085] mt-0.5">
            Add equipment or machinery record into the central property asset registry.
          </p>
        </div>
      </div>

      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
        <form action={createAsset}>
          <div className="p-6 border-b border-[#E2E8F0] space-y-5">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#172033]">
              <span className="h-2 w-2 rounded-full bg-indigo-600" />
              Asset Identification
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="asset_id" className="text-xs font-semibold text-[#172033]">
                  Asset ID / Tag <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="asset_id"
                  name="asset_id"
                  required
                  placeholder="e.g. AST-1009"
                  className="h-10 bg-white border-[#E2E8F0] text-[#172033] placeholder:text-[#667085]/60 focus-visible:ring-indigo-500 focus-visible:border-indigo-500 font-mono text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="name" className="text-xs font-semibold text-[#172033]">
                  Asset Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="name"
                  name="name"
                  required
                  placeholder="e.g. Primary Chilled Water Pump"
                  className="h-10 bg-white border-[#E2E8F0] text-[#172033] placeholder:text-[#667085]/60 focus-visible:ring-indigo-500 focus-visible:border-indigo-500 text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="category" className="text-xs font-semibold text-[#172033]">
                  System Category
                </Label>
                <Input
                  id="category"
                  name="category"
                  placeholder="e.g. HVAC, Electrical, Plumbing"
                  className="h-10 bg-white border-[#E2E8F0] text-[#172033] placeholder:text-[#667085]/60 focus-visible:ring-indigo-500 focus-visible:border-indigo-500 text-sm"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="type" className="text-xs font-semibold text-[#172033]">
                  Equipment Type
                </Label>
                <Input
                  id="type"
                  name="type"
                  placeholder="e.g. Centrifugal Pump"
                  className="h-10 bg-white border-[#E2E8F0] text-[#172033] placeholder:text-[#667085]/60 focus-visible:ring-indigo-500 focus-visible:border-indigo-500 text-sm"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="description" className="text-xs font-semibold text-[#172033]">
                Technical Description &amp; Specifications
              </Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Model details, manufacturer, ratings, service frequency notes..."
                className="min-h-[110px] bg-white border-[#E2E8F0] text-[#172033] placeholder:text-[#667085]/60 focus-visible:ring-indigo-500 focus-visible:border-indigo-500 text-sm leading-relaxed"
              />
            </div>
          </div>

          <div className="px-6 py-4 bg-[#F8FAFC] flex items-center justify-between gap-4">
            <p className="text-xs text-[#667085]">
              Asset will be linked to Anantara Business Tower facility ledger.
            </p>
            <div className="flex items-center gap-3 shrink-0">
              <Link
                href="/assets"
                className="h-10 px-4 text-xs font-semibold text-[#667085] hover:text-[#172033] transition-colors inline-flex items-center"
              >
                Cancel
              </Link>
              <button
                type="submit"
                className="h-10 px-6 bg-[#4F46E5] hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-semibold rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="h-4 w-4" />
                Register Asset
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
