'use server'

import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'

export async function createAsset(formData: FormData) {
  const supabase = await createClient()
  
  const asset_id = formData.get('asset_id') as string
  const name = formData.get('name') as string
  const category = formData.get('category') as string
  const type = formData.get('type') as string
  const description = formData.get('description') as string

  // Note: For a robust app, we'd use Zod for validation here.
  if (!asset_id || !name) {
    throw new Error('Asset ID and Name are required')
  }

  // To associate it with our demo building, fetch the first building
  const { data: buildings } = await supabase.from('buildings').select('id').limit(1)
  const buildingId = buildings?.[0]?.id

  const { error } = await supabase.from('assets').insert({
    asset_id,
    name,
    category,
    type,
    description,
    building_id: buildingId,
    status: 'Active'
  })

  if (error) {
    console.error('Failed to create asset:', error)
    throw new Error('Failed to create asset')
  }

  revalidatePath('/assets')
  redirect('/assets')
}
