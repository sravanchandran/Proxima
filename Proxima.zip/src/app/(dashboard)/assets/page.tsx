import { createClient } from '@/lib/supabase/server'
import { Plus, Package, ArrowRight } from 'lucide-react'
import Link from 'next/link'

const STATUS_STYLE: Record<string, string> = {
  'Active': 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold',
  'Inactive': 'bg-slate-100 text-slate-600 border border-slate-200 font-medium',
  'Under Maintenance': 'bg-amber-50 text-amber-700 border border-amber-200 font-semibold',
}

export default async function AssetsPage() {
  const supabase = await createClient()

  const { data: assets, count } = await supabase
    .from('assets')
    .select('*, floors(name), areas(name)', { count: 'exact' })
    .order('created_at', { ascending: false })

  const active = assets?.filter(a => a.status === 'Active').length ?? 0
  const maintenance = assets?.filter(a => a.status === 'Under Maintenance').length ?? 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
              Facilities Inventory
            </span>
            <span className="text-xs text-[#667085]">· Anantara Business Tower</span>
          </div>
          <h1 className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">Asset Register</h1>
          <p className="text-sm text-[#667085] mt-0.5">
            {active} active systems · {maintenance} under maintenance · {count ?? 0} total registered assets
          </p>
        </div>
        <Link
          href="/assets/new"
          className="inline-flex items-center justify-center gap-2 h-10 px-4 bg-[#4F46E5] hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors shrink-0"
        >
          <Plus className="h-4 w-4" />
          Add Asset
        </Link>
      </div>

      {/* Table Card */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
        {/* Header Row */}
        <div
          className="grid gap-4 px-5 py-3 border-b border-[#E2E8F0] bg-[#F8FAFC] text-[11px] font-semibold uppercase tracking-wider text-[#667085]"
          style={{ gridTemplateColumns: '120px 1.8fr 1.2fr 1.2fr 1fr 120px' }}
        >
          <span>Asset Tag</span>
          <span>Asset Identity</span>
          <span>Category &amp; Type</span>
          <span>Area / Location</span>
          <span>Floor Level</span>
          <span className="text-right">Status</span>
        </div>

        {/* Rows */}
        <div className="divide-y divide-[#E2E8F0]">
          {assets?.map((asset) => (
            <Link
              key={asset.id}
              href={`/assets/${asset.id}`}
              className="grid gap-4 px-5 py-3.5 items-center hover:bg-[#F8FAFC] transition-colors group"
              style={{ gridTemplateColumns: '120px 1.8fr 1.2fr 1.2fr 1fr 120px' }}
            >
              <span className="font-mono text-xs font-semibold text-[#172033] group-hover:text-indigo-600 transition-colors">
                {asset.asset_id}
              </span>

              <div className="min-w-0 pr-2">
                <p className="text-sm font-semibold text-[#172033] group-hover:text-indigo-600 truncate transition-colors">
                  {asset.name}
                </p>
                {asset.manufacturer && (
                  <p className="text-xs text-[#667085] truncate mt-0.5">
                    {asset.manufacturer} {asset.model ? `· ${asset.model}` : ''}
                  </p>
                )}
              </div>

              <div className="min-w-0">
                <p className="text-xs font-medium text-[#172033] truncate">{asset.category ?? '—'}</p>
                <p className="text-[11px] text-[#667085] truncate mt-0.5">{asset.type ?? 'Mechanical'}</p>
              </div>

              <span className="text-xs text-[#172033] truncate font-medium">
                {asset.areas?.name ?? '—'}
              </span>

              <span className="text-xs text-[#667085] truncate">
                {asset.floors?.name ?? '—'}
              </span>

              <div className="text-right">
                <span className={`inline-flex px-2.5 py-0.5 rounded-full text-[11px] ${STATUS_STYLE[asset.status] ?? 'bg-slate-100 text-slate-600'}`}>
                  {asset.status}
                </span>
              </div>
            </Link>
          ))}

          {!assets?.length && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="h-12 w-12 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400 mb-3">
                <Package className="h-6 w-6" />
              </div>
              <p className="text-sm font-semibold text-[#172033]">No assets registered</p>
              <p className="text-xs text-[#667085] mt-1">Add your first facility asset or reseed the demo database.</p>
              <Link
                href="/assets/new"
                className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-700 transition-colors"
              >
                Register an asset <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          )}
        </div>

        {/* Footer */}
        {(assets?.length ?? 0) > 0 && (
          <div className="px-5 py-3 border-t border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between text-xs text-[#667085]">
            <span>
              Showing <strong className="text-[#172033]">{assets?.length}</strong> of <strong className="text-[#172033]">{count}</strong> registered assets
            </span>
            <span className="text-[11px]">Anantara Business Tower Asset Ledger</span>
          </div>
        )}
      </div>
    </div>
  )
}
