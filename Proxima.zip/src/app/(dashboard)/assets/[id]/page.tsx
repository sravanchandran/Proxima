import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import { ArrowLeft, Package, MapPin, Calendar, Wrench, MessageSquare, Globe } from 'lucide-react'
import Link from 'next/link'

const STATUS_STYLE: Record<string, string> = {
  'Active': 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold',
  'Inactive': 'bg-slate-100 text-slate-600 border border-slate-200 font-medium',
  'Under Maintenance': 'bg-amber-50 text-amber-700 border border-amber-200 font-semibold',
}

const COMPLAINT_STATUS_STYLE: Record<string, string> = {
  'Open': 'bg-red-50 text-red-700 border border-red-200 font-semibold',
  'In Progress': 'bg-amber-50 text-amber-700 border border-amber-200 font-semibold',
  'Resolved': 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold',
  'Closed': 'bg-slate-100 text-slate-600 border border-slate-200 font-medium',
}

export default async function AssetDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient()
  const { id } = await params

  const { data: asset } = await supabase
    .from('assets')
    .select('*, buildings(name), floors(name), areas(name)')
    .eq('id', id)
    .single()

  if (!asset) notFound()

  // Related complaints
  const { data: relatedComplaints } = await supabase
    .from('complaints')
    .select('id, ticket_number, title, status, source, created_at')
    .eq('asset_id', id)
    .order('created_at', { ascending: false })
    .limit(6)

  return (
    <div className="max-w-5xl space-y-6">
      {/* Back button */}
      <Link
        href="/assets"
        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#667085] hover:text-[#172033] transition-colors"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back to Assets
      </Link>

      {/* Asset Identity Header Card */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-6 shadow-sm">
        <div className="flex items-start gap-4 flex-wrap sm:flex-nowrap">
          <div className="h-12 w-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0 shadow-xs">
            <Package className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-2xl font-bold text-[#172033] tracking-tight">{asset.name}</h1>
              <span className={`text-xs px-2.5 py-0.5 rounded-full ${STATUS_STYLE[asset.status] ?? 'bg-slate-100 text-slate-600'}`}>
                {asset.status}
              </span>
            </div>
            <div className="flex items-center gap-2 mt-1.5 flex-wrap">
              <span className="font-mono text-xs font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                {asset.asset_id}
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-xs text-[#667085] font-medium">{asset.category || 'Facility Asset'}</span>
              {asset.type && (
                <>
                  <span className="text-slate-300">·</span>
                  <span className="text-xs text-[#667085]">{asset.type}</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Specifications & Related Tickets */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        {/* Left Column: Specs & History */}
        <div className="space-y-6">
          {/* Technical Specifications */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC]">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                Technical Specifications &amp; Register
              </h3>
            </div>
            <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4">
              <div className="sm:col-span-2">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Description</p>
                <p className="text-sm text-[#172033] mt-1 leading-relaxed">
                  {asset.description || 'No additional technical description on file for this asset.'}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">System Category</p>
                <p className="text-sm font-semibold text-[#172033] mt-0.5">{asset.category ?? '—'}</p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Equipment Type</p>
                <p className="text-sm font-semibold text-[#172033] mt-0.5">{asset.type ?? '—'}</p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Manufacturer</p>
                <p className="text-sm font-semibold text-[#172033] mt-0.5">{asset.manufacturer ?? '—'}</p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Model Designation</p>
                <p className="text-sm font-semibold text-[#172033] mt-0.5">{asset.model ?? '—'}</p>
              </div>

              <div className="sm:col-span-2 pt-2 border-t border-[#F1F5F9]">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Serial Number</p>
                <code className="text-xs bg-[#F1F5F9] text-[#172033] px-2.5 py-1 rounded font-mono mt-1 inline-block">
                  {asset.serial_number ?? 'NOT RECORDED'}
                </code>
              </div>
            </div>
          </div>

          {/* Related Complaints */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                Associated Service &amp; Incident History
              </h3>
              {(relatedComplaints?.length ?? 0) > 0 && (
                <span className="text-[11px] font-medium text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  {relatedComplaints?.length} linked incidents
                </span>
              )}
            </div>

            {relatedComplaints && relatedComplaints.length > 0 ? (
              <div className="divide-y divide-[#E2E8F0]">
                {relatedComplaints.map((c) => (
                  <Link
                    key={c.id}
                    href={`/complaints/${c.id}`}
                    className="flex items-center gap-3 px-5 py-3.5 hover:bg-[#F8FAFC] transition-colors group"
                  >
                    {c.source === 'WhatsApp' ? (
                      <MessageSquare className="h-4 w-4 text-emerald-600 shrink-0" />
                    ) : (
                      <Globe className="h-4 w-4 text-blue-600 shrink-0" />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-[#172033] group-hover:text-indigo-600 truncate transition-colors">
                        {c.title}
                      </p>
                      <p className="text-[11px] text-[#667085] mt-0.5 font-mono">{c.ticket_number}</p>
                    </div>
                    <span className={`text-xs px-2.5 py-0.5 rounded-full shrink-0 ${COMPLAINT_STATUS_STYLE[c.status] ?? ''}`}>
                      {c.status}
                    </span>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center">
                <p className="text-sm font-medium text-[#172033]">No incident complaints recorded</p>
                <p className="text-xs text-[#667085] mt-1">This asset has no active or past maintenance tickets.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Location & Lifecycle */}
        <div className="space-y-6">
          {/* Location Context */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center gap-2">
              <MapPin className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                Facility Location
              </h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Building</p>
                <p className="text-sm font-semibold text-[#172033] mt-0.5">
                  {asset.buildings?.name ?? 'Anantara Business Tower'}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Floor</p>
                <p className="text-sm font-medium text-[#172033] mt-0.5">
                  {asset.floors?.name ?? 'Ground Floor'}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Area / Zone</p>
                <p className="text-sm font-medium text-[#172033] mt-0.5">
                  {asset.areas?.name ?? 'Common Area'}
                </p>
              </div>
            </div>
          </div>

          {/* Lifecycle & Status */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center gap-2">
              <Wrench className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                Lifecycle Details
              </h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Commissioning Date</p>
                <div className="flex items-center gap-1.5 mt-1 text-sm font-medium text-[#172033]">
                  <Calendar className="h-3.5 w-3.5 text-[#667085]" />
                  <span>
                    {asset.installation_date
                      ? new Date(asset.installation_date).toLocaleDateString('en-GB', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })
                      : 'Not recorded'}
                  </span>
                </div>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Operational Readiness</p>
                <div className="mt-1">
                  <span className={`inline-flex text-xs px-2.5 py-0.5 rounded-full ${STATUS_STYLE[asset.status] ?? 'bg-slate-100 text-slate-600'}`}>
                    {asset.status}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
