import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import {
  Package,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Zap,
  MessageSquare,
  Globe,
  ArrowRight,
  Building2,
  ShieldAlert,
  MessageCircle,
  ExternalLink,
  UserCheck,
} from 'lucide-react'
import { getMemoryAssignments } from '@/lib/services/demo-store'

export const dynamic = 'force-dynamic'

function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    'Open': 'bg-red-50 text-red-700 border border-red-200 font-semibold',
    'In Progress': 'bg-amber-50 text-amber-700 border border-amber-200 font-semibold',
    'Resolved': 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold',
    'Closed': 'bg-slate-100 text-slate-600 border border-slate-200 font-medium',
  }
  return (
    <span className={`inline-flex px-2 py-0.5 rounded text-[11px] ${map[status] ?? 'bg-slate-100 text-slate-600'}`}>
      {status}
    </span>
  )
}

function PriorityDot({ priority }: { priority: string }) {
  const map: Record<string, string> = {
    'Critical': 'bg-red-500 ring-2 ring-red-100',
    'High': 'bg-amber-500 ring-2 ring-amber-100',
    'Medium': 'bg-yellow-400',
    'Low': 'bg-slate-300',
  }
  return <span className={`inline-block h-2 w-2 rounded-full shrink-0 ${map[priority] ?? 'bg-slate-300'}`} />
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  return `${Math.floor(h / 24)}d ago`
}

export default async function DashboardPage() {
  const supabase = await createClient()

  const [
    { count: assetsCount },
    { count: complaintsTotal },
    { count: openCount },
    { count: inProgressCount },
    { count: resolvedCount },
    { count: whatsappCount },
    { data: allComplaintsList },
    { data: recentComplaints },
    { data: whatsappComplaints },
    { data: building },
  ] = await Promise.all([
    supabase.from('assets').select('*', { count: 'exact', head: true }),
    supabase.from('complaints').select('*', { count: 'exact', head: true }),
    supabase.from('complaints').select('*', { count: 'exact', head: true }).eq('status', 'Open'),
    supabase.from('complaints').select('*', { count: 'exact', head: true }).eq('status', 'In Progress'),
    supabase.from('complaints').select('*', { count: 'exact', head: true }).eq('status', 'Resolved'),
    supabase.from('complaints').select('*', { count: 'exact', head: true }).eq('source', 'WhatsApp'),
    supabase.from('complaints').select('id, status, assigned_service_person_id, latest_service_response, latest_service_response_at'),
    supabase.from('complaints')
      .select('id, ticket_number, title, priority, status, source, created_at, category')
      .order('created_at', { ascending: false })
      .limit(8),
    supabase.from('complaints')
      .select('id, ticket_number, title, description, priority, status, created_at, updated_description')
      .eq('source', 'WhatsApp')
      .order('created_at', { ascending: false })
      .limit(4),
    supabase.from('buildings').select('name, city, country, status').limit(1).single(),
  ])

  const criticalCount = recentComplaints?.filter((c) => c.priority === 'Critical' && c.status !== 'Closed' && c.status !== 'Resolved').length ?? 0
  const latestWhatsApp = whatsappComplaints?.[0]

  // Compute Service Assignment Metrics
  const memAssignments = getMemoryAssignments()
  let assignedCount = 0
  let unassignedCount = 0
  let awaitingCount = 0
  let respondedCount = 0

  const todayIso = new Date().toISOString().substring(0, 10)

  allComplaintsList?.forEach((c) => {
    const isAssigned = Boolean(c.assigned_service_person_id || memAssignments[c.id]?.servicePersonId)
    const response = c.latest_service_response || memAssignments[c.id]?.latestResponse
    const responseAt = c.latest_service_response_at || memAssignments[c.id]?.latestResponseAt

    if (isAssigned) {
      assignedCount++
      if (response) {
        if (responseAt && responseAt.startsWith(todayIso)) {
          respondedCount++
        } else {
          respondedCount++
        }
      } else {
        awaitingCount++
      }
    } else {
      if (c.status === 'Open' || c.status === 'In Progress') {
        unassignedCount++
      }
    }
  })

  const kpis = [
    {
      label: 'Total Assets',
      value: assetsCount ?? 0,
      icon: Package,
      color: 'text-indigo-600',
      bg: 'bg-indigo-50 border border-indigo-100',
      href: '/assets',
    },
    {
      label: 'Open Issues',
      value: openCount ?? 0,
      icon: AlertTriangle,
      color: 'text-red-600',
      bg: 'bg-red-50 border border-red-100',
      href: '/complaints',
    },
    {
      label: 'In Progress',
      value: inProgressCount ?? 0,
      icon: Clock,
      color: 'text-amber-600',
      bg: 'bg-amber-50 border border-amber-100',
      href: '/complaints',
    },
    {
      label: 'Critical Priority',
      value: criticalCount,
      icon: ShieldAlert,
      color: 'text-red-700',
      bg: 'bg-red-100 border border-red-200',
      href: '/complaints',
    },
    {
      label: 'Resolved',
      value: resolvedCount ?? 0,
      icon: CheckCircle2,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50 border border-emerald-100',
      href: '/complaints',
    },
  ]

  return (
    <div className="space-y-6">
      {/* ── Building Command Header ─────────────────────────── */}
      <div className="rounded-xl bg-[#0F172A] text-white px-6 py-5 flex flex-col md:flex-row items-start justify-between gap-6 shadow-sm border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] font-semibold tracking-wider uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded">
              Command Center
            </span>
            <span className="text-xs text-slate-400">· Real-Time Operational Telemetry</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">{building?.name ?? 'Anantara Business Tower'}</h1>
          <p className="text-slate-400 text-xs mt-1 flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5 text-slate-500" />
            {building?.city ?? 'Downtown Dubai'}, {building?.country ?? 'UAE'} · 22 Commercial Floors
          </p>
        </div>

        <div className="flex items-center gap-6 divide-x divide-slate-800 self-stretch md:self-auto pt-4 md:pt-0 border-t md:border-t-0 border-slate-800">
          <div className="text-left md:text-right pr-4">
            <p className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Facility Status</p>
            <div className="flex items-center md:justify-end gap-1.5 mt-1">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-semibold text-emerald-400">Fully Operational</span>
            </div>
          </div>
          <div className="text-left md:text-right pl-4">
            <p className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">Active Tickets</p>
            <p className="text-lg font-bold text-white mt-0.5">
              <span className="text-red-400">{openCount}</span>
              <span className="text-xs text-slate-400 font-normal"> / {complaintsTotal} total</span>
            </p>
          </div>
        </div>
      </div>

      {/* ── KPI Row ─────────────────────────────────────────── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {kpis.map((kpi) => (
          <Link
            key={kpi.label}
            href={kpi.href}
            className="group bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#667085]">{kpi.label}</span>
              <div className={`h-8 w-8 rounded-lg ${kpi.bg} flex items-center justify-center`}>
                <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
              </div>
            </div>
            <div className="mt-3">
              <div className="text-2xl font-bold text-[#172033] tracking-tight">{kpi.value}</div>
              <span className="text-[11px] text-indigo-600 font-medium group-hover:underline inline-flex items-center gap-1 mt-0.5">
                View records <ArrowRight className="h-2.5 w-2.5" />
              </span>
            </div>
          </Link>
        ))}
      </div>

      {/* ── SERVICE ASSIGNMENTS OPERATIONAL SUMMARY ──────────── */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-2.5">
          <div className="flex items-center gap-2">
            <UserCheck className="h-4 w-4 text-indigo-600" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
              Service Assignments &amp; Field Dispatch Status
            </h3>
          </div>
          <Link
            href="/service-persons"
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 transition-colors"
          >
            Manage Service Persons <ArrowRight className="h-3 w-3" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200/80">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#667085] block">
              Unassigned Complaints
            </span>
            <span className="text-2xl font-bold text-[#172033] mt-0.5 block">{unassignedCount}</span>
            <span className="text-[11px] text-[#667085]">Awaiting specialist assignment</span>
          </div>

          <div className="p-3.5 rounded-lg bg-indigo-50/50 border border-indigo-100">
            <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-800 block">
              Assigned Complaints
            </span>
            <span className="text-2xl font-bold text-indigo-900 mt-0.5 block">{assignedCount}</span>
            <span className="text-[11px] text-indigo-600">Active contractor tickets</span>
          </div>

          <div className="p-3.5 rounded-lg bg-amber-50/60 border border-amber-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 block">
              Awaiting Service Response
            </span>
            <span className="text-2xl font-bold text-amber-900 mt-0.5 block">{awaitingCount}</span>
            <span className="text-[11px] text-amber-700">WhatsApp dispatched</span>
          </div>

          <div className="p-3.5 rounded-lg bg-emerald-50/60 border border-emerald-200">
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 block">
              Responded Today
            </span>
            <span className="text-2xl font-bold text-emerald-900 mt-0.5 block">{respondedCount}</span>
            <span className="text-[11px] text-emerald-700">Acknowledged via WhatsApp</span>
          </div>
        </div>
      </div>

      {/* ── Main Two Columns ───────────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-6">
        {/* Incidents Feed */}
        <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#E2E8F0] bg-[#F8FAFC]">
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-[#172033]">Recent Operational Incidents</h2>
              <p className="text-xs text-[#667085] mt-0.5">Real-time issues reported across all facility zones</p>
            </div>
            <Link
              href="/complaints"
              className="text-xs text-indigo-600 hover:text-indigo-700 font-semibold flex items-center gap-1 transition-colors"
            >
              All complaints <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          <div className="divide-y divide-[#E2E8F0]">
            {recentComplaints?.map((c) => {
              const isCritical = c.priority === 'Critical'
              const isHigh = c.priority === 'High'

              return (
                <Link
                  key={c.id}
                  href={`/complaints/${c.id}`}
                  className={`flex items-start gap-3.5 px-5 py-3.5 hover:bg-[#F8FAFC] transition-colors group ${
                    isCritical ? 'border-l-4 border-l-red-500' : isHigh ? 'border-l-4 border-l-amber-500' : 'border-l-4 border-l-transparent'
                  }`}
                >
                  <div className="pt-1">
                    <PriorityDot priority={c.priority} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-semibold text-[#172033] group-hover:text-indigo-600 transition-colors">
                        {c.ticket_number}
                      </span>
                      <span className="text-xs text-slate-300">·</span>
                      <span className="text-xs font-medium text-[#667085]">{c.category || 'General'}</span>
                    </div>
                    <p className="text-sm font-semibold text-[#172033] group-hover:text-indigo-600 mt-0.5 truncate transition-colors">
                      {c.title}
                    </p>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0 pt-0.5">
                    <StatusPill status={c.status} />
                    {c.source === 'WhatsApp' ? (
                      <span className="source-whatsapp inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full">
                        <MessageSquare className="h-3 w-3 text-emerald-600" />
                        <span className="hidden sm:inline">WA</span>
                      </span>
                    ) : (
                      <span className="source-web inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full">
                        <Globe className="h-3 w-3 text-blue-600" />
                        <span className="hidden sm:inline">Web</span>
                      </span>
                    )}
                    <span className="text-[11px] text-[#667085] font-medium hidden md:block">
                      {timeAgo(c.created_at)}
                    </span>
                  </div>
                </Link>
              )
            })}

            {!recentComplaints?.length && (
              <div className="py-16 text-center text-sm text-[#667085]">
                No incidents reported yet.
              </div>
            )}
          </div>
        </div>

        {/* WhatsApp Operations Panel */}
        <div className="space-y-6">
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            {/* WhatsApp Header */}
            <div className="bg-[#075E54] px-5 py-4 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="h-7 w-7 rounded-lg bg-white/15 flex items-center justify-center">
                    <MessageCircle className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold leading-tight">WhatsApp Operations</h3>
                    <p className="text-[11px] text-emerald-100">Live Two-Way Field &amp; Service Gateway</p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold bg-emerald-700/80 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Connected
                </span>
              </div>
            </div>

            {/* Live Stats Row */}
            <div className="p-4 bg-emerald-50/40 border-b border-[#E2E8F0] flex items-center justify-between text-xs">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#667085] block">Hotline Volume</span>
                <span className="font-bold text-[#172033] text-sm">
                  {whatsappCount ?? 0} complaints logged
                </span>
              </div>
              <Link
                href="/whatsapp"
                className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 hover:text-emerald-950 transition-colors"
              >
                <span>Open Console</span>
                <ExternalLink className="h-3 w-3" />
              </Link>
            </div>

            {/* Latest Inbound Ticket Card */}
            {latestWhatsApp ? (
              <div className="p-4 border-b border-[#E2E8F0] space-y-2 bg-white">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-emerald-800 flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                    Latest: Ahmed (Field Staff)
                  </span>
                  <span className="text-[#667085] font-medium">{timeAgo(latestWhatsApp.created_at)}</span>
                </div>

                <p className="text-xs text-[#172033] font-medium italic line-clamp-2 bg-[#F8FAFC] p-2 rounded border border-slate-200/60">
                  &ldquo;{latestWhatsApp.description}&rdquo;
                </p>

                <div className="flex items-center justify-between pt-1">
                  <span className="font-mono text-xs font-bold text-[#172033]">
                    {latestWhatsApp.ticket_number}
                  </span>
                  <Link
                    href={`/complaints/${latestWhatsApp.id}`}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-700"
                  >
                    <span>View Complaint</span>
                    <ArrowRight className="h-3 w-3" />
                  </Link>
                </div>
              </div>
            ) : null}

            {/* Ingestion Pipeline Overview */}
            <div className="p-4 space-y-2 bg-[#F8FAFC]/50 text-xs">
              <p className="text-[10px] font-bold uppercase tracking-wider text-[#667085]">
                Two-Way Operations Pipeline
              </p>
              {[
                { step: '1', label: 'Field Staff texts issue via WhatsApp' },
                { step: '2', label: 'Manager assigns matching Service Person' },
                { step: '3', label: 'Notification dispatched to WhatsApp' },
                { step: '4', label: 'Service Person replies with acknowledgment' },
              ].map((item) => (
                <div key={item.step} className="flex items-center gap-2.5 bg-white p-2 rounded border border-[#E2E8F0]">
                  <span className="h-5 w-5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center justify-center shrink-0">
                    {item.step}
                  </span>
                  <span className="text-[11px] font-medium text-[#172033]">{item.label}</span>
                </div>
              ))}
            </div>

            <div className="p-3 border-t border-[#E2E8F0] bg-white">
              <Link
                href="/whatsapp"
                className="flex items-center justify-center gap-2 w-full h-9 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white text-xs font-bold rounded-lg transition-colors"
              >
                <MessageCircle className="h-3.5 w-3.5" />
                Launch WhatsApp Operations Console
              </Link>
            </div>
          </div>

          {/* Quick Actions Card */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-5 shadow-sm space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
              Facility Dispatch Actions
            </h3>
            <div className="space-y-2">
              <Link
                href="/complaints/new"
                className="flex items-center justify-center gap-2 w-full h-10 bg-[#4F46E5] hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors"
              >
                <Zap className="h-3.5 w-3.5" /> Log Manual Incident
              </Link>
              <Link
                href="/service-persons"
                className="flex items-center justify-center gap-2 w-full h-10 bg-white hover:bg-slate-50 border border-[#E2E8F0] text-[#172033] text-xs font-semibold rounded-lg transition-colors"
              >
                <UserCheck className="h-3.5 w-3.5 text-indigo-600" /> Service Persons Directory
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
