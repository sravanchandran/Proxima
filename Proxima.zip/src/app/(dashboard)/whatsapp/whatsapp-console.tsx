'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  Send,
  Check,
  CheckCheck,
  ArrowRight,
  Loader2,
  MessageCircle,
  Phone,
  Video,
  MoreVertical,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
} from 'lucide-react'
import { ServicePersonRecord, WhatsAppMessageRecord } from '@/lib/services/demo-store'
import { formatPhoneNumber } from '@/lib/phone'

interface ComplaintItem {
  id: string
  ticket_number: string
  title: string
  description: string
  category: string
  priority: string
  status: string
  source: string
  photo_url: string | null
  created_at: string
  buildings?: { name: string }
  floors?: { name: string }
  areas?: { name: string }
  assets?: { name: string; asset_id: string }
  floor_name?: string
  area_name?: string
  latest_service_response?: string
}

interface WhatsAppConsoleProps {
  initialComplaints: ComplaintItem[]
  initialMessages?: WhatsAppMessageRecord[]
  servicePersons?: ServicePersonRecord[]
}

interface ScenarioOption {
  id: string
  type: 'STAFF_NEW' | 'SERVICE_REPLY'
  label: string
  senderName: string
  senderRole: string
  senderPhone: string
  text: string
  photoUrl: string | null
  photoLabel: string | null
  targetTag: string
}

const PRESET_MESSAGES: ScenarioOption[] = [
  {
    id: 'ac-101',
    type: 'STAFF_NEW',
    label: 'Field Staff: Office 101 AC Failure (New Incident)',
    senderName: 'Ahmed',
    senderRole: 'Field Operations Technician',
    senderPhone: '+971 50 849 2011',
    text: 'AC is not cooling in Office 101. Temperature is very high (31°C). Please check urgently.',
    photoUrl: '/demo/ac-room-101.jpg',
    photoLabel: 'AC Unit — Office 101',
    targetTag: 'Floor 1 / Office 101',
  },
  {
    id: 'sp-reply-ac',
    type: 'SERVICE_REPLY',
    label: 'Service Person: Ahmed Khan Response (CoolTech HVAC)',
    senderName: 'Ahmed Khan',
    senderRole: 'HVAC Specialist (CoolTech Services)',
    senderPhone: '+971501234567',
    text: "CMP-001 - Received. I'll inspect the AC in Office 101 within 30 minutes.",
    photoUrl: null,
    photoLabel: null,
    targetTag: 'Response to CMP-001',
  },
  {
    id: 'pump-leak',
    type: 'STAFF_NEW',
    label: 'Field Staff: B1 Pump Leak (New Incident)',
    senderName: 'Salem',
    senderRole: 'Building Supervisor',
    senderPhone: '+971 50 849 2011',
    text: 'Water leakage observed near secondary booster pump in Basement B1 Plant Room. Pressure drop detected.',
    photoUrl: null,
    photoLabel: null,
    targetTag: 'Basement / Plant Room',
  },
  {
    id: 'sp-reply-plumb',
    type: 'SERVICE_REPLY',
    label: 'Service Person: Ali Hassan Response (Dubai Plumbing)',
    senderName: 'Ali Hassan',
    senderRole: 'Plumbing Specialist (Dubai Plumbing LLC)',
    senderPhone: '+971503456789',
    text: "Received. On-site with replacement valve gaskets for the booster pump.",
    photoUrl: null,
    photoLabel: null,
    targetTag: 'Response to Active Assignment',
  },
]

export function WhatsAppConsole({
  initialComplaints,
  initialMessages = [],
  servicePersons = [],
}: WhatsAppConsoleProps) {
  const [selectedPreset, setSelectedPreset] = useState<ScenarioOption>(PRESET_MESSAGES[0])
  const [customMessage, setCustomMessage] = useState(PRESET_MESSAGES[0].text)
  const [attachPhoto, setAttachPhoto] = useState(true)

  // Simulation state
  const [isProcessing, setIsProcessing] = useState(false)
  const [currentStep, setCurrentStep] = useState<number>(0)
  const [resultComplaint, setResultComplaint] = useState<ComplaintItem | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [recentList, setRecentList] = useState<ComplaintItem[]>(initialComplaints)
  const [liveMessages, setLiveMessages] = useState<WhatsAppMessageRecord[]>(initialMessages)
  const [filterDirection, setFilterDirection] = useState<'ALL' | 'INBOUND' | 'OUTBOUND'>('ALL')

  const handleSelectPreset = (preset: ScenarioOption) => {
    setSelectedPreset(preset)
    setCustomMessage(preset.text)
    setAttachPhoto(!!preset.photoUrl)
    setResultComplaint(null)
    setCurrentStep(0)
    setErrorMessage(null)
  }

  const handleSendMessage = async () => {
    if (isProcessing) return

    setIsProcessing(true)
    setErrorMessage(null)
    setResultComplaint(null)
    setCurrentStep(1)

    try {
      await new Promise((r) => setTimeout(r, 350))
      setCurrentStep(2)

      const res = await fetch('/api/whatsapp/demo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderName: selectedPreset.senderName,
          senderRole: selectedPreset.senderRole,
          senderPhone: selectedPreset.senderPhone,
          text: customMessage,
          photoUrl: attachPhoto ? selectedPreset.photoUrl : null,
        }),
      })

      const data = await res.json()

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to process WhatsApp message')
      }

      await new Promise((r) => setTimeout(r, 350))
      setCurrentStep(3)

      await new Promise((r) => setTimeout(r, 300))
      setCurrentStep(4)

      if (data.complaint) {
        setResultComplaint(data.complaint)
        setRecentList((prev) => [data.complaint, ...prev.filter((c) => c.id !== data.complaint.id)])
      }

      // Add to live messages feed
      const newMsg: WhatsAppMessageRecord = {
        id: `wam-live-${Date.now()}`,
        complaint_id: data.complaint?.id || null,
        service_person_id: data.servicePerson?.id || null,
        direction: 'INBOUND',
        message_text: customMessage,
        status: 'RECEIVED',
        sender_phone: selectedPreset.senderPhone,
        created_at: new Date().toISOString(),
      }
      setLiveMessages((prev) => [newMsg, ...prev])
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error executing WhatsApp pipeline.'
      console.error('Demo simulation error:', err)
      setErrorMessage(msg)
    } finally {
      setIsProcessing(false)
    }
  }

  const displayedMessages = liveMessages.filter((m) => {
    if (filterDirection === 'ALL') return true
    return m.direction === filterDirection
  })

  return (
    <div className="space-y-6">
      {/* Top Telemetry Banner */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center shrink-0">
            <MessageCircle className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <h2 className="text-sm font-bold text-[#172033]">Two-Way WhatsApp Cloud Gateway Active</h2>
              <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.2 rounded-full">
                Hotline &amp; Dispatch Connected
              </span>
            </div>
            <p className="text-xs text-[#667085] mt-0.5">
              Live Webhook: <code className="font-mono text-indigo-600 bg-indigo-50 px-1 rounded">/api/whatsapp/webhook</code> · Two-way deterministic ticket matching
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs text-[#667085] self-stretch sm:self-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-[#E2E8F0]">
          <div>
            <span className="block text-[10px] uppercase font-semibold text-[#667085]">Hotline Number</span>
            <span className="font-mono font-semibold text-[#172033]">+971 4 800 7799</span>
          </div>
          <div className="h-7 w-px bg-slate-200" />
          <div>
            <span className="block text-[10px] uppercase font-semibold text-[#667085]">Active Facility</span>
            <span className="font-semibold text-[#172033]">Anantara Business Tower</span>
          </div>
        </div>
      </div>

      {/* Main Split Layout: Left (Chat) + Right (Processing Engine & Two-Way Feed) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ── LEFT: WhatsApp Chat Simulator (5 cols) ── */}
        <div className="lg:col-span-5 space-y-4">
          {/* Preset Selector */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-3.5 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#667085]">
                Simulate Communication Flow
              </span>
              <span className="text-[10px] text-indigo-600 font-semibold bg-indigo-50 px-1.5 py-0.5 rounded">
                Interactive Test
              </span>
            </div>

            <div className="grid grid-cols-1 gap-1.5">
              {PRESET_MESSAGES.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => handleSelectPreset(preset)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg text-xs transition-all cursor-pointer ${
                    selectedPreset.id === preset.id
                      ? 'bg-emerald-50 text-emerald-950 border border-emerald-300 font-semibold shadow-2xs'
                      : 'text-[#667085] hover:bg-slate-50 border border-transparent'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="truncate pr-2">{preset.label}</span>
                    <span
                      className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded shrink-0 ${
                        preset.type === 'SERVICE_REPLY'
                          ? 'bg-indigo-100 text-indigo-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {preset.type === 'SERVICE_REPLY' ? 'Service Reply' : 'New Ticket'}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Smartphone / WhatsApp Chat Interface */}
          <div className="bg-white border border-[#CBD5E1] rounded-2xl shadow-md overflow-hidden flex flex-col">
            {/* WhatsApp App Bar */}
            <div className="bg-[#075E54] text-white px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <div className="h-10 w-10 rounded-full bg-[#128C7E] flex items-center justify-center font-bold text-white text-sm ring-2 ring-white/30">
                    {selectedPreset.senderName.substring(0, 1)}
                  </div>
                  <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-[#075E54]" />
                </div>
                <div>
                  <h3 className="text-sm font-bold leading-tight">{selectedPreset.senderName}</h3>
                  <p className="text-[11px] text-emerald-200 leading-none mt-0.5 truncate max-w-[200px]">
                    {selectedPreset.senderRole} · Online
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-white/80">
                <Phone className="h-4 w-4" />
                <Video className="h-4 w-4 ml-1" />
                <MoreVertical className="h-4 w-4 ml-1" />
              </div>
            </div>

            {/* Chat Body Wallpaper */}
            <div
              className="p-4 space-y-4 min-h-[300px] max-h-[360px] overflow-y-auto bg-[#EFEAE2] relative"
              style={{
                backgroundImage: 'radial-gradient(#0000000d 1px, transparent 1px)',
                backgroundSize: '12px 12px',
              }}
            >
              {/* Date separator */}
              <div className="flex justify-center">
                <span className="bg-white/80 backdrop-blur-xs text-[10px] font-semibold text-[#667085] px-2.5 py-0.5 rounded-full shadow-2xs">
                  TODAY
                </span>
              </div>

              {/* Message Bubble */}
              <div className="flex justify-start">
                <div className="max-w-[88%] bg-white rounded-2xl rounded-tl-xs p-3.5 shadow-sm border border-slate-200/60 space-y-2">
                  <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-1.5">
                    <span className="text-xs font-bold text-emerald-800 truncate">
                      {selectedPreset.senderName}
                    </span>
                    <span className="text-[10px] text-[#667085] font-mono shrink-0">
                      {formatPhoneNumber(selectedPreset.senderPhone)}
                    </span>
                  </div>

                  <p className="text-xs text-[#172033] leading-relaxed font-normal whitespace-pre-wrap">
                    {customMessage}
                  </p>

                  {/* Attachment if present */}
                  {attachPhoto && selectedPreset.photoUrl && (
                    <div className="rounded-xl overflow-hidden border border-slate-200 bg-slate-50 mt-2">
                      <div className="relative h-40 w-full bg-slate-100">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={selectedPreset.photoUrl}
                          alt={selectedPreset.photoLabel || 'Attachment'}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="px-2.5 py-1.5 bg-white flex items-center justify-between text-[11px]">
                        <span className="font-semibold text-[#172033] truncate">
                          📷 {selectedPreset.photoLabel || 'AC-Room-101.jpg'}
                        </span>
                        <span className="text-[#667085] text-[10px]">1.2 MB</span>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-end gap-1 pt-1 text-[10px] text-[#667085]">
                    <span>10:45 AM</span>
                    <CheckCheck className="h-3.5 w-3.5 text-blue-500" />
                  </div>
                </div>
              </div>
            </div>

            {/* Chat Action Footer */}
            <div className="p-3 bg-[#F0F2F5] border-t border-slate-200 flex flex-col gap-2">
              <div className="flex items-center justify-between text-xs px-1">
                <span className="text-[#667085] text-[11px]">
                  Tag: <strong className="text-[#172033]">{selectedPreset.targetTag}</strong>
                </span>
                {selectedPreset.photoUrl && (
                  <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-[#667085]">
                    <input
                      type="checkbox"
                      checked={attachPhoto}
                      onChange={(e) => setAttachPhoto(e.target.checked)}
                      className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500 h-3.5 w-3.5"
                    />
                    <span>Include photo</span>
                  </label>
                )}
              </div>

              <button
                type="button"
                onClick={handleSendMessage}
                disabled={isProcessing}
                className="w-full h-11 bg-[#25D366] hover:bg-[#20bd5a] active:bg-[#1caa51] text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Processing Inbound Message...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    <span>Send Message to Hotline</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* ── RIGHT: Ingestion Pipeline & Two-Way Stream (7 cols) ── */}
        <div className="lg:col-span-7 space-y-6">
          {/* Pipeline Progress */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-3">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-[#172033]">
                  Automated Two-Way Pipeline
                </h3>
                <p className="text-xs text-[#667085] mt-0.5">
                  Identifies sender role, matches tickets deterministically, and dispatches updates.
                </p>
              </div>
              <span className="text-[10px] font-mono bg-slate-100 text-[#172033] px-2 py-0.5 rounded border border-slate-200">
                PROXIMA GATEWAY
              </span>
            </div>

            {/* Visual Step Timeline */}
            <div className="space-y-3">
              {[
                {
                  step: 1,
                  title: 'WhatsApp Gateway Ingestion',
                  desc: 'Inbound message received and verified via Meta Cloud Webhook.',
                },
                {
                  step: 2,
                  title: 'Sender & Entity Resolution',
                  desc: 'Checked sender phone number against Service Persons master & complaints registry.',
                },
                {
                  step: 3,
                  title: 'Deterministic Workflow Execution',
                  desc: 'Updated complaint record, registered audit activity, and synced timeline.',
                },
                {
                  step: 4,
                  title: 'Database Commit & Timeline Synchronized',
                  desc: 'Committed event to Supabase. Instant reflection on dashboard and detail view.',
                },
              ].map((item) => {
                const isPassed = currentStep > item.step || (resultComplaint && currentStep >= 4)
                const isCurrent = currentStep === item.step && isProcessing

                return (
                  <div
                    key={item.step}
                    className={`flex items-start gap-3.5 p-3 rounded-lg border transition-all ${
                      isCurrent
                        ? 'bg-indigo-50/60 border-indigo-200 shadow-2xs'
                        : isPassed
                        ? 'bg-emerald-50/40 border-emerald-200/80'
                        : 'bg-white border-[#E2E8F0] opacity-65'
                    }`}
                  >
                    <div
                      className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                        isPassed
                          ? 'bg-emerald-600 text-white'
                          : isCurrent
                          ? 'bg-indigo-600 text-white animate-pulse'
                          : 'bg-slate-100 text-slate-400'
                      }`}
                    >
                      {isPassed ? <Check className="h-4 w-4" /> : item.step}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p
                          className={`text-xs font-bold ${
                            isPassed
                              ? 'text-emerald-900'
                              : isCurrent
                              ? 'text-indigo-900'
                              : 'text-[#172033]'
                          }`}
                        >
                          {item.title}
                        </p>
                        {isPassed && (
                          <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                            <Check className="h-3 w-3" /> Confirmed
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#667085] mt-0.5 leading-normal">{item.desc}</p>
                    </div>
                  </div>
                )
              })}
            </div>

            {errorMessage && (
              <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-xs text-red-700 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-red-500 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Success Banner when Complaint is updated/created */}
            {resultComplaint && (
              <div className="rounded-xl border-2 border-emerald-500 bg-emerald-50/60 p-4 space-y-3 animate-fade-in shadow-xs">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="h-8 w-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">
                      <Check className="h-4 w-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                        Operational Workflow Synced
                      </span>
                      <h4 className="text-base font-extrabold text-[#172033]">
                        {resultComplaint.ticket_number} — {resultComplaint.title}
                      </h4>
                    </div>
                  </div>

                  <Link
                    href={`/complaints/${resultComplaint.id}`}
                    className="inline-flex items-center justify-center gap-1.5 h-9 px-4 bg-[#4F46E5] hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all shrink-0 cursor-pointer"
                  >
                    <span>View Complaint</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* ── TWO-WAY WHATSAPP OPERATIONS LOG (Prompt Requirement 26) ── */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div className="flex items-center gap-2">
                <MessageCircle className="h-4 w-4 text-emerald-600" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                  Two-Way WhatsApp Operations Stream
                </h4>
              </div>

              {/* Direction Filter */}
              <div className="inline-flex rounded-lg border border-[#E2E8F0] bg-white p-0.5 text-xs">
                {(['ALL', 'INBOUND', 'OUTBOUND'] as const).map((dir) => (
                  <button
                    key={dir}
                    type="button"
                    onClick={() => setFilterDirection(dir)}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-semibold cursor-pointer transition-all ${
                      filterDirection === dir
                        ? 'bg-[#172033] text-white shadow-2xs'
                        : 'text-[#667085] hover:text-[#172033]'
                    }`}
                  >
                    {dir}
                  </button>
                ))}
              </div>
            </div>

            <div className="divide-y divide-[#E2E8F0] max-h-[380px] overflow-y-auto">
              {displayedMessages.map((msg) => {
                const isInbound = msg.direction === 'INBOUND'
                const sp = servicePersons.find((p) => p.id === msg.service_person_id)

                return (
                  <div key={msg.id} className="p-4 hover:bg-[#F8FAFC] transition-colors space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        {isInbound ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                            <ArrowDownLeft className="h-3 w-3 text-emerald-600" />
                            INBOUND ✓
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200">
                            <ArrowUpRight className="h-3 w-3 text-indigo-600" />
                            OUTBOUND ✓
                          </span>
                        )}

                        <span className="font-bold text-[#172033]">
                          {isInbound
                            ? sp
                              ? `${sp.name} · Service Person`
                              : 'Field Staff'
                            : 'Proxima Facilities HQ'}
                        </span>
                      </div>

                      <span className="text-[11px] text-[#667085] font-mono">
                        {new Date(msg.created_at).toLocaleTimeString('en-US', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    <p className="text-xs text-[#172033] bg-[#F8FAFC] p-2.5 rounded-lg border border-slate-200/70 italic leading-relaxed">
                      &ldquo;{msg.message_text}&rdquo;
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-[#667085] pt-0.5">
                      <div className="flex items-center gap-2">
                        {msg.complaint_id && (
                          <span className="font-mono font-semibold text-indigo-600">
                            Ticket Ref: {msg.complaint_id.substring(0, 8)}...
                          </span>
                        )}
                        {msg.sender_phone && (
                          <span>From: {formatPhoneNumber(msg.sender_phone)}</span>
                        )}
                        {msg.recipient_phone && (
                          <span>To: {formatPhoneNumber(msg.recipient_phone)}</span>
                        )}
                      </div>

                      <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                        <CheckCheck className="h-3.5 w-3.5 text-blue-500" />
                        {msg.status}
                      </span>
                    </div>
                  </div>
                )
              })}

              {displayedMessages.length === 0 && (
                <div className="p-8 text-center text-xs text-[#667085]">
                  No WhatsApp messages logged yet under filter &quot;{filterDirection}&quot;.
                </div>
              )}
            </div>
          </div>

          {/* Recent WhatsApp Tickets Card */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageCircle className="h-4 w-4 text-emerald-600" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                  Recent Hotline Incidents
                </h4>
              </div>
              <span className="text-[11px] text-[#667085] font-medium">
                {recentList.length} tickets recorded
              </span>
            </div>

            <div className="divide-y divide-[#E2E8F0]">
              {recentList.slice(0, 4).map((c) => (
                <Link
                  key={c.id}
                  href={`/complaints/${c.id}`}
                  className="flex items-center justify-between px-5 py-3 hover:bg-[#F8FAFC] transition-colors group"
                >
                  <div className="min-w-0 flex items-center gap-2.5">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-[#172033] group-hover:text-indigo-600 transition-colors">
                          {c.ticket_number}
                        </span>
                        <span className="text-slate-300 text-xs">·</span>
                        <span className="text-xs font-medium text-[#172033] truncate max-w-xs">
                          {c.title}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#667085] mt-0.5 truncate">
                        {c.areas?.name || c.area_name ? `${c.floors?.name || c.floor_name || 'Floor 1'} · ${c.areas?.name || c.area_name}` : 'Anantara Business Tower'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-4">
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                      WhatsApp
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 text-[#667085] group-hover:text-indigo-600 transition-colors" />
                  </div>
                </Link>
              ))}

              {recentList.length === 0 && (
                <div className="p-6 text-center text-xs text-[#667085]">
                  No hotline complaints registered yet.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
