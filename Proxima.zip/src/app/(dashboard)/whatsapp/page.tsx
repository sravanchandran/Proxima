import { createClient } from '@/lib/supabase/server'
import { WhatsAppConsole } from './whatsapp-console'
import { MessageCircle } from 'lucide-react'
import { getWhatsAppMessages } from '@/lib/services/whatsapp-messages'
import { getServicePersons } from '@/lib/services/service-persons'

export const dynamic = 'force-dynamic'

export default async function WhatsAppOperationsPage() {
  const supabase = await createClient()

  // Fetch recent WhatsApp complaints, messages and service persons
  const [{ data: whatsappComplaints }, whatsappMessages, servicePersons] = await Promise.all([
    supabase
      .from('complaints')
      .select('*, buildings(name), floors(name), areas(name), assets(name, asset_id)')
      .order('created_at', { ascending: false })
      .limit(10),
    getWhatsAppMessages({ limit: 30 }),
    getServicePersons(),
  ])

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded flex items-center gap-1">
            <MessageCircle className="h-3 w-3 text-emerald-600" />
            Two-Way Field Messaging Gateway
          </span>
          <span className="text-xs text-[#667085]">· Real-Time Automated Dispatch &amp; Technician Replies</span>
        </div>
        <h1 className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">WhatsApp Operations Console</h1>
        <p className="text-sm text-[#667085] mt-0.5">
          Two-way facilities communication: Field staff report incidents, managers dispatch assignments, and certified service persons acknowledge via WhatsApp.
        </p>
      </div>

      {/* Interactive Operations Console */}
      <WhatsAppConsole
        initialComplaints={whatsappComplaints || []}
        initialMessages={whatsappMessages || []}
        servicePersons={servicePersons || []}
      />
    </div>
  )
}
