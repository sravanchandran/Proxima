import { createClient } from '@/lib/supabase/server'
import {
  Plus,
  AlertTriangle,
  Clock,
  CheckCircle2,
  ShieldAlert,
  MessageSquare,
  Globe,
  ArrowRight,
  User,
} from 'lucide-react'
import Link from 'next/link'
import { getServicePersons } from '@/lib/services/service-persons'
import { getMemoryAssignments } from '@/lib/services/demo-store'

export const dynamic = 'force-dynamic'

const STATUS_STYLE: Record<string, string> = {
  'Open': 'bg-red-50 text-red-700 border border-red-200/90 font-semibold',
  'In Progress': 'bg-amber-50 text-amber-700 border border-amber-200/90 font-semibold',
  'Resolved': 'bg-emerald-50 text-emerald-700 border border-emerald-200/90 font-semibold',
  'Closed': 'bg-slate-100 text-slate-600 border border-slate-200 font-medium',
}

const PRIORITY_BADGE: Record<string, { label: string; className: string }> = {
  'Critical': {
    label: 'Critical',
    className: 'bg-red-50 text-red-700 border border-red-200 font-semibold',
  },
  'High': {
    label: 'High',
    className: 'bg-amber-50 text-amber-700 border border-amber-200 font-semibold',
  },
  'Medium': {
    label: 'Medium',
    className: 'bg-yellow-50 text-yellow-800 border border-yellow-200 font-medium',
  },
  'Low': {
    label: 'Low',
    className: 'bg-slate-50 text-slate-600 border border-slate-200 font-normal',
  },
}

function getLeftBorderClass(priority: string) {
  if (priority === 'Critical') return 'border-l-4 border-l-red-500'
  if (priority === 'High') return 'border-l-4 border-l-amber-500'
  return 'border-l-4 border-l-transparent'
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  return `${Math.floor(h / 24)}d ago`
}

export default async function ComplaintsPage() {
  const supabase = await createClient()

  const [{ data: complaints, count }, servicePersons] = await Promise.all([
    supabase
      .from('complaints')
      .select('*, buildings(name), floors(name), areas(name), assets(name)', { count: 'exact' })
      .order('created_at', { ascending: false }),
    getServicePersons(),
  ])

  const servicePersonMap = new Map(servicePersons.map((sp) => [sp.id, sp]))
  const memAssignments = getMemoryAssignments()

  const openCount = complaints?.filter((c) => c.status === 'Open').length ?? 0
  const inProgressCount = complaints?.filter((c) => c.status === 'In Progress').length ?? 0
  const resolvedCount = complaints?.filter((c) => c.status === 'Resolved').length ?? 0
  const criticalCount = complaints?.filter((c) => c.priority === 'Critical' && c.status !== 'Closed').length ?? 0

  const kpis = [
    {
      label: 'Open',
      count: openCount,
      subtext: 'Requires dispatch',
      icon: AlertTriangle,
      iconBg: 'bg-red-50 text-red-600 border border-red-100',
    },
    {
      label: 'In Progress',
      count: inProgressCount,
      subtext: 'Under active review',
      icon: Clock,
      iconBg: 'bg-amber-50 text-amber-600 border border-amber-100',
    },
    {
      label: 'Resolved',
      count: resolvedCount,
      subtext: 'Closed / completed',
      icon: CheckCircle2,
      iconBg: 'bg-emerald-50 text-emerald-600 border border-emerald-100',
    },
    {
      label: 'Critical',
      count: criticalCount,
      subtext: 'Immediate attention',
      icon: ShieldAlert,
      iconBg: 'bg-red-100 text-red-700 border border-red-200',
    },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
              Facilities Operations
            </span>
            <span className="text-xs text-[#667085]">· Anantara Business Tower</span>
          </div>
          <h1 className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">Complaints &amp; Incidents</h1>
          <p className="text-sm text-[#667085] mt-0.5">
            Operational register across all building systems, tenant reports, service assignments, and two-way WhatsApp dispatches.
          </p>
        </div>
        <Link
          href="/complaints/new"
          className="inline-flex items-center justify-center gap-2 h-10 px-4 bg-[#4F46E5] hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors shrink-0"
        >
          <Plus className="h-4 w-4" />
          Log Complaint
        </Link>
      </div>

      {/* KPI Summary Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <div
            key={kpi.label}
            className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-sm hover:border-slate-300 transition-all flex items-start justify-between"
          >
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#667085]">{kpi.label}</p>
              <p className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">{kpi.count}</p>
              <p className="text-[11px] text-[#667085] mt-0.5">{kpi.subtext}</p>
            </div>
            <div className={`h-9 w-9 rounded-lg flex items-center justify-center shrink-0 ${kpi.iconBg}`}>
              <kpi.icon className="h-4.5 w-4.5" />
            </div>
          </div>
        ))}
      </div>

      {/* Main Table Card */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
        {/* Table Header */}
        <div
          className="grid gap-3 px-5 py-3 border-b border-[#E2E8F0] bg-[#F8FAFC] text-[11px] font-semibold uppercase tracking-wider text-[#667085]"
          style={{ gridTemplateColumns: '110px 1.8fr 1.4fr 1.6fr 90px 105px 85px' }}
        >
          <span>Ticket</span>
          <span>Issue &amp; Category</span>
          <span>Assigned Service Person</span>
          <span>Latest Service Response</span>
          <span>Priority</span>
          <span>Status</span>
          <span className="text-right">Source</span>
        </div>

        {/* Rows */}
        <div className="divide-y divide-[#E2E8F0]">
          {complaints?.map((c) => {
            const priorityConfig = PRIORITY_BADGE[c.priority] ?? PRIORITY_BADGE['Medium']
            const leftBorderClass = getLeftBorderClass(c.priority)

            // Resolve assignment
            const assignedSpId =
              c.assigned_service_person_id || memAssignments[c.id]?.servicePersonId
            const assignedPerson = assignedSpId ? servicePersonMap.get(assignedSpId) : null

            // Resolve latest response
            const latestResponseText =
              c.latest_service_response || memAssignments[c.id]?.latestResponse
            const latestResponseTime =
              c.latest_service_response_at || memAssignments[c.id]?.latestResponseAt

            return (
              <Link
                key={c.id}
                href={`/complaints/${c.id}`}
                className={`grid gap-3 px-5 py-3.5 items-center hover:bg-[#F8FAFC] transition-colors group ${leftBorderClass}`}
                style={{ gridTemplateColumns: '110px 1.8fr 1.4fr 1.6fr 90px 105px 85px' }}
              >
                {/* 1. Ticket & Time */}
                <div>
                  <span className="font-mono text-xs font-semibold text-[#172033] block group-hover:text-indigo-600 transition-colors">
                    {c.ticket_number}
                  </span>
                  <span className="text-[11px] text-[#667085] mt-0.5 block">{timeAgo(c.created_at)}</span>
                </div>

                {/* 2. Title & Category */}
                <div className="min-w-0 pr-2">
                  <p className="text-sm font-semibold text-[#172033] group-hover:text-indigo-600 truncate transition-colors leading-snug">
                    {c.title}
                  </p>
                  <div className="flex items-center gap-1.5 mt-0.5 text-[11px] text-[#667085] truncate">
                    <span className="font-medium text-indigo-700 bg-indigo-50 px-1.5 py-0.2 rounded text-[10px]">
                      {c.category || 'HVAC'}
                    </span>
                    <span>·</span>
                    <span>{c.areas?.name || c.floors?.name || 'Main Area'}</span>
                  </div>
                </div>

                {/* 3. Assigned Service Person */}
                <div className="min-w-0">
                  {assignedPerson ? (
                    <div className="flex items-center gap-2">
                      <div className="h-6 w-6 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center font-bold text-[10px] shrink-0">
                        {assignedPerson.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <span className="text-xs font-semibold text-[#172033] block truncate">
                          {assignedPerson.name}
                        </span>
                        <span className="text-[10px] text-[#667085] block truncate">
                          {assignedPerson.company}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs text-slate-400 italic">
                      <User className="h-3 w-3" />
                      <span>Unassigned</span>
                    </span>
                  )}
                </div>

                {/* 4. Latest Service Response */}
                <div className="min-w-0 pr-2">
                  {latestResponseText ? (
                    <div>
                      <p className="text-xs font-medium text-[#172033] italic truncate">
                        &ldquo;{latestResponseText}&rdquo;
                      </p>
                      <span className="text-[10px] text-emerald-700 font-medium block mt-0.5">
                        {latestResponseTime ? timeAgo(latestResponseTime) : 'recently'} via WhatsApp
                      </span>
                    </div>
                  ) : assignedPerson ? (
                    <span className="text-[11px] text-amber-700 font-medium flex items-center gap-1">
                      <Clock className="h-3 w-3 text-amber-500 shrink-0" />
                      <span>Awaiting service response</span>
                    </span>
                  ) : (
                    <span className="text-[11px] text-slate-400 italic">
                      —
                    </span>
                  )}
                </div>

                {/* 5. Priority */}
                <div>
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] ${priorityConfig.className}`}>
                    {priorityConfig.label}
                  </span>
                </div>

                {/* 6. Status */}
                <div>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] ${STATUS_STYLE[c.status] ?? 'bg-slate-100 text-slate-600'}`}>
                    {c.status}
                  </span>
                </div>

                {/* 7. Source */}
                <div className="flex items-center justify-end gap-1.5">
                  {c.source === 'WhatsApp' ? (
                    <span className="source-whatsapp inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full">
                      <MessageSquare className="h-3 w-3 text-emerald-600" />
                      <span>WA</span>
                    </span>
                  ) : (
                    <span className="source-web inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full">
                      <Globe className="h-3 w-3 text-blue-600" />
                      <span>Web</span>
                    </span>
                  )}
                </div>
              </Link>
            )
          })}

          {!complaints?.length && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="h-12 w-12 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400 mb-3">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <p className="text-sm font-semibold text-[#172033]">No operational complaints found</p>
              <p className="text-xs text-[#667085] mt-1 max-w-sm">
                Create a complaint manually or send a message to the integrated WhatsApp hotline to simulate real field reporting.
              </p>
              <Link
                href="/complaints/new"
                className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-700 transition-colors"
              >
                Log a new complaint <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          )}
        </div>

        {/* Footer */}
        {(complaints?.length ?? 0) > 0 && (
          <div className="px-5 py-3 border-t border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between text-xs text-[#667085]">
            <span>
              Showing <strong className="text-[#172033]">{complaints?.length}</strong> of <strong className="text-[#172033]">{count}</strong> registered incidents
            </span>
            <span className="text-[11px] text-[#667085]">
              Real-time synchronization with WhatsApp Field Gateway and Service Assignment Dispatch
            </span>
          </div>
        )}
      </div>
    </div>
  )
}
