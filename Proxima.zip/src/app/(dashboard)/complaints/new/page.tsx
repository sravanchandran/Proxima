import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ArrowLeft, AlertCircle, Image as ImageIcon, Sparkles } from 'lucide-react'
import Link from 'next/link'
import { createComplaint } from './actions'
import { SERVICE_TYPES } from '@/lib/constants/service-types'

export default function NewComplaintPage() {
  return (
    <div className="max-w-3xl space-y-6">
      {/* Back button */}
      <Link
        href="/complaints"
        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#667085] hover:text-[#172033] transition-colors"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back to Complaints
      </Link>

      {/* Page Title with Subtle Colored Icon Block */}
      <div className="flex items-start gap-4">
        <div className="h-12 w-12 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-[#4F46E5] shrink-0 shadow-xs">
          <AlertCircle className="h-6 w-6" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
              Incident Intake
            </span>
            <span className="text-xs text-[#667085]">· Anantara Business Tower</span>
          </div>
          <h1 className="text-2xl font-bold text-[#172033] mt-1 tracking-tight">Log Operational Complaint</h1>
          <p className="text-sm text-[#667085] mt-0.5">
            Submit a maintenance ticket into the central facility dispatch register.
          </p>
        </div>
      </div>

      {/* Form Container */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
        <form action={createComplaint}>
          {/* Section 1: Incident Overview */}
          <div className="p-6 border-b border-[#E2E8F0] space-y-5">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#172033]">
              <span className="h-2 w-2 rounded-full bg-indigo-600" />
              Incident Overview
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="title" className="text-xs font-semibold text-[#172033]">
                Issue Title <span className="text-red-500">*</span>
              </Label>
              <Input
                id="title"
                name="title"
                required
                placeholder="e.g. Chilled water leakage near FCU unit"
                className="h-10 bg-white border-[#E2E8F0] text-[#172033] placeholder:text-[#667085]/60 focus-visible:ring-indigo-500 focus-visible:border-indigo-500 text-sm"
              />
              <p className="text-[11px] text-[#667085]">
                Provide a concise summary of the failure, disruption, or hazard.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="category" className="text-xs font-semibold text-[#172033]">
                  System Category
                </Label>
                <Select name="category" defaultValue="HVAC">
                  <SelectTrigger className="h-10 bg-white border-[#E2E8F0] text-[#172033] focus:ring-indigo-500 text-sm">
                    <SelectValue placeholder="Select system category" />
                  </SelectTrigger>
                  <SelectContent>
                    {SERVICE_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="priority" className="text-xs font-semibold text-[#172033]">
                  Operational Priority
                </Label>
                <Select name="priority" defaultValue="Medium">
                  <SelectTrigger className="h-10 bg-white border-[#E2E8F0] text-[#172033] focus:ring-indigo-500 text-sm">
                    <SelectValue placeholder="Select operational priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low">Low — Routine maintenance</SelectItem>
                    <SelectItem value="Medium">Medium — Standard SLA (24h)</SelectItem>
                    <SelectItem value="High">High — Urgent response (4h)</SelectItem>
                    <SelectItem value="Critical">Critical — Immediate hazard (1h)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="description" className="text-xs font-semibold text-[#172033]">
                Detailed Description
              </Label>
              <Textarea
                id="description"
                name="description"
                placeholder="Describe observations, affected areas, equipment tags, or safety concerns..."
                className="min-h-[110px] bg-white border-[#E2E8F0] text-[#172033] placeholder:text-[#667085]/60 focus-visible:ring-indigo-500 focus-visible:border-indigo-500 text-sm leading-relaxed"
              />
            </div>
          </div>

          {/* Section 2: Photo Upload & Attachment */}
          <div className="p-6 border-b border-[#E2E8F0] space-y-4 bg-[#F8FAFC]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#172033]">
                <ImageIcon className="h-3.5 w-3.5 text-indigo-600" />
                Evidence &amp; Photo Attachment
              </div>
              <span className="text-[11px] text-[#667085] font-medium">Optional attachment</span>
            </div>

            <div className="rounded-xl border-2 border-dashed border-[#CBD5E1] bg-white p-5 hover:border-indigo-400 transition-colors">
              <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="h-12 w-12 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
                  <ImageIcon className="h-6 w-6" />
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <p className="text-sm font-semibold text-[#172033]">Upload incident photo</p>
                  <p className="text-xs text-[#667085] mt-0.5">
                    Images uploaded here will be stored in Supabase Storage and visible on the ticket detail page.
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-[#F1F5F9]">
                <Input
                  id="photo"
                  name="photo"
                  type="file"
                  accept="image/*"
                  className="h-10 bg-[#F8FAFC] border-[#E2E8F0] text-xs text-[#172033] cursor-pointer file:cursor-pointer file:font-semibold file:text-xs file:text-indigo-700 file:bg-indigo-50 file:border-0 file:rounded-md file:mr-3 file:py-1 file:px-2"
                />
              </div>
            </div>
          </div>

          {/* Form Actions Footer */}
          <div className="px-6 py-4 bg-[#F8FAFC] flex items-center justify-between gap-4">
            <p className="text-xs text-[#667085]">
              Ticket will be routed to the facilities operations desk immediately.
            </p>
            <div className="flex items-center gap-3 shrink-0">
              <Link
                href="/complaints"
                className="h-10 px-4 text-xs font-semibold text-[#667085] hover:text-[#172033] transition-colors inline-flex items-center"
              >
                Cancel
              </Link>
              <button
                type="submit"
                className="h-10 px-6 bg-[#4F46E5] hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-semibold rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="h-4 w-4" />
                Log Complaint
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
