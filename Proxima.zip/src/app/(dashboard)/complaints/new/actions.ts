'use server'

import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'

export async function createComplaint(formData: FormData) {
  const supabase = await createClient()
  
  const title = formData.get('title') as string
  const category = formData.get('category') as string
  const priority = formData.get('priority') as string
  const description = formData.get('description') as string
  const photo = formData.get('photo') as File | null

  if (!title) {
    throw new Error('Title is required')
  }

  // To associate it with our demo building
  const { data: buildings } = await supabase.from('buildings').select('id').limit(1)
  const buildingId = buildings?.[0]?.id

  let photo_url = null

  // Handle Photo Upload
  if (photo && photo.size > 0) {
    const fileExt = photo.name.split('.').pop()
    const fileName = `${Math.random().toString(36).substring(2, 15)}_${Date.now()}.${fileExt}`
    const filePath = `public/${fileName}`

    const { error: uploadError } = await supabase.storage
      .from('complaint_photos')
      .upload(filePath, photo)

    if (uploadError) {
      console.error('Error uploading photo:', uploadError)
    } else {
      const { data: publicUrlData } = supabase.storage
        .from('complaint_photos')
        .getPublicUrl(filePath)
      
      photo_url = publicUrlData.publicUrl
    }
  }

  // Generate a random ticket number for the demo
  const ticket_number = `CMP-${Math.floor(Math.random() * 10000)}`

  const { error } = await supabase.from('complaints').insert({
    ticket_number,
    title,
    category,
    priority,
    description,
    photo_url,
    building_id: buildingId,
    source: 'Web',
    status: 'Open'
  })

  if (error) {
    console.error('Failed to create complaint:', error)
    throw new Error('Failed to create complaint')
  }

  revalidatePath('/complaints')
  redirect('/complaints')
}
