'use server'

import { createClient } from '@/lib/supabase/server'
import { revalidatePath } from 'next/cache'
import { assignComplaint, resendAssignmentWhatsApp } from '@/lib/services/assignments'
import { recordComplaintActivity } from '@/lib/services/whatsapp-messages'

export async function updateComplaintStatus(complaintId: string, status: string, previousStatus?: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('complaints')
    .update({
      status,
      latest_activity: `Status updated to ${status}`,
    })
    .eq('id', complaintId)

  if (error) {
    console.error('Error updating status:', error)
    throw new Error('Failed to update status')
  }

  // Record status change activity in audit log
  const prev = previousStatus ? `${previousStatus} → ` : ''
  await recordComplaintActivity({
    complaint_id: complaintId,
    activity_type: 'status_changed',
    message: `Manager changed status: ${prev}${status}`,
    metadata: {
      new_status: status,
      previous_status: previousStatus,
    },
  })

  revalidatePath(`/complaints/${complaintId}`)
  revalidatePath('/complaints')
  revalidatePath('/dashboard')
}

export async function assignComplaintAction(complaintId: string, servicePersonId: string) {
  const result = await assignComplaint(complaintId, servicePersonId)

  revalidatePath(`/complaints/${complaintId}`)
  revalidatePath('/complaints')
  revalidatePath('/dashboard')
  revalidatePath('/service-persons')

  return result
}

export async function resendAssignmentWhatsAppAction(complaintId: string) {
  const result = await resendAssignmentWhatsApp(complaintId)

  revalidatePath(`/complaints/${complaintId}`)
  revalidatePath('/complaints')
  revalidatePath('/dashboard')

  return result
}
