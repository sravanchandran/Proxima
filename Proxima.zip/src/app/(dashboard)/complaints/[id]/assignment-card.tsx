'use client'

import { useState, useTransition } from 'react'
import Link from 'next/link'
import {
  UserCheck,
  Building2,
  Phone,
  CheckCircle2,
  AlertTriangle,
  Send,
  RotateCw,
  Loader2,
  ExternalLink,
  ChevronDown,
  UserX,
  X,
} from 'lucide-react'
import { ServicePersonRecord } from '@/lib/services/demo-store'
import { formatPhoneNumber } from '@/lib/phone'
import { assignComplaintAction, resendAssignmentWhatsAppAction } from './actions'

interface AssignmentCardProps {
  complaintId: string
  complaintCategory: string
  assignedPerson: ServicePersonRecord | null
  eligibleServicePersons: ServicePersonRecord[]
}

export function AssignmentCard({
  complaintId,
  complaintCategory,
  assignedPerson,
  eligibleServicePersons,
}: AssignmentCardProps) {
  const [selectedPersonId, setSelectedPersonId] = useState<string>(
    assignedPerson ? assignedPerson.id : eligibleServicePersons[0]?.id || ''
  )
  const [isChanging, setIsChanging] = useState(false)
  const [isPending, startTransition] = useTransition()
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [deliveryFailed, setDeliveryFailed] = useState(false)

  const selectedPerson = eligibleServicePersons.find((p) => p.id === selectedPersonId)

  const handleAssign = () => {
    if (!selectedPersonId) return
    setErrorMessage(null)
    setSuccessMessage(null)
    setDeliveryFailed(false)

    startTransition(async () => {
      try {
        const res = await assignComplaintAction(complaintId, selectedPersonId)
        if (res.whatsappResult?.status === 'FAILED') {
          setDeliveryFailed(true)
          setErrorMessage(`Assigned, but WhatsApp delivery failed: ${res.whatsappResult.error || 'Network error'}`)
        } else {
          setSuccessMessage(`Assigned to ${res.servicePerson.name}. WhatsApp dispatch confirmed!`)
          setIsChanging(false)
        }
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Failed to assign complaint'
        setErrorMessage(msg)
      }
    })
  }

  const handleResend = () => {
    setErrorMessage(null)
    setSuccessMessage(null)
    setDeliveryFailed(false)

    startTransition(async () => {
      try {
        const res = await resendAssignmentWhatsAppAction(complaintId)
        if (res.whatsappResult?.status === 'FAILED') {
          setDeliveryFailed(true)
          setErrorMessage(`WhatsApp resend failed: ${res.whatsappResult.error || 'Network error'}`)
        } else {
          setSuccessMessage(`WhatsApp assignment notification resent successfully!`)
        }
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Failed to resend WhatsApp notification'
        setErrorMessage(msg)
      }
    })
  }

  return (
    <div className="bg-white border-2 border-indigo-500/20 rounded-xl shadow-xs overflow-hidden">
      {/* Card Header */}
      <div className="bg-[#1E293B] text-white px-5 py-3.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="h-7 w-7 rounded-lg bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
            <UserCheck className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-white">
              Service Person Assignment
            </h3>
            <p className="text-[11px] text-slate-300">
              Matched category: <strong className="text-indigo-300">{complaintCategory}</strong>
            </p>
          </div>
        </div>

        {assignedPerson && !isChanging ? (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            <CheckCircle2 className="h-3 w-3 text-emerald-400" />
            Assigned
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
            Pending Assignment
          </span>
        )}
      </div>

      <div className="p-5 space-y-4">
        {/* Alerts */}
        {errorMessage && (
          <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="font-semibold">{errorMessage}</p>
              {deliveryFailed && (
                <button
                  type="button"
                  onClick={handleResend}
                  disabled={isPending}
                  className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-bold text-red-800 underline hover:no-underline cursor-pointer"
                >
                  <RotateCw className="h-3 w-3" /> Retry WhatsApp Notification
                </button>
              )}
            </div>
          </div>
        )}

        {successMessage && (
          <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* ── CASE 1: Already Assigned (Read View) ── */}
        {assignedPerson && !isChanging && (
          <div className="space-y-4">
            <div className="rounded-xl border border-indigo-100 bg-indigo-50/30 p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="h-11 w-11 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                    {assignedPerson.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-[#172033] flex items-center gap-2">
                      {assignedPerson.name}
                      <span className="text-[10px] font-semibold bg-indigo-100 text-indigo-800 border border-indigo-200 px-2 py-0.2 rounded-full">
                        {assignedPerson.service_type} Specialist
                      </span>
                    </h4>
                    <p className="text-xs text-[#667085] flex items-center gap-1.5 mt-0.5">
                      <Building2 className="h-3.5 w-3.5 text-slate-400" />
                      <span>{assignedPerson.company}</span>
                    </p>
                  </div>
                </div>

                <Link
                  href={`/service-persons/${assignedPerson.id}`}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                >
                  <span>Profile</span>
                  <ExternalLink className="h-3 w-3" />
                </Link>
              </div>

              <div className="pt-2 border-t border-indigo-100/60 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-emerald-800 font-mono font-medium">
                  <Phone className="h-3.5 w-3.5 text-emerald-600" />
                  <span>{formatPhoneNumber(assignedPerson.whatsapp_number)}</span>
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-[#667085]">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
                  <span>WhatsApp assignment dispatched</span>
                </div>
              </div>
            </div>

            {/* Actions: Change / Resend */}
            <div className="flex items-center justify-between gap-3 pt-1">
              <button
                type="button"
                onClick={() => setIsChanging(true)}
                className="h-9 px-3.5 text-xs font-semibold rounded-lg border border-[#E2E8F0] hover:bg-slate-50 text-[#172033] transition-colors cursor-pointer"
              >
                Change Service Person
              </button>

              <button
                type="button"
                onClick={handleResend}
                disabled={isPending}
                className="h-9 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-2xs transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {isPending ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Send className="h-3.5 w-3.5" />
                )}
                <span>Resend WhatsApp</span>
              </button>
            </div>
          </div>
        )}

        {/* ── CASE 2: Unassigned OR Changing Assignment (Selection View) ── */}
        {(!assignedPerson || isChanging) && (
          <div className="space-y-4">
            {isChanging && (
              <div className="flex items-center justify-between text-xs text-[#667085] bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                <span>
                  Currently assigned to: <strong className="text-[#172033]">{assignedPerson?.name}</strong>
                </span>
                <button
                  type="button"
                  onClick={() => setIsChanging(false)}
                  className="text-xs text-slate-500 hover:text-[#172033] flex items-center gap-1 font-semibold cursor-pointer"
                >
                  <X className="h-3.5 w-3.5" /> Cancel Change
                </button>
              </div>
            )}

            {/* If candidates exist */}
            {eligibleServicePersons.length > 0 ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                    Select Matching Service Person
                  </label>
                  <span className="text-[11px] text-[#667085]">
                    {eligibleServicePersons.length} eligible for {complaintCategory}
                  </span>
                </div>

                {/* Candidate Selection Dropdown */}
                <div className="space-y-2">
                  <div className="relative">
                    <select
                      value={selectedPersonId}
                      onChange={(e) => setSelectedPersonId(e.target.value)}
                      className="w-full h-11 pl-3.5 pr-10 text-xs font-semibold rounded-lg border border-[#CBD5E1] bg-white text-[#172033] focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:outline-none appearance-none cursor-pointer"
                    >
                      {eligibleServicePersons.map((person) => (
                        <option key={person.id} value={person.id}>
                          {person.name} — {person.service_type} · {person.company} ({formatPhoneNumber(person.whatsapp_number)})
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#667085] pointer-events-none" />
                  </div>

                  {/* Candidate Preview Card */}
                  {selectedPerson && (
                    <div className="p-3.5 rounded-xl border border-indigo-100 bg-indigo-50/40 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs">
                      <div className="flex items-center gap-2.5">
                        <div className="h-8 w-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                          {selectedPerson.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-[#172033]">{selectedPerson.name}</p>
                          <p className="text-[11px] text-[#667085]">
                            {selectedPerson.service_type} · {selectedPerson.company}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 font-mono text-emerald-800 font-semibold text-[11px] bg-white px-2.5 py-1 rounded border border-indigo-100 self-start sm:self-auto">
                        <Phone className="h-3 w-3 text-emerald-600" />
                        <span>{formatPhoneNumber(selectedPerson.whatsapp_number)}</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Assign Action Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleAssign}
                    disabled={isPending || !selectedPersonId}
                    className="w-full h-10 bg-[#4F46E5] hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Assigning &amp; Sending WhatsApp Notification...</span>
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        <span>Assign Complaint &amp; Notify via WhatsApp</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ) : (
              /* No candidates available for this category */
              <div className="p-5 rounded-xl border border-amber-200 bg-amber-50 text-center space-y-3">
                <UserX className="h-8 w-8 mx-auto text-amber-600" />
                <div>
                  <h4 className="text-xs font-bold text-amber-900">
                    No active {complaintCategory} service persons available
                  </h4>
                  <p className="text-[11px] text-amber-800 mt-1 max-w-sm mx-auto">
                    To assign this complaint, you must have an active contractor or technician registered under{' '}
                    <strong>{complaintCategory}</strong> in the master register.
                  </p>
                </div>

                <Link
                  href="/service-persons"
                  className="inline-flex items-center gap-1.5 h-8 px-4 bg-white hover:bg-amber-100/60 border border-amber-300 text-amber-900 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  <span>Manage Service Persons</span>
                  <ExternalLink className="h-3 w-3" />
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
