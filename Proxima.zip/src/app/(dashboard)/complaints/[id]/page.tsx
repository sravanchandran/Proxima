import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import {
  MapPin,
  ArrowLeft,
  Calendar,
  Tag,
  MessageSquare,
  Globe,
  Check,
  Phone,
  User,
  UserCheck,
} from 'lucide-react'
import { StatusUpdater } from './status-updater'
import { AssignmentCard } from './assignment-card'
import { ResponseCard } from './response-card'
import { ActivityTimeline } from './activity-timeline'
import { getActiveServicePersonsByType } from '@/lib/services/service-persons'
import { getComplaintAssignment } from '@/lib/services/assignments'
import { getComplaintActivities } from '@/lib/services/whatsapp-messages'
import { formatPhoneNumber } from '@/lib/phone'

const STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed']

const STATUS_BADGE: Record<string, string> = {
  'Open': 'bg-red-50 text-red-700 border border-red-200 font-semibold',
  'In Progress': 'bg-amber-50 text-amber-700 border border-amber-200 font-semibold',
  'Resolved': 'bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold',
  'Closed': 'bg-slate-100 text-slate-600 border border-slate-200 font-medium',
}

const PRIORITY_BADGE: Record<string, string> = {
  'Critical': 'bg-red-50 text-red-700 border border-red-200 font-semibold',
  'High': 'bg-amber-50 text-amber-700 border border-amber-200 font-semibold',
  'Medium': 'bg-yellow-50 text-yellow-800 border border-yellow-200 font-medium',
  'Low': 'bg-slate-50 text-slate-600 border border-slate-200 font-normal',
}

function StatusTimeline({ current }: { current: string }) {
  const currentIdx = STATUSES.indexOf(current)

  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      {STATUSES.map((s, i) => {
        const isDone = i < currentIdx
        const isActive = i === currentIdx

        return (
          <div key={s} className="flex items-center">
            <div
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold transition-all ${
                isActive
                  ? STATUS_BADGE[s] + ' shadow-2xs'
                  : isDone
                  ? 'bg-emerald-50/70 text-emerald-800 border border-emerald-200/60'
                  : 'bg-slate-50 text-[#667085] border border-slate-200 opacity-60'
              }`}
            >
              {isDone ? (
                <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0" />
              ) : isActive ? (
                <span className="h-2 w-2 rounded-full bg-current animate-pulse shrink-0" />
              ) : (
                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 shrink-0" />
              )}
              <span>{s}</span>
            </div>

            {i < STATUSES.length - 1 && (
              <div
                className={`h-0.5 w-4 mx-1 ${
                  isDone ? 'bg-emerald-300' : 'bg-slate-200'
                }`}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}

export default async function ComplaintDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const supabase = await createClient()
  const { id } = await params

  const { data: complaint } = await supabase
    .from('complaints')
    .select('*, buildings(name), floors(name), areas(name), assets(asset_id, name)')
    .eq('id', id)
    .single()

  if (!complaint) notFound()

  const isWhatsApp = complaint.source === 'WhatsApp'
  const category = complaint.category || 'HVAC'

  // Load Assignment Data, Eligible Service Persons, and Activities
  const [assignmentData, eligibleServicePersons, activities] = await Promise.all([
    getComplaintAssignment(id),
    getActiveServicePersonsByType(category),
    getComplaintActivities(id),
  ])

  const assignedPerson = assignmentData.assignedServicePerson
  const latestResponse = assignmentData.latestResponse
  const latestResponseAt = assignmentData.latestResponseAt

  // Extract WhatsApp metadata if available
  let whatsappMeta = {
    senderName: 'Ahmed',
    senderRole: 'Field Technician',
    senderPhone: '+971 50 849 2011',
    channel: 'WhatsApp Cloud API',
    originalMessage: complaint.description,
  }

  if (complaint.updated_description) {
    try {
      const parsed = JSON.parse(complaint.updated_description)
      if (parsed.senderName) {
        whatsappMeta = {
          ...whatsappMeta,
          ...parsed,
        }
      }
    } catch {
      // Use fallback metadata
    }
  }

  return (
    <div className="max-w-6xl space-y-6">
      {/* Back button */}
      <Link
        href="/complaints"
        className="inline-flex items-center gap-1.5 text-xs font-medium text-[#667085] hover:text-[#172033] transition-colors"
      >
        <ArrowLeft className="h-3.5 w-3.5" /> Back to Complaints
      </Link>

      {/* Ticket Overview Header Card */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-6 shadow-sm">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex-1 min-w-0">
            {/* Badges row */}
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              {isWhatsApp ? (
                <span className="source-whatsapp inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full">
                  <MessageSquare className="h-3.5 w-3.5 text-emerald-600" />
                  <span>WhatsApp Ingestion</span>
                </span>
              ) : (
                <span className="source-web inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full">
                  <Globe className="h-3.5 w-3.5 text-blue-600" />
                  <span>Web Operations</span>
                </span>
              )}

              <span className="font-mono text-xs font-semibold text-[#172033] bg-[#F1F5F9] px-2 py-0.5 rounded">
                {complaint.ticket_number}
              </span>

              <span className={`text-xs px-2 py-0.5 rounded ${PRIORITY_BADGE[complaint.priority] ?? 'bg-slate-50 text-slate-700'}`}>
                {complaint.priority} Priority
              </span>

              <span className="text-xs px-2.5 py-0.5 rounded-md font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                {category}
              </span>
            </div>

            <h1 className="text-2xl font-bold text-[#172033] tracking-tight leading-snug">
              {complaint.title}
            </h1>
            <p className="text-xs text-[#667085] mt-1.5 flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5 text-[#667085]" />
              Logged on {new Date(complaint.created_at).toLocaleString('en-GB', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
          </div>

          {/* Current status pill */}
          <div className="shrink-0">
            <span className={`inline-flex px-3 py-1 rounded-full text-xs tracking-wider uppercase ${STATUS_BADGE[complaint.status]}`}>
              {complaint.status}
            </span>
          </div>
        </div>

        {/* Status Timeline & Quick Actions */}
        <div className="mt-6 pt-5 border-t border-[#E2E8F0] flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1.5">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Lifecycle Progression</p>
            <StatusTimeline current={complaint.status} />
          </div>

          <StatusUpdater complaintId={complaint.id} currentStatus={complaint.status} />
        </div>
      </div>

      {/* Two columns: Details & Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6">
        {/* Left Column: Assignment + Service Response + Timeline + Origin */}
        <div className="space-y-6">
          {/* 1. Service Person Assignment Card */}
          <AssignmentCard
            complaintId={complaint.id}
            complaintCategory={category}
            assignedPerson={assignedPerson}
            eligibleServicePersons={eligibleServicePersons}
          />

          {/* 2. Service Response Card */}
          {assignedPerson && (
            <ResponseCard
              assignedPerson={assignedPerson}
              latestResponse={latestResponse}
              latestResponseAt={latestResponseAt}
            />
          )}

          {/* 3. WhatsApp Origin Communication Card (shown when source is WhatsApp) */}
          {isWhatsApp && (
            <div className="bg-white border-2 border-emerald-500/80 rounded-xl shadow-xs overflow-hidden">
              <div className="bg-[#075E54] text-white px-5 py-3.5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="h-7 w-7 rounded-full bg-white/20 flex items-center justify-center font-bold text-xs">
                    WA
                  </div>
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                      Reported Through WhatsApp Hotline
                    </h3>
                    <p className="text-[11px] text-emerald-100">
                      Verified Field Staff Inbound Dispatch
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold bg-emerald-700 text-white px-2 py-0.5 rounded">
                  Cloud Gateway
                </span>
              </div>

              <div className="p-5 space-y-4 bg-emerald-50/20">
                {/* Staff metadata */}
                <div className="flex items-center justify-between border-b border-emerald-100 pb-3 text-xs">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-emerald-700" />
                    <div>
                      <span className="font-bold text-[#172033]">{whatsappMeta.senderName}</span>
                      <span className="text-[#667085]"> · {whatsappMeta.senderRole}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-[#667085] font-mono text-[11px]">
                    <Phone className="h-3 w-3 text-emerald-600" />
                    <span>{whatsappMeta.senderPhone}</span>
                  </div>
                </div>

                {/* WhatsApp message bubble */}
                <div className="bg-white rounded-xl p-4 border border-emerald-200/80 shadow-2xs space-y-2">
                  <p className="text-xs text-[#172033] leading-relaxed whitespace-pre-wrap font-normal">
                    &ldquo;{complaint.description}&rdquo;
                  </p>
                  <div className="flex items-center justify-end gap-1 text-[10px] text-[#667085] pt-1">
                    <span>
                      {new Date(complaint.created_at).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4. Description Card (Standard Narrative for Web complaints) */}
          {!isWhatsApp && (
            <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
              <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC]">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                  Incident Narrative &amp; Description
                </h3>
              </div>
              <div className="p-5">
                <p className="text-sm text-[#172033] leading-relaxed whitespace-pre-wrap">
                  {complaint.description || 'No additional notes or description provided for this incident.'}
                </p>
              </div>
            </div>
          )}

          {/* 5. Attached Photo */}
          {complaint.photo_url && (
            <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
              <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                  Attached Photographic Evidence
                </h3>
                <span className="text-[11px] text-[#667085] font-medium">Incident Inspection Image</span>
              </div>
              <div className="p-5 bg-[#F8FAFC]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={complaint.photo_url}
                  alt="Incident attachment"
                  className="w-full max-h-96 object-contain rounded-lg border border-[#E2E8F0] bg-white shadow-xs"
                />
              </div>
            </div>
          )}

          {/* 6. Chronological Activity & Communication Timeline */}
          <ActivityTimeline
            activities={activities}
            createdDate={complaint.created_at}
            source={complaint.source}
          />
        </div>

        {/* Right Column: Meta & Facility Context */}
        <div className="space-y-6">
          {/* Assignment Overview Widget */}
          {assignedPerson && (
            <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
              <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center gap-2">
                <UserCheck className="h-4 w-4 text-indigo-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                  Assigned Contractor
                </h3>
              </div>
              <div className="p-5 space-y-3 text-xs">
                <div>
                  <p className="text-[10px] font-semibold uppercase text-[#667085]">Specialist Name</p>
                  <p className="text-sm font-bold text-[#172033] mt-0.5">{assignedPerson.name}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase text-[#667085]">Company</p>
                  <p className="text-xs font-semibold text-[#172033] mt-0.5">{assignedPerson.company}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase text-[#667085]">WhatsApp Hotline</p>
                  <p className="font-mono text-xs font-bold text-emerald-800 mt-0.5">
                    {formatPhoneNumber(assignedPerson.whatsapp_number)}
                  </p>
                </div>
                <div className="pt-2 border-t border-[#E2E8F0]">
                  <Link
                    href={`/service-persons/${assignedPerson.id}`}
                    className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 block"
                  >
                    View Service Person Workload →
                  </Link>
                </div>
              </div>
            </div>
          )}

          {/* Location Context */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center gap-2">
              <MapPin className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                Location &amp; Facility Context
              </h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Building</p>
                <p className="text-sm font-semibold text-[#172033] mt-0.5">
                  {complaint.buildings?.name ?? 'Anantara Business Tower'}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Floor / Level</p>
                <p className="text-sm font-medium text-[#172033] mt-0.5">
                  {complaint.floors?.name ?? 'Floor 1'}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Specific Area / Room</p>
                <p className="text-sm font-medium text-[#172033] mt-0.5">
                  {complaint.areas?.name ?? 'Office 101'}
                </p>
              </div>

              {complaint.assets && (
                <div className="pt-3 border-t border-[#E2E8F0]">
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Target Asset</p>
                  <p className="text-xs font-mono font-semibold text-indigo-600 mt-0.5">
                    {complaint.assets.asset_id}
                  </p>
                  <p className="text-sm font-semibold text-[#172033]">
                    {complaint.assets.name}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Operational Attributes */}
          <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center gap-2">
              <Tag className="h-4 w-4 text-indigo-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
                Operational Attributes
              </h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Category</p>
                <p className="text-sm font-medium text-[#172033] mt-0.5">{category}</p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Priority Level</p>
                <div className="mt-1">
                  <span className={`inline-flex text-xs px-2 py-0.5 rounded ${PRIORITY_BADGE[complaint.priority] ?? 'bg-slate-50 text-slate-700'}`}>
                    {complaint.priority}
                  </span>
                </div>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Ingestion Channel</p>
                <p className="text-sm font-medium text-[#172033] mt-0.5">
                  {isWhatsApp ? 'WhatsApp Cloud Hotline (+971 4 800 7799)' : 'Web Operations Console'}
                </p>
              </div>

              <div>
                <p className="text-[11px] font-semibold uppercase tracking-wider text-[#667085]">Reporter Attribution</p>
                <p className="text-xs font-medium text-emerald-800 mt-0.5">
                  {isWhatsApp ? `${whatsappMeta.senderName} (${whatsappMeta.senderRole})` : 'Facilities Staff'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
