'use client'

import { useState, useTransition } from 'react'
import { updateComplaintStatus } from './actions'
import { CheckCircle2, Loader2, ArrowRight } from 'lucide-react'

const STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'] as const
type Status = typeof STATUSES[number]

const STEP_ACTIVE_STYLE: Record<Status, string> = {
  'Open': 'bg-[#EF4444] text-white border-[#EF4444]',
  'In Progress': 'bg-[#F59E0B] text-white border-[#F59E0B]',
  'Resolved': 'bg-[#10B981] text-white border-[#10B981]',
  'Closed': 'bg-slate-600 text-white border-slate-600',
}

export function StatusUpdater({ complaintId, currentStatus }: {
  complaintId: string
  currentStatus: string
}) {
  const [status, setStatus] = useState(currentStatus as Status)
  const [saved, setSaved] = useState(false)
  const [isPending, startTransition] = useTransition()

  const handleSelect = (s: Status) => {
    if (s === status) return
    setStatus(s)
    setSaved(false)
  }

  const handleSave = () => {
    if (status === currentStatus) return
    startTransition(async () => {
      await updateComplaintStatus(complaintId, status, currentStatus)
      setSaved(true)
    })
  }

  return (
    <div className="flex items-center gap-2.5 flex-wrap">
      <span className="text-[11px] font-semibold uppercase tracking-wider text-[#667085] mr-1">
        Update Status:
      </span>
      <div className="inline-flex rounded-lg border border-[#E2E8F0] bg-white p-0.5 shadow-2xs">
        {STATUSES.map((s) => {
          const isSelected = status === s
          return (
            <button
              key={s}
              type="button"
              onClick={() => handleSelect(s)}
              disabled={isPending}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                isSelected
                  ? `${STEP_ACTIVE_STYLE[s]} shadow-xs`
                  : 'text-[#667085] hover:text-[#172033] hover:bg-slate-50'
              } ${isPending ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {s}
            </button>
          )
        })}
      </div>

      <button
        type="button"
        onClick={handleSave}
        disabled={isPending || status === currentStatus || saved}
        className={`h-8 px-3.5 text-xs font-semibold rounded-lg border transition-all flex items-center gap-1.5 shadow-2xs ${
          saved
            ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
            : status === currentStatus
            ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
            : 'bg-[#4F46E5] hover:bg-indigo-700 text-white border-[#4F46E5] cursor-pointer'
        }`}
      >
        {isPending ? (
          <Loader2 className="h-3 w-3 animate-spin" />
        ) : saved ? (
          <CheckCircle2 className="h-3 w-3" />
        ) : (
          <ArrowRight className="h-3 w-3" />
        )}
        {isPending ? 'Saving…' : saved ? 'Saved' : 'Save Status'}
      </button>
    </div>
  )
}
