import {
  Plus,
  UserCheck,
  Send,
  MessageCircle,
  RefreshCw,
  Clock,
  FileText,
} from 'lucide-react'
import { ComplaintActivityRecord } from '@/lib/services/demo-store'

interface ActivityTimelineProps {
  activities: ComplaintActivityRecord[]
  createdDate: string
  source: string
}

export function ActivityTimeline({
  activities,
  createdDate,
  source,
}: ActivityTimelineProps) {
  // Consolidate events including base creation if not present in activities
  const allEvents = [...activities]

  const hasCreated = allEvents.some((a) => a.activity_type === 'created')
  if (!hasCreated) {
    allEvents.unshift({
      id: 'creation-event',
      complaint_id: '',
      service_person_id: null,
      activity_type: 'created',
      message:
        source === 'WhatsApp'
          ? 'Complaint created from WhatsApp hotline'
          : 'Complaint logged via Web Operations Console',
      created_at: createdDate,
    })
  }

  // Sort ascending by created_at
  allEvents.sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())

  const getEventBadge = (type: string) => {
    switch (type) {
      case 'created':
        return {
          icon: Plus,
          bg: 'bg-blue-100 text-blue-700 border-blue-200',
          label: 'Ticket Ingestion',
        }
      case 'assigned':
      case 'reassigned':
        return {
          icon: UserCheck,
          bg: 'bg-indigo-100 text-indigo-700 border-indigo-200',
          label: 'Service Assignment',
        }
      case 'whatsapp_sent':
        return {
          icon: Send,
          bg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          label: 'WhatsApp Outbound',
        }
      case 'whatsapp_received':
        return {
          icon: MessageCircle,
          bg: 'bg-emerald-500 text-white border-emerald-600',
          label: 'WhatsApp Inbound',
        }
      case 'status_changed':
        return {
          icon: RefreshCw,
          bg: 'bg-amber-100 text-amber-800 border-amber-200',
          label: 'Status Progression',
        }
      default:
        return {
          icon: FileText,
          bg: 'bg-slate-100 text-slate-700 border-slate-200',
          label: 'System Audit',
        }
    }
  }

  return (
    <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-sm overflow-hidden">
      <div className="px-5 py-3.5 border-b border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-indigo-600" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#172033]">
            Audit &amp; Communication Timeline
          </h3>
        </div>
        <span className="text-[11px] text-[#667085] font-medium">
          {allEvents.length} operational milestones
        </span>
      </div>

      <div className="p-5">
        <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
          {allEvents.map((evt, idx) => {
            const config = getEventBadge(evt.activity_type)
            const Icon = config.icon

            const formattedTime = new Date(evt.created_at).toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit',
            })
            const formattedDate = new Date(evt.created_at).toLocaleDateString('en-GB', {
              day: 'numeric',
              month: 'short',
            })

            return (
              <div key={evt.id || idx} className="relative group">
                {/* Node icon */}
                <div
                  className={`absolute -left-6 top-0.5 h-5 w-5 rounded-full flex items-center justify-center text-[10px] shadow-2xs border ${config.bg}`}
                >
                  <Icon className="h-2.5 w-2.5" />
                </div>

                <div className="bg-[#F8FAFC] hover:bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 transition-all space-y-1.5 shadow-2xs">
                  <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
                      {config.label}
                    </span>
                    <span className="text-[11px] text-[#667085] font-mono">
                      {formattedDate} · {formattedTime}
                    </span>
                  </div>

                  <p className="text-xs font-medium text-[#172033] leading-relaxed">
                    {evt.message}
                  </p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
