'use client'

import { MessageSquare, Clock, CheckCheck } from 'lucide-react'
import { ServicePersonRecord } from '@/lib/services/demo-store'
import { formatPhoneNumber } from '@/lib/phone'

interface ResponseCardProps {
  assignedPerson: ServicePersonRecord | null
  latestResponse: string | null
  latestResponseAt: string | null
}

export function ResponseCard({
  assignedPerson,
  latestResponse,
  latestResponseAt,
}: ResponseCardProps) {
  if (!assignedPerson) {
    return null
  }

  const hasResponse = Boolean(latestResponse && latestResponse.trim().length > 0)

  return (
    <div
      className={`rounded-xl border-2 transition-all shadow-xs overflow-hidden ${
        hasResponse
          ? 'bg-white border-emerald-500/80'
          : 'bg-white border-slate-200'
      }`}
    >
      {/* Header */}
      <div
        className={`px-5 py-3.5 flex items-center justify-between ${
          hasResponse ? 'bg-[#075E54] text-white' : 'bg-[#F8FAFC] text-[#172033] border-b border-[#E2E8F0]'
        }`}
      >
        <div className="flex items-center gap-2.5">
          <div
            className={`h-7 w-7 rounded-lg flex items-center justify-center font-bold text-xs ${
              hasResponse ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
            }`}
          >
            <MessageSquare className="h-4 w-4" />
          </div>
          <div>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${hasResponse ? 'text-white' : 'text-[#172033]'}`}>
              Service Person WhatsApp Response
            </h3>
            <p className={`text-[11px] ${hasResponse ? 'text-emerald-100' : 'text-[#667085]'}`}>
              Two-Way Mobile Feedback Loop
            </p>
          </div>
        </div>

        {hasResponse ? (
          <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-emerald-700 text-white px-2.5 py-0.5 rounded-full">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-300 animate-pulse" />
            Response Received
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-full">
            <Clock className="h-3 w-3 text-amber-500" />
            Awaiting Reply
          </span>
        )}
      </div>

      {/* Body */}
      <div className="p-5">
        {hasResponse ? (
          <div className="space-y-3">
            {/* Person Attribution */}
            <div className="flex items-center justify-between border-b border-emerald-100/80 pb-2.5 text-xs">
              <div className="flex items-center gap-2">
                <div className="h-7 w-7 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
                  {assignedPerson.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <span className="font-bold text-[#172033]">{assignedPerson.name}</span>
                  <span className="text-[#667085]"> · {assignedPerson.company}</span>
                </div>
              </div>

              <div className="text-[11px] text-[#667085] font-mono">
                {formatPhoneNumber(assignedPerson.whatsapp_number)}
              </div>
            </div>

            {/* Inbound WhatsApp Chat Bubble */}
            <div className="bg-[#EFEAE2]/50 p-4 rounded-xl border border-emerald-200/60 space-y-2">
              <div className="flex items-center justify-between text-[10px] text-[#667085]">
                <span className="font-bold text-emerald-900 uppercase tracking-wider">
                  Received via WhatsApp Hotline
                </span>
                {latestResponseAt && (
                  <span>
                    {new Date(latestResponseAt).toLocaleTimeString('en-US', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                )}
              </div>

              <div className="bg-white rounded-lg p-3.5 shadow-2xs border border-slate-200/60">
                <p className="text-xs text-[#172033] font-medium leading-relaxed italic whitespace-pre-wrap">
                  &ldquo;{latestResponse}&rdquo;
                </p>
                <div className="flex items-center justify-end gap-1 text-[10px] text-[#667085] pt-1.5">
                  <CheckCheck className="h-3.5 w-3.5 text-blue-500" />
                  <span>Verified Service Person Response</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-amber-50/50 border border-amber-200/60 text-xs">
            <div className="h-8 w-8 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
              <Clock className="h-4 w-4" />
            </div>
            <div>
              <p className="font-bold text-[#172033]">
                Awaiting response from {assignedPerson.name}
              </p>
              <p className="text-[#667085] mt-0.5">
                The assignment message has been dispatched to{' '}
                <strong>{formatPhoneNumber(assignedPerson.whatsapp_number)}</strong>. When {assignedPerson.name} replies
                via WhatsApp, their message will automatically appear here.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
