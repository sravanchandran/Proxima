import { login } from './actions'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Building2 } from 'lucide-react'

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ message?: string }>
}) {
  const { message } = await searchParams

  return (
    <div className="flex min-h-screen">
      {/* Left — brand panel */}
      <div className="hidden lg:flex lg:w-[480px] xl:w-[560px] flex-col bg-[oklch(0.155_0.012_247)] text-white px-12 py-16 relative overflow-hidden shrink-0">
        {/* Subtle grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.035]"
          style={{
            backgroundImage: 'linear-gradient(oklch(0.9 0 0) 1px, transparent 1px), linear-gradient(90deg, oklch(0.9 0 0) 1px, transparent 1px)',
            backgroundSize: '32px 32px',
          }}
        />
        {/* Content */}
        <div className="relative z-10 flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center gap-3 mb-auto">
            <div className="h-9 w-9 bg-white/10 border border-white/20 rounded-lg flex items-center justify-center">
              <Building2 className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-bold tracking-tight">PROXIMA</span>
          </div>

          {/* Central message */}
          <div className="mb-auto py-16">
            <h1 className="text-4xl font-bold leading-tight tracking-tight mb-5">
              Facilities<br />Command Center
            </h1>
            <p className="text-white/50 text-base leading-relaxed max-w-[320px]">
              Manage buildings, assets, and operational issues from a single platform. Built for enterprise facilities teams.
            </p>

            <div className="mt-12 space-y-4">
              {[
                { n: '01', label: 'Building & Asset Management' },
                { n: '02', label: 'Complaint & Incident Tracking' },
                { n: '03', label: 'WhatsApp Field Reporting' },
                { n: '04', label: 'Manager Oversight Dashboard' },
              ].map(f => (
                <div key={f.n} className="flex items-center gap-4">
                  <span className="text-xs font-mono text-white/30">{f.n}</span>
                  <span className="h-px flex-1 bg-white/10 max-w-[24px]" />
                  <span className="text-sm text-white/60">{f.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Footer */}
          <div>
            <p className="text-xs text-white/25">Dubai, United Arab Emirates</p>
            <p className="text-xs text-white/20 mt-1">Business Demonstration — v1.0</p>
          </div>
        </div>
      </div>

      {/* Right — login form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-slate-50">
        <div className="w-full max-w-sm">
          {/* Mobile logo */}
          <div className="flex items-center gap-2 mb-10 lg:hidden">
            <Building2 className="h-5 w-5 text-slate-800" />
            <span className="font-bold text-slate-900 tracking-tight">PROXIMA</span>
          </div>

          <h2 className="text-2xl font-bold tracking-tight text-slate-900 mb-1">Sign in</h2>
          <p className="text-sm text-slate-500 mb-8">Enter your credentials to access the platform.</p>

          <form action={login} className="space-y-5">
            <div className="space-y-1.5">
              <label htmlFor="email" className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Email</label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="manager@proxima.demo"
                required
                className="h-10 bg-white border-slate-200 text-slate-900 placeholder:text-slate-400 focus-visible:ring-slate-900/20 focus-visible:border-slate-400"
              />
            </div>
            <div className="space-y-1.5">
              <label htmlFor="password" className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Password</label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="••••••••"
                required
                className="h-10 bg-white border-slate-200 text-slate-900 focus-visible:ring-slate-900/20 focus-visible:border-slate-400"
              />
            </div>

            {message && (
              <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
                {message}
              </div>
            )}

            <Button
              type="submit"
              className="w-full h-10 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm tracking-wide rounded-lg transition-colors"
            >
              Sign In
            </Button>
          </form>

          <p className="mt-8 text-xs text-slate-400 text-center">
            PROXIMA Facilities Management Platform · Demo Build
          </p>
        </div>
      </div>
    </div>
  )
}
