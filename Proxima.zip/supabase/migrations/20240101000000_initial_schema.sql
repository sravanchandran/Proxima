-- Initial Schema for PROXIMA Business Demo

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Profiles
CREATE TABLE public.profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    role TEXT NOT NULL DEFAULT 'field_staff' CHECK (role IN ('manager', 'field_staff')),
    full_name TEXT,
    avatar_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public profiles are viewable by everyone." ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile." ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update own profile." ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- 2. Buildings
CREATE TABLE public.buildings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    address TEXT,
    city TEXT,
    country TEXT,
    description TEXT,
    number_of_floors INTEGER DEFAULT 1,
    status TEXT DEFAULT 'Active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.buildings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Buildings are viewable by everyone." ON public.buildings FOR SELECT USING (true);

-- 3. Floors
CREATE TABLE public.floors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    building_id UUID NOT NULL REFERENCES public.buildings(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    level INTEGER NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.floors ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Floors are viewable by everyone." ON public.floors FOR SELECT USING (true);

-- 4. Areas
CREATE TABLE public.areas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    floor_id UUID NOT NULL REFERENCES public.floors(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.areas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Areas are viewable by everyone." ON public.areas FOR SELECT USING (true);

-- 5. Assets
CREATE TABLE public.assets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_id TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    type TEXT,
    category TEXT,
    building_id UUID REFERENCES public.buildings(id),
    floor_id UUID REFERENCES public.floors(id),
    area_id UUID REFERENCES public.areas(id),
    description TEXT,
    manufacturer TEXT,
    model TEXT,
    serial_number TEXT,
    status TEXT DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Under Maintenance')),
    installation_date DATE,
    photo_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Assets are viewable by everyone." ON public.assets FOR SELECT USING (true);
CREATE POLICY "Assets can be modified by authenticated users." ON public.assets FOR ALL USING (auth.role() = 'authenticated');

-- 6. Complaints
CREATE TABLE public.complaints (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_number TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT,
    priority TEXT DEFAULT 'Medium' CHECK (priority IN ('Low', 'Medium', 'High', 'Critical')),
    building_id UUID REFERENCES public.buildings(id),
    floor_id UUID REFERENCES public.floors(id),
    area_id UUID REFERENCES public.areas(id),
    asset_id UUID REFERENCES public.assets(id),
    reported_by UUID REFERENCES public.profiles(id),
    source TEXT DEFAULT 'Web' CHECK (source IN ('Web', 'WhatsApp')),
    status TEXT DEFAULT 'Open' CHECK (status IN ('Open', 'In Progress', 'Resolved', 'Closed')),
    photo_url TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE public.complaints ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Complaints are viewable by everyone." ON public.complaints FOR SELECT USING (true);
CREATE POLICY "Complaints can be modified by authenticated users." ON public.complaints FOR ALL USING (auth.role() = 'authenticated');

-- Trigger to update updated_at timestamp (generic)
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_profiles_modtime BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_buildings_modtime BEFORE UPDATE ON public.buildings FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_assets_modtime BEFORE UPDATE ON public.assets FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_complaints_modtime BEFORE UPDATE ON public.complaints FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Storage Buckets setup (this requires superuser, in Supabase typically done via UI, but provided for completeness)
INSERT INTO storage.buckets (id, name, public) VALUES ('complaint_photos', 'complaint_photos', true) ON CONFLICT DO NOTHING;
INSERT INTO storage.buckets (id, name, public) VALUES ('asset_photos', 'asset_photos', true) ON CONFLICT DO NOTHING;

-- Allow public access to read files
CREATE POLICY "Public Access" ON storage.objects FOR SELECT USING (bucket_id IN ('complaint_photos', 'asset_photos'));
-- Allow authenticated users to upload files
CREATE POLICY "Auth Uploads" ON storage.objects FOR INSERT WITH CHECK (bucket_id IN ('complaint_photos', 'asset_photos') AND auth.role() = 'authenticated');
