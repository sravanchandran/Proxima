-- Migration: Add rich fields for assets and complaints to match demo UI

-- Assets: add condition, criticality, risk_score, next_ppm, operational_status, system_category
ALTER TABLE public.assets 
  ADD COLUMN IF NOT EXISTS condition TEXT DEFAULT 'Good' CHECK (condition IN ('Excellent', 'Good', 'Fair', 'Poor')),
  ADD COLUMN IF NOT EXISTS criticality TEXT DEFAULT 'Medium' CHECK (criticality IN ('Critical', 'High', 'Medium', 'Low')),
  ADD COLUMN IF NOT EXISTS risk_score INTEGER DEFAULT 50,
  ADD COLUMN IF NOT EXISTS next_ppm DATE,
  ADD COLUMN IF NOT EXISTS operational_status TEXT DEFAULT 'Active' CHECK (operational_status IN ('Running', 'Standby', 'Offline', 'Under Maintenance')),
  ADD COLUMN IF NOT EXISTS system_category TEXT;

-- Complaints: add priority_code (P1/P2/P3), latest_activity, source_detail
ALTER TABLE public.complaints
  ADD COLUMN IF NOT EXISTS priority_code TEXT DEFAULT 'P3',
  ADD COLUMN IF NOT EXISTS latest_activity TEXT,
  ADD COLUMN IF NOT EXISTS updated_description TEXT;
