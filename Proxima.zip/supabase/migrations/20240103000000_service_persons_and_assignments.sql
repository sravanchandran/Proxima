-- Migration: Service Person Management, Complaint Assignment & Two-Way WhatsApp Ingestion

-- 1. Create service_persons table
CREATE TABLE IF NOT EXISTS public.service_persons (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    service_type TEXT NOT NULL,
    company TEXT NOT NULL,
    whatsapp_number TEXT NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.service_persons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service persons are viewable by everyone." ON public.service_persons FOR SELECT USING (true);
CREATE POLICY "Service persons can be modified by authenticated users." ON public.service_persons FOR ALL USING (auth.role() = 'authenticated');

-- Indexes on service_persons
CREATE INDEX IF NOT EXISTS idx_service_persons_type ON public.service_persons (service_type);
CREATE INDEX IF NOT EXISTS idx_service_persons_active ON public.service_persons (is_active);
CREATE INDEX IF NOT EXISTS idx_service_persons_whatsapp ON public.service_persons (whatsapp_number);

-- Trigger for updated_at
CREATE TRIGGER update_service_persons_modtime 
BEFORE UPDATE ON public.service_persons 
FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- 2. Extend complaints table for service person assignment & latest response
ALTER TABLE public.complaints
    ADD COLUMN IF NOT EXISTS assigned_service_person_id UUID REFERENCES public.service_persons(id) ON DELETE SET NULL,
    ADD COLUMN IF NOT EXISTS latest_service_response TEXT,
    ADD COLUMN IF NOT EXISTS latest_service_response_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS latest_service_response_by UUID REFERENCES public.service_persons(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_complaints_assigned_sp ON public.complaints (assigned_service_person_id);

-- 3. Create complaint_activities table for audit trail & timeline
CREATE TABLE IF NOT EXISTS public.complaint_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    complaint_id UUID NOT NULL REFERENCES public.complaints(id) ON DELETE CASCADE,
    service_person_id UUID REFERENCES public.service_persons(id) ON DELETE SET NULL,
    activity_type TEXT NOT NULL CHECK (activity_type IN ('created', 'assigned', 'reassigned', 'whatsapp_sent', 'whatsapp_received', 'status_changed', 'note_added')),
    message TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.complaint_activities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Complaint activities are viewable by everyone." ON public.complaint_activities FOR SELECT USING (true);
CREATE POLICY "Complaint activities can be modified by authenticated users." ON public.complaint_activities FOR ALL USING (auth.role() = 'authenticated');

CREATE INDEX IF NOT EXISTS idx_complaint_activities_complaint ON public.complaint_activities (complaint_id, created_at DESC);

-- 4. Create whatsapp_messages table for two-way tracking
CREATE TABLE IF NOT EXISTS public.whatsapp_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    complaint_id UUID REFERENCES public.complaints(id) ON DELETE SET NULL,
    service_person_id UUID REFERENCES public.service_persons(id) ON DELETE SET NULL,
    direction TEXT NOT NULL CHECK (direction IN ('INBOUND', 'OUTBOUND')),
    message_text TEXT NOT NULL,
    whatsapp_message_id TEXT,
    status TEXT NOT NULL DEFAULT 'SENT' CHECK (status IN ('SENT', 'DELIVERED', 'READ', 'FAILED', 'RECEIVED')),
    sender_phone TEXT,
    recipient_phone TEXT,
    error_message TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.whatsapp_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "WhatsApp messages are viewable by everyone." ON public.whatsapp_messages FOR SELECT USING (true);
CREATE POLICY "WhatsApp messages can be modified by authenticated users." ON public.whatsapp_messages FOR ALL USING (auth.role() = 'authenticated');

CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_complaint ON public.whatsapp_messages (complaint_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_sp ON public.whatsapp_messages (service_person_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_messages_sender ON public.whatsapp_messages (sender_phone);
